/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import View.MsgConfirm;
import View.MsgError;
import View.MsgInfomation;
import View.MsgWarning;
import View.Msginput;
import java.text.DecimalFormat;

/**
 *
 * @author Pasindu Siriwardana
 */
public class MessagePopUps {
//lbl_text.setText("<html>this is line1<br>this is line2</html>");
    // gfhfjhjhhgjgfhgfhfghgfhmngnggj

    String DATA_SAVED_SUCCESS_AND_PRINT_MSG = "<html>Data Saved Successfully ! <br>Do you want to Print ?</html>";
    String DATA_UPDATED_SUCCESS_MSG = "Data Updated Successfully !";
    String DATA_DELETED_SUCCESS_MSG = "Data Deleted Successfully";
    String DATA_ADDED_SUCCESS_MSG = "Data Added Successfully !";
    String Duplicate_data_MSG = "<html>Sorry, You have this record<br>currently in your Table !</html> ";
    String Duplicate_cheque_MSG = "<html>Sorry, You have this Cheque Number<br>currently in your Database !</html> ";
    String LOGIN_SUCCESS_MSG = "Ok You can Access !";
    String LOGIN_ERROR_MSG = "Sorry, Your Username or Password was Wrong";

    String Item_Location_Error = "Sorry, Change Your Tranfer Location";
    //Basic Error Messages   
    String DATA_NOT_FOUND_ERROR_MSG = "Data Not Found !";
    String REQUIRED_FIEALDS_NOT_EMPTY_ERROR_MSG = "Required fields must no be Empty !";
    String ERROR_MESSAGE_TITTLE = "Error !";
    String SYSTEM_Date_Is_Wrong = " Sorry, System Date Is Wrong";
    String item_code_duplicate = " Sorry, Item Code Is Already Exists";
    String item_name_duplicate = " Sorry, Item Description Is Already Exists";
    String SYSTEM_EXPIRED_MESSAGE_TITTLE = " Sorry,System Expired";
    String SYSTEM_EXPIRED_MSG = "Sorry, System Expired !";
    String SYSTEM_SERIAL_KEY_WRONG_MESSAGE_TITTLE = "System Expired";
    String SYSTEM_SERIAL_KEY_WRONG_MESSAGE = "<html>Serial Key is Invalied<br>Please contact System Admin !</html> ";
    String SYSTEM_SERIAL_KEY_OK_MESSAGE_TITTLE = "System Activated";
    String SYSTEM_SERIAL_KEY_OK_MESSAGE = "System Activated Successfully";
    String DENIED_ACCESS = "Sorry, You dont have Permissions !";
    String NETWORK_ERROR = "Network Error!";
    String DUPLICATE_DATA = "<html>Sorry, You have this recorrd<br>currently in your Database !</html>  ";
    String DUPLICATE_INVOICE = "This invoice number is already exists";
    String DUPLICATE_GRN_INVOICE = "This GRN invoice number is already exists";
    String Number_Format_error = "Invalid Number Format";
    String BLANK_ENTRY = "Sorry, You cannot leave this field empty";
    String Amount_Empty = "Please Enter Amount";
    String Quantity_Empty = "Please Enter Quantity";
    String Exceed_Quantity = "Item Quantity is Exceeded";
    String Item_name_doesnot_match = "Item Description Does't Match";
    String Item_number_doesnot_match = "Item Code Doesn't Match";
    String Cash_Payment_Is_Less_Than_Sub_Total_MSG = "Cash Payment Is Less Than Sub Total";
    String Cash_Payment_is_greater_than_Sub_Total_MSG = "Cash Payment Is Greater Than Sub Total";
    String Credit_Cash_Payment_is_greater_than_Sub_Total_MSG = "<html>Sorry ,Cash Payment Is Greater Than Net Total<br>Check Payment Type or Cash Payment Amount</html>";
    DecimalFormat df2 = new DecimalFormat("#0.00");

    ////////////////udara///////////////////////
    String enter_item_code = "Enter Item Code";
    String enter_item_description = "Enter Item Description";
    String enter_item_category = "Enter Item Type";
    String enter_item_cost = "Enter Item Label Price";
    String enter_item_sell_price = "Enter Item sell Price";
    String data_saved_successfully = "Data Saved Successfully !";
    String INFORMATION_MESSAGE_TITTLE = "Information";
    String mobile_number_invalid = "Invalid Phone Number";

    String supplier_code_exists = "Sorry,Supplier Code Is Already Exists";
    String do_you_want_update = "Do You Want To Update This record";
    String record_updated_success = "Record Updated Successfully";
    String do_you_want_delete = "Do You Want Delete This Record";
    String record_deleted = "Record Deleted Successfully";

    String grn_invoice_duplicate = "Sorry  , Supplier Invoice Code is Already Exists";
    String grn_select_supplier = "Please Select Supplier";
    String please_select_itemcode = "Please Select Item Code";
    String item_desc_is_empty = "Item Description is Empty , Please Select Item Code";
    String item_cost_is_empty = "Item Cost is Empty , Please Select Item Code";
    String enter_discount = "Please Enter Discount";
    String item_amount_empty = "Item Amount is Empty, Please Enter Discount";
    String select_supplier_number = "Please Select Supplier Code";
    String supplier_name_cannt_find = "Supplier Name is Empty ,Please Select Supplier Code";
    String grn_invoice_empty = "Please Enter Supplier Invoice Code";
    String grn_invoie_date_empty = "Please Enter Supplier Invoice Date";
    String grn_number_empty = "Sorry , GRN Code Is Empty. Please Close & ReOpen GRN Form";
    String grn_date_empty = "Please Enter GRN Date";
    String total_amount_emty = "Sorry ,Total Amont Is Empty";
    String sub_amount_emty = "Sorry ,Sub Total Amont Is Empty";
    String enter_total_discount = "Please Enter Total Discount";
    String net_amount_empty = "Net Amount Is Empty";
    String enter_cash_payment = "Please Enter Cash Payment";
    String grn_code_duplicate = "<html>Sorry ,GRN Code is Already Exists, <br>Please Close & ReOpen GRN Form</html>";

    String customer_code_exists = "Sorry,Customer Code Is Already Exists";
    String customer_code_empty = "Please Enter Customer Code";
    String customer_name_empty = "Please Enter Customer Name";
    String customer_address_empty = "Please Enter Customer Address";
    String item_amount_empty_witout_dis = "Please Enter Customer Address";
    String item_sell_price_empty = "Item sell Price Is Empty";
    String item_amount_empty_without_discount = "Item Amount Is Empty";
    String invoce_number_empty = "<html>Sorry , Invoice Code Is Empty.<br>Please Close & ReOpen GRN Form</html> ";
    String invoice_select_customer = "Please Select Customer";
    String invoice_date_empty = "Please Enter Invoice Date";
    String table_empty = "Cann't Find Item Details In Your Table";
    String balance_empty = "Cash Balance Is Empty";
    String same_location = "Invalid Transfer Loation";
    String enter_payment = "Please Enter Payment";
    String enter_cheque_details = "Please Enter Cheque Details";
    String select_type = "Please Select Type";
    String select_cs = "Please Customer/Supplier Code";
    String select_invoice_code = "Please Select Invoice Code";
    String payment_balance_empty = "Payment Balance Is Empty";
    String invoice_grn_code_empty = "Invoice Grn Code Is Empty";
    String enter_cheque_number = "Please Enter Cheque Number";
    String enter_bank = "Please Enter Bank";
    String enter_cheque_date = "Please Enter Cheque Date";
    String payments_completed = "Payments Successfuly Completed";
    String payments_details_not_found = "Cann't Find Payment Details";
    String cannt_find_invoice_credit_details = "Cann't find Invoice Credit Details";
    String cannt_find_grn_credit_details = "Cann't find Grn Credit Details";
    String select_invoice_or_grn = "Please Select Invoice or Grn";
    String customer_not_match = "Customer Code dosn't Match";
    String invoice_amount_empty = "Invoice Amount is Empty";
    String enter_invoice_code = "Enter Invoice Code";
    String duplicate_cheque_code = "Duplicate Cheque Number";
    String enter_cheque_amount = "Enter Cheque Amount";
    String customer_name_empty_cheque = "Customer Name Is Emptyt";
    String cheque_details_empty = "Cheque Detail Is Empty";
    String date_format_error = "Sorry Date Format Is Invalid";
    String enter_bill_code = "Enter Bill Code";
    String enter_date = "Please Enter Date";
    String cannt_find_expense_details = "<html>Cann't Find Expense Or Income Details<br>In Your Table</html> ";
    String invoice_code_doesnot_match = "Invoice Code Doesn't Match";
    String grn_code_doesnot_match = "Grn Code Doesn't Match";
    String cannt_find_invoice_item_details = "Cann't Find Invoice Item Details";
    String cannt_find_grn_item_details = "Cann't Find Grn Item Details";
    String item_price_is_empty = "Item Price Is Empty";
    String amount_is_empty = "Amount Is Empty";
    String user_name_exists = "Sorry, Your Username Already Exists";
    String password_not_in_match = "Sorry, Password Doesn't Match";
    String enter_user_name = "Please Enter User Name";
    String enter_password = "Please Enter Password";
    String user_password_wrong = "Sorry ,User Name or Password Was Wrong";
    String available_quantity_is_empty = "Sorry ,Available Quantity Is Empty";
    String approve_successfully = "Approved Successfully";
    String are_you_sure_approve = "Are You Sure Approve ?";
    String enter_minimun_qty = "Enter Minimum Quantity";
    String get_backup = "Backup taken successfully";
    String not_get_backup = "Could not take mysql backup";
    String return_invoice_payment = "<html>Payment Sucessfully Completed.<br>You Have Manualy Settle Down Customer Payment </html>";
    String enter_group = "Enter New Group";
    String Duplicate_entry = "Sorry Duplicate Entry";
    String Plase_Enter_userGroup = "Plaese Enter User Group";
    String Plase_Enter_full_name = "Plaese Enter User Full Name";
    String Plase_Enter_user_name = "Plaese Enter User Name";
    String Plase_Enter_confirm_paswrd = "Plaese Enter Confirm Password";
    String user_duplicate = "Sorry, User Dupliated";
    String duplicate = "Sorry,  Dupliate Entry";
    String user_name_password_not_match = "<html>Sorry, Current User Name or Password<br>Doesn't Match</html> ";
    String status_change = "Status Changed Sucessfully..!";
    String select_function = "Please Select Function";
    String select_group = "Please Select Group";
    String dont_permision = "Sorry You Don't have Permision";
    String select_Components = "Please Select Component";
    String exit = "Are You Sure Want to Exit ? ";
    String switch_u = "Are You Sure Want to Switch User ? ";
    String transfer_location_invalid = "Sorry, Transfer Location is Invalid";
    String enter_item_purchuse_price = "Sorry, Please Enter Purchuse Price";
    String enter_mesurment_unit = " Please Enter Measurement Unit";
    String enter_valid_unit = " Please Enter Valid Measurement Unit";
    String have_you_payment_now = "Do You Want Pay Now ?";
    String please_enter_ounstad_limit = "Sorry, Please Enter Limit of Outstanding";
    String please_select_customer = "Sorry Please Select Customer";
    String Loss = "Profit is Minus. Do You Want Add This Item";
    String print = "Do You Want to Print";

    public int print() {
        //int user = JOptionPane.showConfirmDialog(null, switch_u);
        int user = MsgConfirm.msg_input(print);
        new MsgConfirm(null, true).setVisible(true);
        user = MsgConfirm.msg_input(print);
        return user;
    }

    public int Loss() {
        //int user = JOptionPane.showConfirmDialog(null, switch_u);
        int user = MsgConfirm.msg_input(Loss);
        new MsgConfirm(null, true).setVisible(true);
        user = MsgConfirm.msg_input(Loss);
        return user;
    }

    public void please_select_customer() {
        MsgError.msg_error(please_select_customer);
        new MsgError(null, true).setVisible(true);
    }

    public void please_enter_ounstad_limit() {
        MsgError.msg_error(please_enter_ounstad_limit);
        new MsgError(null, true).setVisible(true);
    }

    public int have_you_payment_now() {
        //int user = JOptionPane.showConfirmDialog(null, switch_u);
        int user = MsgConfirm.msg_input(have_you_payment_now);
        new MsgConfirm(null, true).setVisible(true);
        user = MsgConfirm.msg_input(have_you_payment_now);
        return user;
    }

    public void enter_valid_unit() {
        MsgError.msg_error(enter_valid_unit);
        new MsgError(null, true).setVisible(true);
    }

    public String enter_mesurment_unit() {
        String group = "";
        Msginput.msg_input1(enter_mesurment_unit);
        new Msginput(null, true).setVisible(true);
        group = Msginput.msg_input(enter_mesurment_unit);
        return group;
    }

    public void enter_item_purchuse_price() {
        //JOptionPane.showMessageDialog(null, select_group, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(enter_item_purchuse_price);
        new MsgError(null, true).setVisible(true);
    }

    public void transfer_location_invalid() {
        //    JOptionPane.showMessageDialog(null, dont_permision, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(transfer_location_invalid);
        new MsgError(null, true).setVisible(true);
    }

    public int switch_user() {
        //int user = JOptionPane.showConfirmDialog(null, switch_u);
        int user = MsgConfirm.msg_input(switch_u);
        new MsgConfirm(null, true).setVisible(true);
        user = MsgConfirm.msg_input(switch_u);
        return user;
    }

    public int exit() {
        //int group = JOptionPane.showConfirmDialog(null, exit);
        int group = MsgConfirm.msg_input(exit);
        new MsgConfirm(null, true).setVisible(true);
        group = MsgConfirm.msg_input(exit);
        return group;
    }

    public String enter_group() {
        //   String group = JOptionPane.showInputDialog(null, enter_group);
        // String group = Msginput.msg_input(enter_group);
        String group = "";
        Msginput.msg_input1(enter_group);
        new Msginput(null, true).setVisible(true);
        group = Msginput.msg_input(enter_group);
        return group;
    }

    public int are_you_sure_approve() {
        //int i = JOptionPane.showConfirmDialog(null, are_you_sure_approve, INFORMATION_MESSAGE_TITTLE, JOptionPane.INFORMATION_MESSAGE);
        int i = MsgConfirm.msg_input(are_you_sure_approve);
        new MsgConfirm(null, true).setVisible(true);
        i = MsgConfirm.msg_input(are_you_sure_approve);
        return i;
    }

    public int do_you_want_delete_record_confirem_msg() {
        //  int i = JOptionPane.showConfirmDialog(null, do_you_want_delete, INFORMATION_MESSAGE_TITTLE, JOptionPane.INFORMATION_MESSAGE);
        int i = MsgConfirm.msg_input(do_you_want_delete);
        new MsgConfirm(null, true).setVisible(true);
        i = MsgConfirm.msg_input(do_you_want_delete);
        return i;
    }

    public int record_update_confirem_msg() {
        //int i = JOptionPane.showConfirmDialog(null, do_you_want_update, INFORMATION_MESSAGE_TITTLE, JOptionPane.INFORMATION_MESSAGE);
        int i = MsgConfirm.msg_input(do_you_want_update);
        new MsgConfirm(null, true).setVisible(true);
        return i;
    }

    public void dont_permision() {
        //    JOptionPane.showMessageDialog(null, dont_permision, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(dont_permision);
        new MsgError(null, true).setVisible(true);
    }

    public void select_Components() {
        //JOptionPane.showMessageDialog(null, select_Components, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(select_Components);
        new MsgError(null, true).setVisible(true);
    }

    public void select_group() {
        //JOptionPane.showMessageDialog(null, select_group, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(select_group);
        new MsgError(null, true).setVisible(true);
    }

    public void select_function() {
        // JOptionPane.showMessageDialog(null, select_function, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(select_function);
        new MsgError(null, true).setVisible(true);
    }

    public void status_change() {
        //JOptionPane.showMessageDialog(null, status_change, INFORMATION_MESSAGE_TITTLE, JOptionPane.INFORMATION_MESSAGE);
        MsgInfomation.msg_information(status_change);
        new MsgInfomation(null, true).setVisible(true);
    }

    public void duplicate() {
        // JOptionPane.showMessageDialog(null, duplicate, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(duplicate);
        new MsgError(null, true).setVisible(true);
    }

    public void user_name_password_not_match() {
        //JOptionPane.showMessageDialog(null, user_name_password_not_match, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(user_name_password_not_match);
        new MsgError(null, true).setVisible(true);
    }

    public void user_duplicate() {
        // JOptionPane.showMessageDialog(null, user_duplicate, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(user_duplicate);
        new MsgError(null, true).setVisible(true);
    }

    public void Plase_Enter_confirm_paswrd() {
        //JOptionPane.showMessageDialog(null, Plase_Enter_confirm_paswrd, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(Plase_Enter_confirm_paswrd);
        new MsgError(null, true).setVisible(true);
    }

    public void Plase_Enter_user_name() {
        //JOptionPane.showMessageDialog(null, Plase_Enter_user_name, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(Plase_Enter_user_name);
        new MsgError(null, true).setVisible(true);
    }

    public void Plase_Enter_full_name() {
        //JOptionPane.showMessageDialog(null, Plase_Enter_full_name, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(Plase_Enter_full_name);
        new MsgError(null, true).setVisible(true);
    }

    public void Plase_Enter_userGroup() {
        //JOptionPane.showMessageDialog(null, Plase_Enter_userGroup, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(Plase_Enter_userGroup);
        new MsgError(null, true).setVisible(true);
    }

    public void Duplicate_entry_plain() {
        //JOptionPane.showMessageDialog(null, Duplicate_entry, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(Duplicate_entry);
        new MsgError(null, true).setVisible(true);
    }

    public void not_get_backup() {
        //JOptionPane.showMessageDialog(null, not_get_backup, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(not_get_backup);
        new MsgError(null, true).setVisible(true);
    }

    public void get_backup() {
        //JOptionPane.showMessageDialog(null, get_backup, INFORMATION_MESSAGE_TITTLE, JOptionPane.INFORMATION_MESSAGE);
        MsgInfomation.msg_information(get_backup);
        new MsgInfomation(null, true).setVisible(true);
    }

    public void return_invoice_payment(String s) {
        // JOptionPane.showMessageDialog(null, return_invoice_payment + s, INFORMATION_MESSAGE_TITTLE, JOptionPane.INFORMATION_MESSAGE);
        MsgInfomation.msg_information(return_invoice_payment + s);
        new MsgInfomation(null, true).setVisible(true);
    }

    public void approve_successfully() {
        //JOptionPane.showMessageDialog(null, approve_successfully, INFORMATION_MESSAGE_TITTLE, JOptionPane.INFORMATION_MESSAGE);
        MsgInfomation.msg_information(approve_successfully);
        new MsgInfomation(null, true).setVisible(true);
    }

    public void enter_minimun_qty() {
        //JOptionPane.showMessageDialog(null, enter_minimun_qty, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(enter_minimun_qty);
        new MsgError(null, true).setVisible(true);
    }

    public void item_name_duplicate() {
        //JOptionPane.showMessageDialog(null, item_name_duplicate, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(item_name_duplicate);
        new MsgError(null, true).setVisible(true);
    }

    public void available_quantity_is_empty() {
        //JOptionPane.showMessageDialog(null, available_quantity_is_empty, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(available_quantity_is_empty);
        new MsgError(null, true).setVisible(true);
    }

    public void user_password_wrong() {
        //JOptionPane.showMessageDialog(null, user_password_wrong, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(user_password_wrong);
        new MsgError(null, true).setVisible(true);
    }

    public void enter_password() {
        //JOptionPane.showMessageDialog(null, enter_password, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(enter_password);
        new MsgError(null, true).setVisible(true);
    }

    public void enter_user_name() {
        // JOptionPane.showMessageDialog(null, enter_user_name, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(enter_user_name);
        new MsgError(null, true).setVisible(true);
    }

    public void password_not_in_match() {
        //JOptionPane.showMessageDialog(null, password_not_in_match, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(password_not_in_match);
        new MsgError(null, true).setVisible(true);
    }

    public void user_name_exists() {
        //JOptionPane.showMessageDialog(null, user_name_exists, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(user_name_exists);
        new MsgError(null, true).setVisible(true);
    }

    public void amount_is_empty() {
        //JOptionPane.showMessageDialog(null, amount_is_empty, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(amount_is_empty);
        new MsgError(null, true).setVisible(true);
    }

    public void item_price_is_empty() {
        // JOptionPane.showMessageDialog(null, item_price_is_empty, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(item_price_is_empty);
        new MsgError(null, true).setVisible(true);
    }

    public void cannt_find_grn_item_details() {
        //JOptionPane.showMessageDialog(null, cannt_find_grn_item_details, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(cannt_find_grn_item_details);
        new MsgError(null, true).setVisible(true);
    }

    public void cannt_find_invoice_item_details() {
        // JOptionPane.showMessageDialog(null, cannt_find_invoice_item_details, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(cannt_find_invoice_item_details);
        new MsgError(null, true).setVisible(true);
    }

    public void grn_code_doesnot_match() {
        //JOptionPane.showMessageDialog(null, grn_code_doesnot_match, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(grn_code_doesnot_match);
        new MsgError(null, true).setVisible(true);
    }

    public void invoice_code_doesnot_match() {
        //JOptionPane.showMessageDialog(null, invoice_code_doesnot_match, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(invoice_code_doesnot_match);
        new MsgError(null, true).setVisible(true);
    }

    public void enter_date() {
        //JOptionPane.showMessageDialog(null, enter_date, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(enter_date);
        new MsgError(null, true).setVisible(true);
    }

    public void cannt_find_expense_details() {
        //JOptionPane.showMessageDialog(null, cannt_find_expense_details, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(cannt_find_expense_details);
        new MsgError(null, true).setVisible(true);
    }

    public void enter_bill_code() {
        //JOptionPane.showMessageDialog(null, enter_bill_code, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(enter_bill_code);
        new MsgError(null, true).setVisible(true);
    }

    public void date_format_error() {
        //JOptionPane.showMessageDialog(null, date_format_error, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(date_format_error);
        new MsgError(null, true).setVisible(true);
    }

    public void enter_cheque_amount() {
        //JOptionPane.showMessageDialog(null, enter_cheque_amount, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(enter_cheque_amount);
        new MsgError(null, true).setVisible(true);
    }

    public void cheque_details_empty() {
        // JOptionPane.showMessageDialog(null, cheque_details_empty, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(cheque_details_empty);
        new MsgError(null, true).setVisible(true);
    }

    public void customer_name_empty_cheque() {
        //JOptionPane.showMessageDialog(null, customer_name_empty_cheque, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(customer_name_empty_cheque);
        new MsgError(null, true).setVisible(true);
    }

    public void duplicate_cheque_code() {
        //JOptionPane.showMessageDialog(null, duplicate_cheque_code, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(duplicate_cheque_code);
        new MsgError(null, true).setVisible(true);
    }

    public void invoice_amount_empty() {
        //JOptionPane.showMessageDialog(null, invoice_amount_empty, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(invoice_amount_empty);
        new MsgError(null, true).setVisible(true);
    }

    public void enter_invoice_code() {
        // JOptionPane.showMessageDialog(null, enter_invoice_code, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(enter_invoice_code);
        new MsgError(null, true).setVisible(true);
    }

    public void customer_not_match() {
        // JOptionPane.showMessageDialog(null, customer_not_match, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(customer_not_match);
        new MsgError(null, true).setVisible(true);
    }

    public void select_invoice_or_grn() {
        // JOptionPane.showMessageDialog(null, select_invoice_or_grn, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(select_invoice_or_grn);
        new MsgError(null, true).setVisible(true);
    }

    public void payments_completed() {
        // JOptionPane.showMessageDialog(null, payments_completed, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(payments_completed);
        new MsgError(null, true).setVisible(true);
    }

    public void cannt_find_grn_credit_details() {
        //JOptionPane.showMessageDialog(null, cannt_find_grn_credit_details, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(cannt_find_grn_credit_details);
        new MsgError(null, true).setVisible(true);
    }

    public void cannt_find_invoice_credit_details() {
        //JOptionPane.showMessageDialog(null, cannt_find_invoice_credit_details, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(cannt_find_invoice_credit_details);
        new MsgError(null, true).setVisible(true);
    }

    public void payments_details_not_found() {
        //JOptionPane.showMessageDialog(null, payments_details_not_found, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(payments_details_not_found);
        new MsgError(null, true).setVisible(true);
    }

    public void enter_cheque_date() {
        //JOptionPane.showMessageDialog(null, enter_cheque_date, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(enter_cheque_date);
        new MsgError(null, true).setVisible(true);
    }

    public void enter_bank() {
        //JOptionPane.showMessageDialog(null, enter_bank, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(enter_bank);
        new MsgError(null, true).setVisible(true);
    }

    public void enter_cheque_number() {
        //JOptionPane.showMessageDialog(null, enter_cheque_number, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(enter_cheque_number);
        new MsgError(null, true).setVisible(true);
    }

    public void invoice_grn_code_empty() {
        //JOptionPane.showMessageDialog(null, invoice_grn_code_empty, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(invoice_grn_code_empty);
        new MsgError(null, true).setVisible(true);
    }

    public void payment_balance_empty() {
        //JOptionPane.showMessageDialog(null, payment_balance_empty, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(payment_balance_empty);
        new MsgError(null, true).setVisible(true);
    }

    public void select_invoice_code() {
        //  JOptionPane.showMessageDialog(null, select_invoice_code, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(select_invoice_code);
        new MsgError(null, true).setVisible(true);
    }

    public void select_cs() {
        // JOptionPane.showMessageDialog(null, select_cs, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(select_cs);
        new MsgError(null, true).setVisible(true);
    }

    public void select_type() {
        // JOptionPane.showMessageDialog(null, select_type, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(select_type);
        new MsgError(null, true).setVisible(true);
    }

    public void enter_cheque_details() {
        // JOptionPane.showMessageDialog(null, enter_cheque_details, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(enter_cheque_details);
        new MsgError(null, true).setVisible(true);
    }

    public void enter_payment() {
        //JOptionPane.showMessageDialog(null, enter_payment, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(enter_payment);
        new MsgError(null, true).setVisible(true);
    }

    public void table_empty() {
        //JOptionPane.showMessageDialog(null, table_empty, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(table_empty);
        new MsgError(null, true).setVisible(true);
    }

    public void same_location() {
        //JOptionPane.showMessageDialog(null, same_location, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(same_location);
        new MsgError(null, true).setVisible(true);
    }

    public void balance_empty() {
        // JOptionPane.showMessageDialog(null, balance_empty, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(balance_empty);
        new MsgError(null, true).setVisible(true);
    }

    public void item_sell_price_empty() {
        // JOptionPane.showMessageDialog(null, item_sell_price_empty, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(item_sell_price_empty);
        new MsgError(null, true).setVisible(true);
    }

    public void invoice_date_empty() {
        //JOptionPane.showMessageDialog(null, invoice_date_empty, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(invoice_date_empty);
        new MsgError(null, true).setVisible(true);
    }

    public void invoice_select_customer() {
        //JOptionPane.showMessageDialog(null, invoice_select_customer, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(invoice_select_customer);
        new MsgError(null, true).setVisible(true);
    }

    public void invoice_code_empty() {
        // JOptionPane.showMessageDialog(null, invoce_number_empty, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(invoce_number_empty);
        new MsgError(null, true).setVisible(true);
    }

    public void sub_total_empty() {
        // JOptionPane.showMessageDialog(null, sub_amount_emty, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(sub_amount_emty);
        new MsgError(null, true).setVisible(true);
    }

    public void item_amount_empty_witout_dis() {
        // JOptionPane.showMessageDialog(null, item_amount_empty_witout_dis, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(item_amount_empty_witout_dis);
        new MsgError(null, true).setVisible(true);
    }

    public void enter_item_code() {
        //JOptionPane.showMessageDialog(null, enter_item_code, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(enter_item_code);
        new MsgError(null, true).setVisible(true);
    }

    public void enter_item_description() {
        // JOptionPane.showMessageDialog(null, enter_item_description, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(enter_item_description);
        new MsgError(null, true).setVisible(true);
    }

    public void enter_item_category() {
        // JOptionPane.showMessageDialog(null, enter_item_category, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(enter_item_category);
        new MsgError(null, true).setVisible(true);
    }

    public void enter_item_cost() {
        // JOptionPane.showMessageDialog(null, enter_item_cost, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(enter_item_cost);
        new MsgError(null, true).setVisible(true);
    }

    public void enter_item_sall_pricet() {
        // JOptionPane.showMessageDialog(null, enter_item_sell_price, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(enter_item_sell_price);
        new MsgError(null, true).setVisible(true);
    }

    public void saveMessage() {
        // JOptionPane.showMessageDialog(null, data_saved_successfully, INFORMATION_MESSAGE_TITTLE, JOptionPane.INFORMATION_MESSAGE);
        MsgInfomation.msg_information(data_saved_successfully);
        new MsgInfomation(null, true).setVisible(true);
    }

    public void suypplier_number_duplicat() {
        // JOptionPane.showMessageDialog(null, supplier_code_exists, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(supplier_code_exists);
        new MsgError(null, true).setVisible(true);
    }

    public void mobile_number_inaild() {
        // JOptionPane.showMessageDialog(null, mobile_number_invalid, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(mobile_number_invalid);
        new MsgError(null, true).setVisible(true);
    }

    public void record_updated() {
        //JOptionPane.showMessageDialog(null, record_updated_success, INFORMATION_MESSAGE_TITTLE, JOptionPane.INFORMATION_MESSAGE);
        MsgInfomation.msg_information(record_updated_success);
        new MsgInfomation(null, true).setVisible(true);
    }

    public void record_deleted() {
        //JOptionPane.showMessageDialog(null, record_deleted, INFORMATION_MESSAGE_TITTLE, JOptionPane.INFORMATION_MESSAGE);
        MsgInfomation.msg_information(record_deleted);
        new MsgInfomation(null, true).setVisible(true);
    }

    public void grn_invoice_duplicate() {
        // JOptionPane.showMessageDialog(null, grn_invoice_duplicate, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(grn_invoice_duplicate);
        new MsgError(null, true).setVisible(true);
    }

    public void please_select_supplier() {
        // JOptionPane.showMessageDialog(null, grn_select_supplier, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(grn_select_supplier);
        new MsgError(null, true).setVisible(true);
    }

    public void please_item_code() {
        //JOptionPane.showMessageDialog(null, please_select_itemcode, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(please_select_itemcode);
        new MsgError(null, true).setVisible(true);
    }

    public void item_desc_is_empty() {
        //  JOptionPane.showMessageDialog(null, item_desc_is_empty, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(item_desc_is_empty);
        new MsgError(null, true).setVisible(true);
    }

    public void item_cost_is_empty() {
        //JOptionPane.showMessageDialog(null, item_cost_is_empty, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(item_cost_is_empty);
        new MsgError(null, true).setVisible(true);
    }

    public void enter_discount() {
        // JOptionPane.showMessageDialog(null, enter_discount, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(enter_discount);
        new MsgError(null, true).setVisible(true);
    }

    public void item_amount_empty() {
        //JOptionPane.showMessageDialog(null, item_amount_empty, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(item_amount_empty);
        new MsgError(null, true).setVisible(true);
    }

    public void select_supplier_number() {
        //JOptionPane.showMessageDialog(null, select_supplier_number, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(select_supplier_number);
        new MsgError(null, true).setVisible(true);
    }

    public void supplier_name_cannt_find() {
        // JOptionPane.showMessageDialog(null, supplier_name_cannt_find, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(supplier_name_cannt_find);
        new MsgError(null, true).setVisible(true);
    }

    public void enter_grn_invoice_number() {
        //JOptionPane.showMessageDialog(null, grn_invoice_empty, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(grn_invoice_empty);
        new MsgError(null, true).setVisible(true);
    }

    public void enter_grn_invoice_date() {
        //JOptionPane.showMessageDialog(null, grn_invoie_date_empty, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(grn_invoie_date_empty);
        new MsgError(null, true).setVisible(true);
    }

    public void grn_code_empty() {
        //  JOptionPane.showMessageDialog(null, grn_number_empty, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(grn_number_empty);
        new MsgError(null, true).setVisible(true);
    }

    public void grn_date_empty() {
        //   JOptionPane.showMessageDialog(null, grn_date_empty, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(grn_date_empty);
        new MsgError(null, true).setVisible(true);
    }

    public void total_amount_empty() {
        // JOptionPane.showMessageDialog(null, total_amount_emty, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(total_amount_emty);
        new MsgError(null, true).setVisible(true);
    }

    public void enter_total_discount() {
        // JOptionPane.showMessageDialog(null, enter_total_discount, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(enter_total_discount);
        new MsgError(null, true).setVisible(true);
    }

    public void net_amount_empty() {
        //JOptionPane.showMessageDialog(null, net_amount_empty, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(net_amount_empty);
        new MsgError(null, true).setVisible(true);
    }

    public void enter_cash_payment() {
        //  JOptionPane.showMessageDialog(null, enter_cash_payment, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(enter_cash_payment);
        new MsgError(null, true).setVisible(true);
    }
    
    public void enter_bill_no() {
        //  JOptionPane.showMessageDialog(null, enter_cash_payment, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error("Please Enter Bill No");
        new MsgError(null, true).setVisible(true);
    }

    public void grn_code_duplicate() {
        // JOptionPane.showMessageDialog(null, grn_code_duplicate, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(grn_code_duplicate);
        new MsgError(null, true).setVisible(true);
    }

    public void customer_code_duplicate() {
        //JOptionPane.showMessageDialog(null, customer_code_exists, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(customer_code_exists);
        new MsgError(null, true).setVisible(true);
    }

    public void customer_code_empty() {
        // JOptionPane.showMessageDialog(null, customer_code_empty, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(customer_code_empty);
        new MsgError(null, true).setVisible(true);
    }

    public void customername_empty() {
        //  JOptionPane.showMessageDialog(null, customer_name_empty, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(customer_name_empty);
        new MsgError(null, true).setVisible(true);
    }

    public void customer_address_empty() {
        // JOptionPane.showMessageDialog(null, customer_address_empty, "Error  !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(customer_address_empty);
        new MsgError(null, true).setVisible(true);
    }

    //////////////////udara///////////
    public void duplicateGRNMessage() {
        // JOptionPane.showMessageDialog(null, DUPLICATE_GRN_INVOICE, ERROR_MESSAGE_TITTLE, JOptionPane.ERROR_MESSAGE);
        MsgInfomation.msg_information(DUPLICATE_GRN_INVOICE);
        new MsgInfomation(null, true).setVisible(true);
    }

    public void item_code_duplicate() {
        //JOptionPane.showMessageDialog(null, item_code_duplicate, "Error !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(item_code_duplicate);
        new MsgError(null, true).setVisible(true);
    }

    public void duplicateInvoiceMessage() {
        //JOptionPane.showMessageDialog(null, DUPLICATE_INVOICE, ERROR_MESSAGE_TITTLE, JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(DUPLICATE_INVOICE);
        new MsgError(null, true).setVisible(true);
    }

    public void blankEntryMessage() {
        // JOptionPane.showMessageDialog(null, BLANK_ENTRY, ERROR_MESSAGE_TITTLE, JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(BLANK_ENTRY);
        new MsgError(null, true).setVisible(true);
    }

    public void deleteMessage() {
        // JOptionPane.showMessageDialog(null, DATA_DELETED_SUCCESS_MSG, INFORMATION_MESSAGE_TITTLE, JOptionPane.INFORMATION_MESSAGE);
        MsgInfomation.msg_information(DATA_DELETED_SUCCESS_MSG);
        new MsgInfomation(null, true).setVisible(true);
    }

    public void updateMessage() {
        //JOptionPane.showMessageDialog(null, DATA_UPDATED_SUCCESS_MSG, INFORMATION_MESSAGE_TITTLE, JOptionPane.INFORMATION_MESSAGE);
        MsgInfomation.msg_information(DATA_UPDATED_SUCCESS_MSG);
        new MsgInfomation(null, true).setVisible(true);
    }

    public void duplicateEntryMessage() {
        // JOptionPane.showMessageDialog(null, DUPLICATE_DATA, ERROR_MESSAGE_TITTLE, JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(DUPLICATE_DATA);
        new MsgError(null, true).setVisible(true);
    }

    public void dataNotFoundMessage() {
        //  JOptionPane.showMessageDialog(null, DATA_NOT_FOUND_ERROR_MSG, ERROR_MESSAGE_TITTLE, JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(DATA_NOT_FOUND_ERROR_MSG);
        new MsgError(null, true).setVisible(true);
    }

    public void loginSuccessMessage() {
        //JOptionPane.showMessageDialog(null, LOGIN_SUCCESS_MSG, "Successfully Logged to the System", JOptionPane.INFORMATION_MESSAGE);
        MsgInfomation.msg_information(LOGIN_SUCCESS_MSG);
        new MsgInfomation(null, true).setVisible(true);
    }

    public void errorInLogin() {
        //JOptionPane.showMessageDialog(null, LOGIN_ERROR_MSG, "Check your Username or Password", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(LOGIN_ERROR_MSG);
        new MsgError(null, true).setVisible(true);
    }

    public void errorInSerial() {
        // JOptionPane.showMessageDialog(null, SYSTEM_SERIAL_KEY_WRONG_MESSAGE, SYSTEM_SERIAL_KEY_WRONG_MESSAGE_TITTLE, JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(SYSTEM_SERIAL_KEY_WRONG_MESSAGE);
        new MsgError(null, true).setVisible(true);
    }

    public void successSerialKey() {
        // JOptionPane.showMessageDialog(null, SYSTEM_SERIAL_KEY_OK_MESSAGE_TITTLE, SYSTEM_SERIAL_KEY_OK_MESSAGE_TITTLE, JOptionPane.INFORMATION_MESSAGE);
        MsgInfomation.msg_information(SYSTEM_SERIAL_KEY_OK_MESSAGE_TITTLE);
        new MsgInfomation(null, true).setVisible(true);
    }

    public void exceptionMessage(Exception ex) {
        //JOptionPane.showMessageDialog(null, ex, "Sorry System Error !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error("Sorry System Error !");
        new MsgError(null, true).setVisible(true);
    }

    public void AccessDenideMessage() {
        //JOptionPane.showMessageDialog(null, DENIED_ACCESS, "Warning", JOptionPane.WARNING_MESSAGE);
        MsgWarning.msg_warning(DENIED_ACCESS);
        new MsgWarning(null, true).setVisible(true);
    }

    public void NetworkError() {
        //JOptionPane.showMessageDialog(null, NETWORK_ERROR, "Error !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(NETWORK_ERROR);
        new MsgError(null, true).setVisible(true);
    }

    public void Number_format_error() {
        // JOptionPane.showMessageDialog(null, Number_Format_error, "Error !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(Number_Format_error);
        new MsgError(null, true).setVisible(true);
    }

    public void Amount_Empty() {
        //  JOptionPane.showMessageDialog(null, Amount_Empty, "Error !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(Amount_Empty);
        new MsgError(null, true).setVisible(true);
    }

    public void Quantity_Empty() {
        //  JOptionPane.showMessageDialog(null, Quantity_Empty, "Error !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(Quantity_Empty);
        new MsgError(null, true).setVisible(true);
    }

    public void Data_Added_Successfully() {
        // JOptionPane.showMessageDialog(null, DATA_ADDED_SUCCESS_MSG, "Information", JOptionPane.INFORMATION_MESSAGE);
        MsgInfomation.msg_information(DATA_ADDED_SUCCESS_MSG);
        new MsgInfomation(null, true).setVisible(true);
    }

    public void Item_number_dosesnot_match() {
        // JOptionPane.showMessageDialog(null, Item_number_doesnot_match, "Error !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(Item_number_doesnot_match);
        new MsgError(null, true).setVisible(true);
    }

    public void Item_Name_dosesnot_match() {
        //JOptionPane.showMessageDialog(null, Item_name_doesnot_match, "Error !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(Item_name_doesnot_match);
        new MsgError(null, true).setVisible(true);
    }

    public void Exceed_Quantity() {
        //JOptionPane.showMessageDialog(null, Exceed_Quantity, "Error !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(Exceed_Quantity);
        new MsgError(null, true).setVisible(true);
    }

    public void Duplicate_entry() {
        // JOptionPane.showMessageDialog(null, Duplicate_data_MSG, "Error !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(Duplicate_data_MSG);
        new MsgError(null, true).setVisible(true);
    }

    public void Duplicate_cheque() {
        //JOptionPane.showMessageDialog(null, Duplicate_cheque_MSG, "Error !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(Duplicate_cheque_MSG);
        new MsgError(null, true).setVisible(true);
    }

    public void Location_Change() {
        //JOptionPane.showMessageDialog(null, Item_Location_Error, "Warning  !", JOptionPane.WARNING_MESSAGE);
        MsgWarning.msg_warning(Item_Location_Error);
        new MsgWarning(null, true).setVisible(true);
    }

    public void Sytem_expire() {
        //  JOptionPane.showMessageDialog(null, SYSTEM_EXPIRED_MESSAGE_TITTLE, "Warning  !", JOptionPane.WARNING_MESSAGE);
        MsgWarning.msg_warning(SYSTEM_EXPIRED_MESSAGE_TITTLE);
        new MsgWarning(null, true).setVisible(true);
    }

    public void Sytem_date_wrong() {
        //JOptionPane.showMessageDialog(null, SYSTEM_Date_Is_Wrong, "Warning  !", JOptionPane.WARNING_MESSAGE);
        MsgWarning.msg_warning(SYSTEM_Date_Is_Wrong);
        new MsgWarning(null, true).setVisible(true);
    }

    public void paymet_low() {
        // JOptionPane.showMessageDialog(null, Cash_Payment_Is_Less_Than_Sub_Total_MSG, "Error !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(Cash_Payment_Is_Less_Than_Sub_Total_MSG);
        new MsgError(null, true).setVisible(true);
    }

    public void paymet_High() {
        //JOptionPane.showMessageDialog(null, Cash_Payment_is_greater_than_Sub_Total_MSG, "Warning  !", JOptionPane.INFORMATION_MESSAGE);
        MsgWarning.msg_warning(Cash_Payment_is_greater_than_Sub_Total_MSG);
        new MsgWarning(null, true).setVisible(true);
    }

    public void credit_payment_High() {
        //JOptionPane.showMessageDialog(null, Credit_Cash_Payment_is_greater_than_Sub_Total_MSG, "Error !", JOptionPane.ERROR_MESSAGE);
        MsgError.msg_error(Credit_Cash_Payment_is_greater_than_Sub_Total_MSG);
        new MsgError(null, true).setVisible(true);
    }

}
