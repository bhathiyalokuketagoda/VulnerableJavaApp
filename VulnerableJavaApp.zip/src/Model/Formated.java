/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.awt.Color;
import java.net.Inet4Address;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

/**
 *
 * @author user
 */
public class Formated {

    DecimalFormat df2 = new DecimalFormat("#0.00");

    public String todayDate() {
        String DATE_FORMAT = "yyyy-MM-dd";
        Date Sysdate = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
        Calendar c1 = Calendar.getInstance();
        c1.setTime(Sysdate);
        return sdf.format(c1.getTime());
    }

    public String ipAddress() {
        String ipadd = "";
        try {
            ipadd = Inet4Address.getLocalHost().getHostAddress();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ipadd;
    }

    public void date_fromat(JTextField txt_date_textfieald) {
        try {
            DateTimeFormatter dateStringFormat = DateTimeFormat.forPattern("yyyy-MM-dd");
            DateTime firstTime = dateStringFormat.parseDateTime(txt_date_textfieald.getText());
            txt_date_textfieald.setBackground(Color.white);
        } catch (Exception e) {
            txt_date_textfieald.setText(null);
            txt_date_textfieald.setBackground(Color.RED);
            //infoims.Object.messagePopUps.date_format_error();
        }

    }

    public boolean string_date_fromat(String date) {
        boolean bool = false;
        try {
            DateTimeFormatter dateStringFormat = DateTimeFormat.forPattern("yyyy-MM-dd");
            DateTime currect_date = dateStringFormat.parseDateTime(date);
        } catch (Exception e) {
            bool = true;
        }
        return bool;
    }

    public String nowTime() {
        String DATE_FORMAT = "hh:mm:ss a";
        Date Sysdate = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
        Calendar c1 = Calendar.getInstance();
        c1.setTime(Sysdate);
        return sdf.format(c1.getTime());
    }
    
     public String time_h_m() {
        String DATE_FORMAT = "hh:mm";
        Date Sysdate = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
        Calendar c1 = Calendar.getInstance();
        c1.setTime(Sysdate);
        return sdf.format(c1.getTime());
    }

    public String nowTime_1() {
        String DATE_FORMAT = "hh:mm:ss";
        Date Sysdate = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
        Calendar c1 = Calendar.getInstance();
        c1.setTime(Sysdate);
        return sdf.format(c1.getTime());
    }

    public String Month_day() {
        String month = "";
        Date date = new Date();
        if (date.getMonth() == 0) {
            month = "Jan";
        } else if (date.getMonth() == 1) {
            month = "Feb";
        } else if (date.getMonth() == 2) {
            month = "Mar";
        } else if (date.getMonth() == 3) {
            month = "Apr";
        } else if (date.getMonth() == 4) {
            month = "May";
        } else if (date.getMonth() == 5) {
            month = "June";
        } else if (date.getMonth() == 6) {
            month = "July";
        } else if (date.getMonth() == 7) {
            month = "Aug";
        } else if (date.getMonth() == 8) {
            month = "Sept";
        } else if (date.getMonth() == 9) {
            month = "Oct";
        } else if (date.getMonth() == 10) {
            month = "Nov";
        } else if (date.getMonth() == 11) {
            month = "Dec";
        }
        month = String.valueOf(date.getDate()) + ", " + month;
        return month;
    }

    public String today() {
        String today = "";
        Date date = new Date();
        if (date.getDay() == 0) {
            today = "Sunday";
        } else if (date.getDay() == 1) {
            today = "Monday";
        } else if (date.getDay() == 2) {
            today = "Tuesday";
        } else if (date.getDay() == 3) {
            today = "Wednesday";
        } else if (date.getDay() == 4) {
            today = "Thursday";
        } else if (date.getDay() == 5) {
            today = "Friday";
        } else if (date.getDay() == 6) {
            today = "Saturday";
        }
        return today;
    }

    public String getPriceValue(double inputValue) {
        String formatedValue = df2.format(inputValue);
        return formatedValue;
    }

    public void Double_format_check(JTextField txt_field) {
        try {
            Double d = 0.00;
            if (txt_field.getText().isEmpty()) {
            } else {
                d = Double.parseDouble(txt_field.getText() + "0");
            }
        } catch (NumberFormatException e) {
            Model.Object.messagePopUps.Number_format_error();
            txt_field.setText(null);
            txt_field.grabFocus();
        }
    }

    public void int_formate_check(JTextField txt_field) {
        try {
            int i = 0;
            if (txt_field.getText().isEmpty()) {
            } else {
                i = Integer.parseInt(txt_field.getText());
            }
        } catch (NumberFormatException e) {
            Model.Object.messagePopUps.Number_format_error();
            txt_field.setText(null);
            txt_field.grabFocus();
        } catch (Exception e) {
        }
    }

    public String StartDate() {
        String startDate = JOptionPane.showInputDialog("Enter Start Date", Model.Object.Formated.todayDate());
        return startDate;
    }

    public String EndDate() {
        String endDate = JOptionPane.showInputDialog("Enter End Date", Model.Object.Formated.todayDate());
        return endDate;
    }
}
