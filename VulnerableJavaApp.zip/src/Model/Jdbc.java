/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author user
 */
public class Jdbc {

    String driver = "com.mysql.jdbc.Driver";
      //String url = "jdbc:mysql://localhost:3306/infoims_walava_krushi";
    String url = "jdbc:mysql://localhost:3306/infoims_sumith_new_chathuka";
   

    public Connection getconnection() throws Exception {
        Class.forName(driver);
        Connection con = DriverManager.getConnection(url, "root", "");
        //Connection con = DriverManager.getConnection(url, "root", "");
        //pass=Infocraft@99.com
        return con;
    }

    public void putdata(String sql) {
        try {
            PreparedStatement state = getconnection().prepareStatement(sql);
            state.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public ResultSet getdata(String sql) throws Exception {
        Statement state = getconnection().createStatement();
        ResultSet rset = state.executeQuery(sql);
        return rset;
    }
}
