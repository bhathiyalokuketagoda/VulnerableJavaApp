/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package infoims;

import View.FrmLogin;
import javax.swing.UIManager;

/**
 *
 * @author user
 */
public class Run {

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                    new FrmLogin().setVisible(true);
                } catch (Exception e) {
                }
            }
        });
    }
}
