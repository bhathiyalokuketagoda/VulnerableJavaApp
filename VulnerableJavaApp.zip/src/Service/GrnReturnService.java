/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import java.sql.ResultSet;
import java.util.Vector;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import View.FrmGrnReturn;
import View.FrmHome2;

/**
 *
 * @author user
 */
public class GrnReturnService {

    public void code_gen(JLabel lbl_return_code) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select max(code) from grn_return_code");
            if (rset.next()) {
                lbl_return_code.setText("GRNRT" + (rset.getInt(1) + 1));
            }
        } catch (Exception e) {
            System.out.println("grn return code_gen   " + e);
        }
    }

    public void select_grn(JTextField txt_grn_code, JLabel lbl_supplier_code, JLabel lbl_supplier_name, JComboBox cbo_item_code) {
        try {
            //ResultSet rset_grn_balance = Model.Object.Jdbc.getdata("select * from grn_balance where grn_code='" + txt_grn_code.getText() + "'");
            ResultSet rset_grn_balance = Model.Object.Jdbc.getdata("select * from grn_balance where supplier_invoice_code='" + txt_grn_code.getText() + "'");
            if (rset_grn_balance.next()) {
                String grnCode = rset_grn_balance.getString(1);

                ResultSet rset_grnitem = Model.Object.Jdbc.getdata("select m.* from grn_item i inner join item_master m on m.item_code = i.item_code where grn_code='" + grnCode + "'");
                Vector v = new Vector();
                while (rset_grnitem.next()) {
                    v.add(rset_grnitem.getString(2));
                }
                cbo_item_code.setModel(new DefaultComboBoxModel(v));
                ResultSet rset_supplier = Model.Object.Jdbc.getdata("select* from supplier_master where supplier_code='" + rset_grn_balance.getString(2) + "'");
                if (rset_supplier.next()) {
                    lbl_supplier_code.setText(rset_supplier.getString(1));
                    lbl_supplier_name.setText(rset_supplier.getString(2));
                } else {
                    lbl_supplier_code.setText(null);
                    lbl_supplier_name.setText(null);
                }
                cbo_item_code.grabFocus();
            } else {
                Model.Object.messagePopUps.grn_code_doesnot_match();
                Vector v = new Vector();
                v.add("[ Select ]");
                txt_grn_code.grabFocus();
                lbl_supplier_code.setText(null);
                cbo_item_code.setModel(new DefaultComboBoxModel(v));
                lbl_supplier_name.setText(null);
            }
        } catch (Exception e) {
            System.out.println("grn return select_grn   " + e);
        }
    }

    public void select_item(JLabel lbl_available_stock, JTextField txt_grn_code, JComboBox cbo_item_code, JLabel lbl_item_description, JLabel lbl_by_price, JLabel lbl_by_qty, JLabel lbl_total_amount, JLabel lbl_item_discount, JLabel lbl_net_amount, JLabel lbl_total_discount, JLabel lbl_sub_total, JLabel lbl_return_item_unit_price, JComboBox cbo_return_location) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select i.* from grn_item i inner join grn_balance b on b.grn_code = i.grn_code where b.supplier_invoice_code='" + txt_grn_code.getText() + "' and i.item_code='" + cbo_item_code.getSelectedItem() + "'");
            if (rset.next()) {
                lbl_item_description.setText(rset.getString(3));
                lbl_by_price.setText(rset.getString(5));
                lbl_by_qty.setText(rset.getString(6));
                lbl_total_amount.setText(rset.getString(7));
                lbl_item_discount.setText(rset.getString(9));
                lbl_net_amount.setText(rset.getString(10));
                lbl_total_discount.setText(rset.getString(11));
                lbl_sub_total.setText(rset.getString(12));
                ResultSet rset_stock = Model.Object.Jdbc.getdata("select* from item_inventory where item_code='" + cbo_item_code.getSelectedItem() + "' and location='" + cbo_return_location.getSelectedItem() + "'");
                if (rset_stock.next()) {
                    lbl_available_stock.setText(rset_stock.getString(4));
                }
                lbl_return_item_unit_price.setText(Model.Object.Formated.getPriceValue((Double.parseDouble(lbl_sub_total.getText()) / Double.parseDouble(lbl_by_qty.getText()))));
            } else {
                Model.Object.messagePopUps.cannt_find_grn_item_details();
                cbo_item_code.grabFocus();
            }
        } catch (Exception e) {
            System.out.println("grn return select_item  " + e);
        }
    }

    public void return_location_change(JComboBox cbo_item_code, JLabel lbl_available_stock, JComboBox cbo_return_location) {
        try {
            ResultSet rset_stock = Model.Object.Jdbc.getdata("select* from item_inventory where item_code='" + cbo_item_code.getSelectedItem() + "' and location='" + cbo_return_location.getSelectedItem() + "'");
            if (rset_stock.next()) {
                lbl_available_stock.setText(rset_stock.getString(4));
            }
        } catch (Exception e) {
            System.out.println("grn return return_location_change  " + e);
        }
    }

    public void quantity_action(JButton btn_add, JLabel lbl_item_return_amount, JLabel lbl_available_stock, JLabel lbl_by_qty, JLabel lbl_return_item_unit_price, JComboBox cbo_item_code, JTextField txt_return_quantity) {
        try {
            if (txt_return_quantity.getText().isEmpty()) {
                Model.Object.messagePopUps.Quantity_Empty();
                txt_return_quantity.grabFocus();
            } else if (lbl_return_item_unit_price.getText().isEmpty()) {
                Model.Object.messagePopUps.item_price_is_empty();
                cbo_item_code.grabFocus();
            } else {
                if (Double.parseDouble(lbl_by_qty.getText()) < Double.parseDouble(txt_return_quantity.getText())) {
                    Model.Object.messagePopUps.Exceed_Quantity();
                    txt_return_quantity.grabFocus();
                    txt_return_quantity.selectAll();
                } else {
                    if (Double.parseDouble(lbl_available_stock.getText()) < Double.parseDouble(txt_return_quantity.getText())) {
                        Model.Object.messagePopUps.Exceed_Quantity();
                        txt_return_quantity.grabFocus();
                        txt_return_quantity.selectAll();
                    } else {
                        lbl_item_return_amount.setText(Model.Object.Formated.getPriceValue(Double.parseDouble(txt_return_quantity.getText()) * Double.parseDouble(lbl_return_item_unit_price.getText())));
                        btn_add.grabFocus();
                    }
                }

            }
        } catch (Exception e) {
            System.out.println("grn return quantity_action  " + e);
        }
    }

    public void add(JLabel lbl_return_total_amount, JLabel lbl_supplier_code, JLabel lbl_supplier_name, JLabel lbl_item_return_amount, JComboBox cbo_return_location, JLabel lbl_return_item_unit_price, JLabel lbl_sub_total, JLabel lbl_total_discount, JLabel lbl_net_amount, JLabel lbl_item_discount, JLabel lbl_total_amount, JTable tbl_return, JLabel lbl_available_stock, JTextField txt_grn_code, JComboBox cbo_item_code, JLabel lbl_item_description, JLabel lbl_by_price, JLabel lbl_by_qty, JTextField txt_return_quantity) {
        try {
            //ResultSet rset = Model.Object.Jdbc.getdata("select* from grn_item where grn_code='" + txt_grn_code.getText() + "' and item_code='" + cbo_item_code.getSelectedItem() + "'");
            ResultSet rset = Model.Object.Jdbc.getdata("select i.* from grn_item i inner join grn_balance b on b.grn_code = i.grn_code where b.supplier_invoice_code='" + txt_grn_code.getText() + "' and item_code='" + cbo_item_code.getSelectedItem() + "'");
            if (rset.next()) {
                if (Double.parseDouble(lbl_by_qty.getText()) < Double.parseDouble(txt_return_quantity.getText())) {
                    Model.Object.messagePopUps.Exceed_Quantity();
                    txt_return_quantity.grabFocus();
                    txt_return_quantity.selectAll();
                } else {
                    if (Double.parseDouble(lbl_available_stock.getText()) < Double.parseDouble(txt_return_quantity.getText())) {
                        Model.Object.messagePopUps.Exceed_Quantity();
                        txt_return_quantity.grabFocus();
                        txt_return_quantity.selectAll();
                    } else {
                        boolean duplicate = false;
                        ResultSet rset_duplicate = Model.Object.Jdbc.getdata("select* from grn_return_item where item_code='" + cbo_item_code.getSelectedItem() + "' and grn_code='" + txt_grn_code.getText() + "'");
                        if (rset_duplicate.next()) {
                            Model.Object.messagePopUps.duplicateEntryMessage();
                            duplicate = true;
                        } else {
                            for (int i = 0; i < tbl_return.getRowCount(); i++) {
                                if (tbl_return.getValueAt(i, 0).equals(cbo_item_code.getSelectedItem().toString())) {
                                    duplicate = true;
                                    Model.Object.messagePopUps.Duplicate_entry();
                                    break;
                                }
                            }

                        }
                        if (duplicate) {
                            cbo_item_code.setSelectedItem("[ Select ]");
                            lbl_item_description.setText(null);
                            lbl_by_price.setText(null);
                            lbl_by_qty.setText(null);
                            lbl_total_amount.setText(null);
                            lbl_item_discount.setText(null);
                            lbl_net_amount.setText(null);
                            lbl_total_discount.setText(null);
                            lbl_sub_total.setText(null);
                            lbl_return_item_unit_price.setText(null);
                            cbo_return_location.setSelectedItem("WAREHOUSE");
                            txt_return_quantity.setText(null);
                            lbl_item_return_amount.setText(null);
                            lbl_available_stock.setText(null);
                            if (tbl_return.getRowCount() == 0) {
                                txt_grn_code.setText(null);
                                lbl_supplier_code.setText(null);
                                lbl_supplier_name.setText(null);
                                txt_grn_code.setEditable(true);
                                txt_grn_code.grabFocus();
                            } else {
                                cbo_item_code.grabFocus();
                            }
                        } else {
                            DefaultTableModel df = (DefaultTableModel) tbl_return.getModel();
                            Vector v = new Vector();
                            v.add(cbo_item_code.getSelectedItem());
                            v.add(lbl_item_description.getText());
                            v.add(lbl_return_item_unit_price.getText());
                            v.add(txt_return_quantity.getText());
                            v.add(lbl_item_return_amount.getText());
                            v.add(cbo_return_location.getSelectedItem());
                            df.addRow(v);
                            Model.Object.messagePopUps.Data_Added_Successfully();
                            DefaultTableModel df_1 = (DefaultTableModel) tbl_return.getModel();
                            Double return_amount = 0.00;
                            for (int i = 0; i < df_1.getRowCount(); i++) {
                                return_amount = return_amount + Double.parseDouble(df_1.getValueAt(i, 4).toString());
                            }
                            lbl_return_total_amount.setText(Model.Object.Formated.getPriceValue(return_amount));
                            cbo_item_code.setSelectedItem("[ Select ]");
                            lbl_item_description.setText(null);
                            lbl_by_price.setText(null);
                            lbl_by_qty.setText(null);
                            lbl_total_amount.setText(null);
                            lbl_item_discount.setText(null);
                            lbl_net_amount.setText(null);
                            lbl_total_discount.setText(null);
                            lbl_sub_total.setText(null);
                            lbl_available_stock.setText(null);
                            lbl_return_item_unit_price.setText(null);
                            cbo_return_location.setSelectedItem("WAREHOUSE");
                            txt_return_quantity.setText(null);
                            lbl_item_return_amount.setText(null);
                            txt_grn_code.setEnabled(false);
                            cbo_item_code.grabFocus();
                        }
                    }
                }
            } else {
                Model.Object.messagePopUps.invoice_code_doesnot_match();
                txt_grn_code.grabFocus();
            }
        } catch (Exception e) {
            System.out.println("grn return add  " + e);
        }
    }

    public void end_return(JTable tbl_return, JLabel lbl_return_code, JTextField txt_grn_code, JLabel lbl_supplier_code, JLabel lbl_supplier_name, JLabel lbl_return_total_amount) {
        try {
            if (tbl_return.getRowCount() >= 1) {
                DefaultTableModel df = (DefaultTableModel) tbl_return.getModel();
                Double item_count = 0.00;
                for (int i = 0; i < df.getRowCount(); i++) {
                    Double recent_qty = 0.00;
                    ResultSet rset_all_qty = Model.Object.Jdbc.getdata("select* from item_inventory where item_code='" + df.getValueAt(i, 0) + "'");
                    while (rset_all_qty.next()) {
                        recent_qty = recent_qty + rset_all_qty.getDouble(4);
                    }

                    Double location_recent_qty = 0.00;
                    ResultSet rset_location_qty = Model.Object.Jdbc.getdata("select* from item_inventory where item_code='" + df.getValueAt(i, 0) + "' and location='" + df.getValueAt(i, 5) + "'");
                    while (rset_location_qty.next()) {
                        location_recent_qty = rset_location_qty.getDouble(4);
                    }
                    Model.Object.Jdbc.putdata("insert into grn_return_item values('" + lbl_return_code.getText() + "','" + txt_grn_code.getText() + "','" + df.getValueAt(i, 0) + "','" + df.getValueAt(i, 1) + "','" + df.getValueAt(i, 2) + "','" + "Type" + "','" + df.getValueAt(i, 3) + "','" + df.getValueAt(i, 4) + "','" + df.getValueAt(i, 5) + "',NOW(),'" + View.FrmHome2.user_lbl.getText() + "')");
                    Double quanntity = 0.00;
                    ResultSet rset = Model.Object.Jdbc.getdata("select* from item_inventory where item_code='" + df.getValueAt(i, 0) + "' and location='" + df.getValueAt(i, 5) + "'");
                    if (rset.next()) {
                        quanntity = rset.getDouble(4) - Double.parseDouble(df.getValueAt(i, 3).toString());
                        Model.Object.Jdbc.putdata("update item_inventory set stock='" + quanntity + "',last_date_time=NOW(),last_user='" + View.FrmHome2.user_lbl.getText() + "' where item_code='" + df.getValueAt(i, 0) + "' and location='" + df.getValueAt(i, 5) + "'");
                    }
                    item_count = item_count + Double.parseDouble(df.getValueAt(i, 3).toString());

                    Model.Object.Jdbc.putdata("insert into transaction values('" + df.getValueAt(i, 0) + "','" + lbl_return_code.getText() + "',NOW(),'" + recent_qty + "','" + "0.0" + "','" + df.getValueAt(i, 3) + "','" + (recent_qty - Double.parseDouble(df.getValueAt(i, 3).toString())) + "','" + "GRN Return" + "','" + df.getValueAt(i, 5) + "',NOW(),'" + FrmHome2.user_lbl.getText() + "')");
                    Model.Object.Jdbc.putdata("insert into Location_wise_transaction values('" + df.getValueAt(i, 0) + "','" + lbl_return_code.getText() + "',NOW(),'" + location_recent_qty + "','" + "0.0" + "','" + df.getValueAt(i, 3) + "','" + (location_recent_qty - Double.parseDouble(df.getValueAt(i, 3).toString())) + "','" + "GRN Return" + "','" + df.getValueAt(i, 5) + "',NOW(),'" + FrmHome2.user_lbl.getText() + "')");

                }
                Model.Object.Jdbc.putdata("insert into grn_return_balance values('" + lbl_return_code.getText() + "','" + txt_grn_code.getText() + "','" + lbl_supplier_code.getText() + "','" + lbl_supplier_name.getText() + "','" + item_count + "','" + lbl_return_total_amount.getText() + "','" + FrmGrnReturn.return_type + "','" + FrmGrnReturn.new_invo_code + "',NOW(),'" + View.FrmHome2.user_lbl.getText() + "')");
                Model.Object.Jdbc.putdata("insert into grn_return_code values('" + "0" + "')");

                ResultSet rset_payment = Model.Object.Jdbc.getdata("select* from payments where(invoice_or_grn='" + "grn" + "' or invoice_or_grn='" + "Grn Return" + "') and invoice_grn_code='" + txt_grn_code.getText() + "'");
                Double payment = 0.00;
                boolean next = false;
                int pay_status = 0;
                while (rset_payment.next()) {
                    payment = payment + rset_payment.getDouble(6);
                    pay_status = rset_payment.getInt(10);
                    next = true;
                }
                if (next == true) {
                    ResultSet rset_grn = Model.Object.Jdbc.getdata("select* from grn_balance where grn_code='" + txt_grn_code.getText() + "' and payment_type='" + "credit" + "'");
                    if (rset_grn.next()) {
                        Double due_payment = payment;
                        due_payment = due_payment + Double.parseDouble(lbl_return_total_amount.getText());
                        due_payment = rset_grn.getDouble(12) - due_payment;
                        Double sub_total = rset_grn.getDouble(12) - payment;
                        if (pay_status == 1) {
                            Model.Object.messagePopUps.return_invoice_payment(" Your Balance is Rs." + due_payment);
                        } else {
                            Model.Object.Jdbc.putdata("insert into payments values('" + "0" + "','" + "Grn Return" + "','" + txt_grn_code.getText() + "','" + lbl_supplier_code.getText() + "','" + sub_total + "','" + lbl_return_total_amount.getText() + "','" + due_payment + "',NOW(),'" + "Return" + "','" + "0" + "','" + "" + "',NOW(),'" + FrmHome2.user_lbl.getText() + "')");
                        }
                    }
                }

                Model.Object.messagePopUps.saveMessage();
                txt_grn_code.setEnabled(true);
                txt_grn_code.setText("GRN");
                txt_grn_code.grabFocus();
                lbl_supplier_code.setText(null);
                lbl_supplier_name.setText(null);
                df.setRowCount(0);
                FrmGrnReturn.return_type = "Without Grn";
                FrmGrnReturn.new_invo_code = "Without Grn";
                code_gen(lbl_return_code);
                lbl_return_total_amount.setText(null);
            } else {
                Model.Object.messagePopUps.table_empty();
                txt_grn_code.grabFocus();
            }
        } catch (Exception e) {
            System.out.println("Grn Return end_return  " + e);
        }
    }

    public void row_delete(JTable tbl_return, JLabel lbl_return_total_amount) {
        try {
            int u = Model.Object.messagePopUps.do_you_want_delete_record_confirem_msg();
            DefaultTableModel df = (DefaultTableModel) tbl_return.getModel();
            if (u == JOptionPane.YES_OPTION) {
                df.removeRow(tbl_return.getSelectedRow());
                Double amount = 0.00;
                for (int i = 0; i < tbl_return.getRowCount(); i++) {
                    amount = amount + Double.parseDouble(tbl_return.getValueAt(i, 4).toString());
                }
                lbl_return_total_amount.setText(Model.Object.Formated.getPriceValue(amount));
            }
        } catch (Exception e) {
            System.out.println("grn Return row_delete  " + e);
        }
    }
}
