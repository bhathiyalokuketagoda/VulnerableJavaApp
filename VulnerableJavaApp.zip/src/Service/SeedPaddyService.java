/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import View.FrmHome2;
import java.sql.ResultSet;
import java.util.Vector;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author user
 */
public class SeedPaddyService {

    public void search_seedPaddy(JTable tbl_item, JComboBox cbo_type_search, JTextField txt_search_name) {
        try {
            String type = "";
            if (cbo_type_search.getSelectedItem().toString().equals("Seed Paddy")) {
                type = "SPM";
            } else {
                type = "SPD";
            }
            DefaultTableModel df = (DefaultTableModel) tbl_item.getModel();
            df.setRowCount(0);
            ResultSet rset = Model.Object.Jdbc.getdata("select* from item_master where item_description like'" + txt_search_name.getText() + "%' and item_code like'" + type + "%'");
            while (rset.next()) {
                Vector v = new Vector();
                if (String.valueOf(rset.getString(1).charAt(2)).equals("M")) {
                    v.add("Seed Paddy");
                } else {
                    v.add("Product");
                }
                v.add(rset.getString(1));
                v.add(rset.getString(2));
                v.add(rset.getString(7));
                if (String.valueOf(rset.getString(1).charAt(2)).equals("M")) {
                    v.add(rset.getString(5));
                } else {
                    v.add(rset.getString(6));
                }
                ResultSet rset_m = Model.Object.Jdbc.getdata("select* from minimum_qty where  item_code ='" + rset.getString(1) + "'");
                if (rset_m.next()) {
                    v.add(rset_m.getString(2));
                } else {

                }
                df.addRow(v);
            }
        } catch (Exception e) {
            System.out.println("view_all_seedPaddy " + e);
        }
    }

    public void view_all_seedPaddy(JTable tbl_item, JComboBox cbo_type_search) {
        try {
            String type = "";
            if (cbo_type_search.getSelectedItem().toString().equals("Seed Paddy")) {
                type = "SPM";
            } else {
                type = "SPD";
            }
            DefaultTableModel df = (DefaultTableModel) tbl_item.getModel();
            df.setRowCount(0);
            ResultSet rset = Model.Object.Jdbc.getdata("select* from item_master where  item_code like'" + type + "%'");
            while (rset.next()) {
                Vector v = new Vector();
                if (String.valueOf(rset.getString(1).charAt(2)).equals("M")) {
                    v.add("Seed Paddy");
                } else {
                    v.add("Product");
                }
                v.add(rset.getString(1));
                v.add(rset.getString(2));
                v.add(rset.getString(7));
                if (String.valueOf(rset.getString(1).charAt(2)).equals("M")) {
                    v.add(rset.getString(5));
                } else {
                    v.add(rset.getString(6));
                }
                ResultSet rset_m = Model.Object.Jdbc.getdata("select* from minimum_qty where  item_code ='" + rset.getString(1) + "'");
                if (rset_m.next()) {
                    v.add(rset_m.getString(2));
                } else {

                }
                df.addRow(v);
            }
        } catch (Exception e) {
            System.out.println("view_all_seedPaddy " + e);
        }
    }

    public void save_paddy(JComboBox cbo_type, JLabel lbl_code_extenstion, JTextField txt_code, JTextField txt_name, JComboBox cbo_measurement, JTextField txt_purchase_price, JTextField txt_minimum, JTable tbl_item) {
        try {
            if (txt_code.getText() == null || (lbl_code_extenstion.getText() + txt_code.getText()).isEmpty()) {
                Model.Object.messagePopUps.enter_item_code();
                txt_code.grabFocus();
            } else if (txt_name.getText() == null || txt_name.getText().isEmpty()) {
                Model.Object.messagePopUps.enter_item_description();
                txt_name.grabFocus();
            } else if (txt_purchase_price.getText() == null || txt_purchase_price.getText().isEmpty()) {
                if (cbo_type.getSelectedItem().toString().equals("Product")) {
                    Model.Object.messagePopUps.enter_item_sall_pricet();
                    txt_purchase_price.grabFocus();
                } else {
                    Model.Object.messagePopUps.enter_item_purchuse_price();
                    txt_purchase_price.grabFocus();
                }
            } else if (txt_minimum.getText() == null || txt_minimum.getText().isEmpty()) {
                Model.Object.messagePopUps.enter_minimun_qty();
                txt_minimum.grabFocus();
            } else {
                ResultSet rset = Model.Object.Jdbc.getdata("select* from item_master where item_code='" + txt_code.getText() + "'");
                if (rset.next()) {
                    Model.Object.messagePopUps.item_code_duplicate();
                    txt_code.setText(null);
                    txt_name.setText(null);
                    txt_minimum.setText(null);
                    txt_purchase_price.setText(null);
                    txt_code.grabFocus();
                } else {
                    ResultSet rset1 = Model.Object.Jdbc.getdata("select* from item_master where  item_description='" + txt_name.getText() + "'");
                    if (rset1.next()) {
                        Model.Object.messagePopUps.item_name_duplicate();
                        txt_code.setText(null);
                        txt_name.setText(null);
                        txt_minimum.setText(null);
                        txt_purchase_price.setText(null);
                        txt_code.grabFocus();
                    } else {
                        Model.Object.Jdbc.putdata("insert into item_master values('" + (lbl_code_extenstion.getText() + txt_code.getText()) + "','" + txt_name.getText() + "','" + "Default Type" + "','" + txt_purchase_price.getText() + "','" + txt_purchase_price.getText() + "','" + txt_purchase_price.getText() + "','" + cbo_measurement.getSelectedItem() + "','" + "0" + "','" + "0" + "','" + "0" + "','" + "0" + "','" + "0" + "','" + "0" + "','" + "0" + "','" + "0" + "','" + "0" + "','" + "0" + "','" + "0" + "','" + "Supplier Number Not Load" + "',NOW(),'" + FrmHome2.user_lbl.getText() + "')");
                        Model.Object.Jdbc.putdata("insert into minimum_qty values('" + (lbl_code_extenstion.getText() + txt_code.getText()) + "','" + txt_minimum.getText() + "',NOW(),'" + FrmHome2.user_lbl.getText() + "')");
                        Model.Object.messagePopUps.saveMessage();
                        DefaultTableModel df = (DefaultTableModel) tbl_item.getModel();
                        Vector v = new Vector();
                        v.add(cbo_type.getSelectedItem());
                        v.add(lbl_code_extenstion.getText() + txt_code.getText());
                        v.add(txt_name.getText());
                        v.add(cbo_measurement.getSelectedItem());
                        v.add(txt_purchase_price.getText());
                        v.add(txt_minimum.getText());
                        df.addRow(v);
                        txt_code.setText(null);
                        txt_name.setText(null);
                        txt_minimum.setText(null);
                        txt_purchase_price.setText(null);
                        cbo_measurement.setEnabled(true);
                        txt_code.grabFocus();
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("save_paddy " + e);
        }
    }

    public void seed_paddy_code_load(JComboBox cbo_seed_paddy_code) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select item_code from item_master");
            Vector v = new Vector();
            v.add("[ Select ]");
            while (rset.next()) {
                if ((String.valueOf(rset.getString(1).charAt(0)) + String.valueOf(rset.getString(1).charAt(1)) + String.valueOf(rset.getString(1).charAt(2))).equals("SPM")) {
                    v.add(rset.getString(1));
                }
            }
            cbo_seed_paddy_code.setModel(new DefaultComboBoxModel(v));
        } catch (Exception e) {
            System.out.println("seed_paddy_code_load " + e);
        }
    }

    public void production_code_load(JLabel lbl_production_code) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select max(code) from production_code");
            if (rset.next()) {
                lbl_production_code.setText("PRD" + (rset.getInt(1)+1));
            }
        } catch (Exception e) {
            System.out.println("seed_paddy_code_load " + e);
        }
    }

    public void seed_product_code_load(JComboBox cbo_product_code) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select item_code from item_master");
            Vector v = new Vector();
            v.add("[ Select ]");
            while (rset.next()) {
                if ((String.valueOf(rset.getString(1).charAt(0)) + String.valueOf(rset.getString(1).charAt(1)) + String.valueOf(rset.getString(1).charAt(2))).equals("SPD")) {
                    v.add(rset.getString(1));
                }
            }
            cbo_product_code.setModel(new DefaultComboBoxModel(v));
        } catch (Exception e) {
            System.out.println("seed_paddy_code_load " + e);
        }
    }
}
