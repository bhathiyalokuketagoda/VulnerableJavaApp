/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import View.FrmHome2;
import java.sql.ResultSet;
import java.util.Vector;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author user
 */
public class SupplierService {

    public void supplier_code_check(JTextField txt_supplier_code, JTextField txt_supplier_name) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select* from supplier_master where supplier_code='" + txt_supplier_code.getText() + "'");
            if (rset.next()) {
                Model.Object.messagePopUps.suypplier_number_duplicat();
                txt_supplier_code.grabFocus();
                txt_supplier_code.selectAll();
            } else {
                txt_supplier_name.grabFocus();
            }
        } catch (Exception e) {
            System.out.println("supplier_code_check  " + e);
        }
    }

    public void supplier_save(JTextField txt_supplier_code, JTextField txt_supplier_name, JTextField txt_supplier_address, JTextField txt_supplier_company, JTextField txt_supplier_mobile, JTextField txt_supplier_office_tell, JTextField txt_supplier_fax, JTextField txt_supplier_email, JTable tbl_supplier) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select* from supplier_master where supplier_code='" + txt_supplier_code.getText() + "'");
            if (rset.next()) {
                Model.Object.messagePopUps.suypplier_number_duplicat();
                txt_supplier_code.grabFocus();
                txt_supplier_code.selectAll();
            } else {
                Model.Object.Jdbc.putdata("insert into supplier_master values('" + txt_supplier_code.getText() + "','" + txt_supplier_name.getText() + "','" + txt_supplier_address.getText() + "','" + txt_supplier_company.getText() + "','" + txt_supplier_mobile.getText() + "','" + txt_supplier_office_tell.getText() + "','" + txt_supplier_fax.getText() + "','" + txt_supplier_email.getText() + "',NOW(),'" + FrmHome2.user_lbl.getText() + "')");
                Model.Object.messagePopUps.saveMessage();
                DefaultTableModel df = (DefaultTableModel) tbl_supplier.getModel();
                Vector v = new Vector();
                v.add(txt_supplier_code.getText());
                v.add(txt_supplier_name.getText());
                v.add(txt_supplier_address.getText());
                v.add(txt_supplier_company.getText());
                v.add(txt_supplier_mobile.getText());
                v.add(txt_supplier_fax.getText());
                v.add(txt_supplier_office_tell.getText());
                v.add(txt_supplier_email.getText());
                df.addRow(v);
                txt_supplier_address.setText(null);
                txt_supplier_code.setText(null);
                txt_supplier_company.setText(null);
                txt_supplier_email.setText(null);
                txt_supplier_fax.setText(null);
                txt_supplier_mobile.setText(null);
                txt_supplier_name.setText(null);
                txt_supplier_office_tell.setText(null);
                txt_supplier_code.grabFocus();
            }
        } catch (Exception e) {
            System.out.println("supplier_save " + e);
        }
    }

    public void View_all_supplier(JTextField txt_supplier_search_code, JTable tbl_supplier) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select* from supplier_master");
            DefaultTableModel df = (DefaultTableModel) tbl_supplier.getModel();
            df.setRowCount(0);
            while (rset.next()) {
                Vector v = new Vector();
                v.add(rset.getString(1));
                v.add(rset.getString(2));
                v.add(rset.getString(3));
                v.add(rset.getString(4));
                v.add(rset.getString(5));
                v.add(rset.getString(6));
                v.add(rset.getString(7));
                v.add(rset.getString(8));
                df.addRow(v);
            }
        } catch (Exception e) {
            System.out.println("View_all_supplier " + e);
        }
    }

    public void like_suppiler_saerch(JTextField txt_supplier_search_code, JTable tbl_supplier) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select* from supplier_master where supplier_code like'" + txt_supplier_search_code.getText() + "%'");
            DefaultTableModel df = (DefaultTableModel) tbl_supplier.getModel();
            df.setRowCount(0);
            while (rset.next()) {
                Vector v = new Vector();
                v.add(rset.getString(1));
                v.add(rset.getString(2));
                v.add(rset.getString(3));
                v.add(rset.getString(4));
                v.add(rset.getString(5));
                v.add(rset.getString(6));
                v.add(rset.getString(7));
                v.add(rset.getString(8));
                df.addRow(v);
            }
        } catch (Exception e) {
            System.out.println("like_suppiler_saerch " + e);
        }
    }

    public void suppler_table_click(JTextField txt_supplier_code, JTextField txt_supplier_name, JTextField txt_supplier_address, JTextField txt_supplier_company, JTextField txt_supplier_mobile, JTextField txt_supplier_office_tell, JTextField txt_supplier_fax, JTextField txt_supplier_email, JTable tbl_supplier, JButton btn_save, JButton btn_update) {
        try {
            if (Model.Object.messagePopUps.record_update_confirem_msg() == JOptionPane.YES_OPTION) {
                DefaultTableModel df = (DefaultTableModel) tbl_supplier.getModel();
                int i = tbl_supplier.getSelectedRow();
                txt_supplier_code.setText(df.getValueAt(i, 0).toString());
                txt_supplier_code.setEnabled(false);
                txt_supplier_name.setText(df.getValueAt(i, 1).toString());
                txt_supplier_address.setText(df.getValueAt(i, 2).toString());
                txt_supplier_company.setText(df.getValueAt(i, 3).toString());
                txt_supplier_mobile.setText(df.getValueAt(i, 4).toString());
                txt_supplier_office_tell.setText(df.getValueAt(i, 5).toString());
                txt_supplier_fax.setText(df.getValueAt(i, 6).toString());
                txt_supplier_email.setText(df.getValueAt(i, 7).toString());
                btn_save.setEnabled(false);
                btn_update.setEnabled(true);
                txt_supplier_name.grabFocus();
                df.removeRow(i);
            }
        } catch (Exception e) {
            System.out.println("suppler_table_click  " + e);
        }
    }

    public void clear(JTextField txt_supplier_code, JTextField txt_supplier_name, JTextField txt_supplier_address, JTextField txt_supplier_company, JTextField txt_supplier_mobile, JTextField txt_supplier_office_tell, JTextField txt_supplier_fax, JTextField txt_supplier_email, JTable tbl_supplier, JButton btn_save, JButton btn_update) {
        try {
            txt_supplier_address.setText(null);
            txt_supplier_code.setText(null);
            txt_supplier_company.setText(null);
            txt_supplier_email.setText(null);
            txt_supplier_fax.setText(null);
            txt_supplier_mobile.setText(null);
            txt_supplier_name.setText(null);
            txt_supplier_office_tell.setText(null);
            txt_supplier_code.setEnabled(true);
            btn_save.setEnabled(true);
            btn_update.setEnabled(false);
            txt_supplier_code.grabFocus();
        } catch (Exception e) {
            System.out.println("clear  " + e);
        }
    }

    public void supplier_update(JTextField txt_supplier_code, JTextField txt_supplier_name, JTextField txt_supplier_address, JTextField txt_supplier_company, JTextField txt_supplier_mobile, JTextField txt_supplier_office_tell, JTextField txt_supplier_fax, JTextField txt_supplier_email, JTable tbl_supplier, JButton btn_save, JButton btn_update) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select* from supplier_master where supplier_code='" + txt_supplier_code.getText() + "'");
            if (rset.next()) {
                Model.Object.Jdbc.putdata("update supplier_master set name='" + txt_supplier_name.getText() + "', address='" + txt_supplier_address.getText() + "',company='" + txt_supplier_company.getText() + "',mobile='" + txt_supplier_mobile.getText() + "',oficce_tell='" + txt_supplier_office_tell.getText() + "',fax='" + txt_supplier_fax.getText() + "',email='" + txt_supplier_email.getText() + "',date_time=NOW(),user='" + FrmHome2.user_lbl.getText() + "' where supplier_code='" + txt_supplier_code.getText() + "'");
                Model.Object.messagePopUps.record_updated();
                DefaultTableModel df = (DefaultTableModel) tbl_supplier.getModel();
                Vector v = new Vector();
                v.add(txt_supplier_code.getText());
                v.add(txt_supplier_name.getText());
                v.add(txt_supplier_address.getText());
                v.add(txt_supplier_company.getText());
                v.add(txt_supplier_mobile.getText());
                v.add(txt_supplier_fax.getText());
                v.add(txt_supplier_office_tell.getText());
                v.add(txt_supplier_email.getText());
                df.addRow(v);
                txt_supplier_address.setText(null);
                txt_supplier_code.setText(null);
                txt_supplier_company.setText(null);
                txt_supplier_email.setText(null);
                txt_supplier_fax.setText(null);
                txt_supplier_mobile.setText(null);
                txt_supplier_name.setText(null);
                txt_supplier_office_tell.setText(null);
                txt_supplier_code.setEnabled(true);
                btn_save.setEnabled(true);
                btn_update.setEnabled(false);
                txt_supplier_code.grabFocus();

            }
        } catch (Exception e) {
            System.out.println("supplier_update " + e);
        }
    }

    public void supplier_delete(JTable tbl_supplier) {
        try {
            if (Model.Object.messagePopUps.do_you_want_delete_record_confirem_msg() == JOptionPane.YES_OPTION) {
                DefaultTableModel df = (DefaultTableModel) tbl_supplier.getModel();
                int i = tbl_supplier.getSelectedRow();
                Model.Object.Jdbc.putdata("delete from supplier_master where supplier_code='" + df.getValueAt(i, 0) + "'");
                df.removeRow(i);                
            }
        } catch (Exception e) {
             System.out.println("supplier_delete " + e);
        }
    }
}
