/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import java.sql.ResultSet;
import java.util.Vector;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import View.FrmHome2;

/**
 *
 * @author user
 */
public class ItemAjustmentService {

    public void item_load(JList lst_code, JTextField txt_search_item_code) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select* from item_inventory where item_code like'" + txt_search_item_code.getText() + "%' and location='" + "WAREHOUSE" + "'");
            Vector v = new Vector();
            while (rset.next()) {
                v.add(rset.getString(1));
            }
            lst_code.setListData(v);
        } catch (Exception e) {
            System.out.println("ItemAjustmentService  item load  " + e);
        }
    }

    public void item_select(JList lst_code, JLabel lbl_item_code, JLabel lbl_item_description, JLabel lbl_sale_price, JLabel lbl_availale_qty, JComboBox cbo_location) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select* from item_master where item_code='" + lst_code.getSelectedValue() + "'");
            if (rset.next()) {
                lbl_item_code.setText(rset.getString(1));
                lbl_item_description.setText(rset.getString(2));
                lbl_sale_price.setText(rset.getString(6));
                ResultSet rset_qty = Model.Object.Jdbc.getdata("select* from item_inventory where item_code='" + lst_code.getSelectedValue() + "' and location='" + cbo_location.getSelectedItem() + "'");
                if (rset_qty.next()) {
                    lbl_availale_qty.setText(rset_qty.getString(4));
                }
            }
        } catch (Exception e) {
            System.out.println("ItemAjustmentService  item_select  " + e);
        }
    }

    public void location_change(JList lst_code, JLabel lbl_item_code, JLabel lbl_item_description, JLabel lbl_sale_price, JLabel lbl_availale_qty, JComboBox cbo_location) {
        try {
            ResultSet rset_qty = Model.Object.Jdbc.getdata("select* from item_inventory where item_code='" + lst_code.getSelectedValue() + "' and location='" + cbo_location.getSelectedItem() + "'");
            if (rset_qty.next()) {
                lbl_availale_qty.setText(rset_qty.getString(4));
            } else {
                lbl_availale_qty.setText(null);
            }
        } catch (Exception e) {
            System.out.println("ItemAjustmentService  location_change  " + e);
        }
    }

    public void quantity_action(JRadioButton rbtn_deduct, JRadioButton rbtn_add, JLabel lbl_remaining_qty, JButton btn_update, JTextField txt_ajust_qty, JLabel lbl_availale_qty, JLabel lbl_item_code) {
        try {
            if (lbl_item_code.getText().isEmpty()) {
                Model.Object.messagePopUps.item_cost_is_empty();
                lbl_remaining_qty.setText(null);
            } else if (lbl_availale_qty.getText().isEmpty()) {
                Model.Object.messagePopUps.available_quantity_is_empty();
                lbl_remaining_qty.setText(null);
            } else if (txt_ajust_qty.getText().isEmpty()) {
                Model.Object.messagePopUps.Quantity_Empty();
                lbl_remaining_qty.setText(null);
                txt_ajust_qty.grabFocus();
            } else {
                if (rbtn_deduct.isSelected()) {
                    lbl_remaining_qty.setText(String.valueOf(Double.parseDouble(lbl_availale_qty.getText()) - Double.parseDouble(txt_ajust_qty.getText())));
                    btn_update.grabFocus();
                } else {
                    lbl_remaining_qty.setText(String.valueOf(Double.parseDouble(lbl_availale_qty.getText()) + Double.parseDouble(txt_ajust_qty.getText())));
                    btn_update.grabFocus();
                }
            }
        } catch (Exception e) {
            System.out.println("ItemAjustmentService  quantity_action  " + e);
        }
    }

    public void upadate(JLabel lbl_availale_qty, JTextField txt_ajust_qty, JRadioButton rbtn_deduct, JLabel lbl_sale_price, JLabel lbl_item_description, JComboBox cbo_location, JLabel lbl_item_code, JLabel lbl_remaining_qty) {
        try {
            if (lbl_item_code.getText().isEmpty()) {
                Model.Object.messagePopUps.item_cost_is_empty();
                lbl_remaining_qty.setText(null);
            } else if (lbl_availale_qty.getText().isEmpty()) {
                Model.Object.messagePopUps.available_quantity_is_empty();
                lbl_remaining_qty.setText(null);
            } else if (txt_ajust_qty.getText().isEmpty()) {
                Model.Object.messagePopUps.Quantity_Empty();
                lbl_remaining_qty.setText(null);
                txt_ajust_qty.grabFocus();
            } else {
                ResultSet rset = Model.Object.Jdbc.getdata("select* from item_inventory where item_code='" + lbl_item_code.getText() + "' and location='" + cbo_location.getSelectedItem() + "'");
                if (rset.next()) {
                    Double recent_qty = 0.00;
                    ResultSet rset_all_qty = Model.Object.Jdbc.getdata("select* from item_inventory where item_code='" + lbl_item_code.getText() + "'");
                    while (rset_all_qty.next()) {
                        recent_qty = recent_qty + rset_all_qty.getDouble(4);
                    }

                    Double location_recent_qty = 0.00;
                    ResultSet rset_location_qty = Model.Object.Jdbc.getdata("select* from item_inventory where item_code='" + lbl_item_code.getText() + "' and location='" + cbo_location.getSelectedItem() + "'");
                    while (rset_location_qty.next()) {
                        location_recent_qty = rset_location_qty.getDouble(4);
                    }
                    String code = "";
                    ResultSet rset_code = Model.Object.Jdbc.getdata("select max(code) from item_adjust_code");
                    if (rset_code.next()) {
                        code = "AJC" + rset_code.getInt(1) + 1;
                    }
                    String type = "Deduct";
                    if (rbtn_deduct.isSelected()) {
                        type = "Deduct";
                        Model.Object.Jdbc.putdata("insert into transaction values('" + lbl_item_code.getText() + "','" + code + "',NOW(),'" + recent_qty + "','" + "0.0" + "','" + txt_ajust_qty.getText() + "','" + (recent_qty - Double.parseDouble(txt_ajust_qty.getText())) + "','" + "Inventory Adjustment" + "','" + cbo_location.getSelectedItem() + "',NOW(),'" + FrmHome2.user_lbl.getText() + "')");
                        Model.Object.Jdbc.putdata("insert into Location_wise_transaction values('" + lbl_item_code.getText() + "','" + code + "',NOW(),'" + location_recent_qty + "','" + "0.0" + "','" + txt_ajust_qty.getText() + "','" + (location_recent_qty - Double.parseDouble(txt_ajust_qty.getText())) + "','" + "Inventory Adjustment" + "','" + cbo_location.getSelectedItem() + "',NOW(),'" + FrmHome2.user_lbl.getText() + "')");

                    } else {
                        type = "Add";
                        Model.Object.Jdbc.putdata("insert into transaction values('" + lbl_item_code.getText() + "','" + code + "',NOW(),'" + recent_qty + "','" + txt_ajust_qty.getText() + "','" + "0.0" + "','" + (recent_qty + Double.parseDouble(txt_ajust_qty.getText())) + "','" + "Inventory Adjustment" + "','" + cbo_location.getSelectedItem() + "',NOW(),'" + FrmHome2.user_lbl.getText() + "')");
                        Model.Object.Jdbc.putdata("insert into Location_wise_transaction values('" + lbl_item_code.getText() + "','" + code + "',NOW(),'" + location_recent_qty + "','" + txt_ajust_qty.getText() + "','" + "0.0" + "','" + (location_recent_qty + Double.parseDouble(txt_ajust_qty.getText())) + "','" + "Inventory Adjustment" + "','" + cbo_location.getSelectedItem() + "',NOW(),'" + FrmHome2.user_lbl.getText() + "')");

                    }

                    Model.Object.Jdbc.putdata("update item_inventory set stock='" + lbl_remaining_qty.getText() + "',last_date_time=NOW(),last_user='" + FrmHome2.user_lbl.getText() + "' where item_code='" + lbl_item_code.getText() + "' and location='" + cbo_location.getSelectedItem() + "'");
                    Model.Object.Jdbc.putdata("insert into item_adjustment values('" + code + "','" + lbl_item_code.getText() + "','" + lbl_item_description.getText() + "','" + type + "','" + cbo_location.getSelectedItem() + "','" + lbl_availale_qty.getText() + "','" + txt_ajust_qty.getText() + "','" + lbl_remaining_qty.getText() + "',NOW(),'" + FrmHome2.user_lbl.getText() + "')");
                    Model.Object.Jdbc.putdata("insert into item_adjust_code values('" + "0" + "')");
                    Model.Object.messagePopUps.record_updated();
                    lbl_item_code.setText(null);
                    lbl_remaining_qty.setText(null);
                    lbl_item_description.setText(null);
                    lbl_sale_price.setText(null);
                    lbl_availale_qty.setText(null);
                    rbtn_deduct.setSelected(true);
                    txt_ajust_qty.setText(null);
                    cbo_location.setSelectedItem("WAREHOUSE");
                } else {
                    Model.Object.messagePopUps.Item_number_dosesnot_match();
                    lbl_item_code.setText(null);
                    lbl_remaining_qty.setText(null);
                    lbl_item_description.setText(null);
                    lbl_sale_price.setText(null);
                    rbtn_deduct.setSelected(true);
                    lbl_availale_qty.setText(null);
                    txt_ajust_qty.setText(null);
                    cbo_location.setSelectedItem("WAREHOUSE");
                }
            }
        } catch (Exception e) {
            System.out.println("ItemAjustmentService  upadate  " + e);
        }
    }
}
