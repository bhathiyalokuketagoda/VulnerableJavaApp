/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import View.FrmHome2;
import java.sql.ResultSet;
import java.util.Vector;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JTextField;

/**
 *
 * @author user
 */
public class PastGrn {

    public void load_past_grn_number(JList lst_invoice_number) {
        try {
            ResultSet rset1 = Model.Object.Jdbc.getdata("select Admin from user_login where UserGroup='" + FrmHome2.group + "'");
            if (rset1.next()) {
                if (rset1.getString(1).equals("Admin") || (Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Outlet") == true && Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Warehouse") == true)) {
                    Vector v = new Vector();
                    lst_invoice_number.setListData(v);
                    ResultSet rset = Model.Object.Jdbc.getdata("select supplier_invoice_code from grn_balance");
                    while (rset.next()) {
                        v.add(rset.getString(1));
                    }
                    lst_invoice_number.setListData(v);
                    //admin

                } else if (Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Outlet") == true) {
                    Vector v = new Vector();
                    lst_invoice_number.setListData(v);
                    ResultSet rset = Model.Object.Jdbc.getdata("select supplier_invoice_code from grn_balance where location='" + "OUTLET" + "'");
                    while (rset.next()) {
                        v.add(rset.getString(1));
                    }
                    lst_invoice_number.setListData(v);
                    //outlet

                } else if (Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Warehouse") == true) {
                    Vector v = new Vector();
                    lst_invoice_number.setListData(v);
                    ResultSet rset = Model.Object.Jdbc.getdata("select supplier_invoice_code from grn_balance where location='" + "WAREHOUSE" + "'");
                    while (rset.next()) {
                        v.add(rset.getString(1));
                    }
                    lst_invoice_number.setListData(v);
                    //wherhouse
                }
            }

        } catch (Exception e) {
            System.out.println("load_past_grn_number()  " + e);
        }
    }

    public void search_past_grn_number(JList lst_invoice_number, JTextField txtgrnNo) {
        try {
            ResultSet rset1 = Model.Object.Jdbc.getdata("select Admin from user_login where UserGroup='" + FrmHome2.group + "'");
            if (rset1.next()) {
                if (rset1.getString(1).equals("Admin") || (Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Outlet") == true && Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Warehouse") == true)) {
                    Vector v = new Vector();
                    lst_invoice_number.setListData(v);
                    ResultSet rset = Model.Object.Jdbc.getdata("select supplier_invoice_code from grn_balance where supplier_invoice_code like'" + txtgrnNo.getText() + "%' order by LPAD(lower(supplier_invoice_code), 10,0) ASC ");
                    while (rset.next()) {
                        v.add(rset.getString(1));
                    }
                    lst_invoice_number.setListData(v);
                    //admin

                } else if (Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Outlet") == true) {
                    Vector v = new Vector();
                    lst_invoice_number.setListData(v);
                    ResultSet rset = Model.Object.Jdbc.getdata("select supplier_invoice_code from grn_balance where location='" + "OUTLET" + "' and supplier_invoice_code like'" + txtgrnNo.getText() + "%' order by LPAD(lower(supplier_invoice_code), 10,0) ASC ");
                    while (rset.next()) {
                        v.add(rset.getString(1));
                    }
                    lst_invoice_number.setListData(v);
                    //outlet

                } else if (Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Warehouse") == true) {
                    Vector v = new Vector();
                    lst_invoice_number.setListData(v);
                    ResultSet rset = Model.Object.Jdbc.getdata("select supplier_invoice_code from grn_balance where location='" + "WAREHOUSE" + "' and supplier_invoice_code like'" + txtgrnNo.getText() + "%' order by LPAD(lower(supplier_invoice_code), 10,0) ASC ");
                    while (rset.next()) {
                        v.add(rset.getString(1));
                    }
                    lst_invoice_number.setListData(v);
                    //wherhouse
                }
            }

        } catch (Exception e) {
            System.out.println("search_past_grn_number()  " + e);
        }
    }

    public void search_past_grn_number_supplierwise(JList lst_invoice_number, JTextField txt_suppName) {
        try {
            ResultSet rset1 = Model.Object.Jdbc.getdata("select Admin from user_login where UserGroup='" + FrmHome2.group + "'");
            if (rset1.next()) {
                if (rset1.getString(1).equals("Admin") || (Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Outlet") == true && Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Warehouse") == true)) {
                    Vector v = new Vector();
                    lst_invoice_number.setListData(v);
                    ResultSet rset = Model.Object.Jdbc.getdata("SELECT grn_balance.supplier_invoice_code FROM grn_balance INNER JOIN supplier_master ON grn_balance.supplier_code = supplier_master.supplier_code WHERE  supplier_master.name like'" + txt_suppName.getText() + "%' order by LPAD(lower(grn_balance.supplier_invoice_code), 10,0) ASC ");
                    while (rset.next()) {
                        v.add(rset.getString(1));
                    }
                    lst_invoice_number.setListData(v);
                    //admin

                } else if (Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Outlet") == true) {
                    Vector v = new Vector();
                    lst_invoice_number.setListData(v);
                    ResultSet rset = Model.Object.Jdbc.getdata("SELECT grn_balance.supplier_invoice_code FROM grn_balance INNER JOIN supplier_master ON grn_balance.supplier_code = supplier_master.supplier_code WHERE grn_balance.location='"+"OUTLET"+"' AND supplier_master.name like '"+txt_suppName.getText()+"%' order by LPAD(lower(grn_balance.supplier_invoice_code), 10,0) ASC");
                    while (rset.next()) {
                        v.add(rset.getString(1));
                    }
                    lst_invoice_number.setListData(v);
                    //outlet

                } else if (Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Warehouse") == true) {
                    Vector v = new Vector();
                    lst_invoice_number.setListData(v);
               ResultSet rset = Model.Object.Jdbc.getdata("SELECT grn_balance.supplier_invoice_code FROM grn_balance INNER JOIN supplier_master ON grn_balance.supplier_code = supplier_master.supplier_code WHERE grn_balance.location='WAREHOUSE' AND supplier_master.name like '"+txt_suppName.getText()+"%' order by LPAD(lower(grn_balance.supplier_invoice_code), 10,0) ASC");
                    while (rset.next()) {
                        v.add(rset.getString(1));
                    }
                    lst_invoice_number.setListData(v);
                    //wherhouse
                }
            }

        } catch (Exception e) {
            System.out.println("search_past_grn_number()  " + e);
        }
    }

    public void select_code(String grn_number, JLabel lbl_supplier, JLabel lbl_grn_date, JLabel lbl_amount, JLabel lbl_pay_type) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select* from grn_balance where supplier_invoice_code='" + grn_number + "'");
            if (rset.next()) {
                ResultSet rset_c = Model.Object.Jdbc.getdata("select* from supplier_master where supplier_code='" + rset.getString(2) + "'");
                if (rset_c.next()) {
                    lbl_supplier.setText(rset_c.getString(2));
                } else {
                    lbl_supplier.setText("Unknown Customer");
                }
                lbl_grn_date.setText(rset.getString(6));
                lbl_pay_type.setText(rset.getString(13));
                lbl_amount.setText(rset.getString(12));
            }
        } catch (Exception e) {
            System.out.println(" past invoice    select_code()   " + e);
        }
    }
}
