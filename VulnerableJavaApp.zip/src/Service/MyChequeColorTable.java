/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import java.awt.Color;
import java.awt.Component;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

/**
 *
 * @author user
 */
public class MyChequeColorTable extends DefaultTableCellRenderer {

    public MyChequeColorTable() {
        setOpaque(true);
    }

    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        // String number = (String) value;
        // int val = Integer.parseInt(number);
        if (table.getValueAt(row, 5).toString().equals("1")) {
            setBackground(Color.red);
        } else if (table.getValueAt(row, 5).toString().equals("2")) {
            setBackground(Color.ORANGE);
        } else {
            setBackground(Color.WHITE);
        }
       setText(value != null ? value.toString() : "");
        return this;
    }

}
