/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import View.FrmCheque;

import java.sql.ResultSet;
import java.util.Vector;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import View.FrmHome2;

/**
 *
 * @author user
 */
public class ChequeService {

    public static void invoic_search(JLabel lbl_customer_code, JTextField txt_invoice_number, JLabel lbl_invoice_amount, JLabel lbl_invoice_date, JRadioButton btn_invoice, JRadioButton btn_grn, JLabel lbl_customer_name) {
        try {
            if (btn_invoice.isSelected()) {
                ResultSet rset_invoice = Model.Object.Jdbc.getdata("select* from invoice_balance where invoice_code='" + txt_invoice_number.getText() + "' and payment_type='" + "Credit" + "' and invoice_status='" + "0" + "'");
                if (rset_invoice.next()) {
                    ResultSet rset_payment = Model.Object.Jdbc.getdata("select* from payments where invoice_grn_code='" + txt_invoice_number.getText() + "' and( invoice_or_grn='" + "invoice" + "' or invoice_or_grn='" + "invoice Return" + "')");
                    Double d = 0.00;
                    while (rset_payment.next()) {
                        d = d + rset_payment.getDouble(6);
                    }
                    lbl_invoice_amount.setText(Model.Object.Formated.getPriceValue(rset_invoice.getDouble(9) - d));
                    lbl_invoice_date.setText(rset_invoice.getString(3));
                    ResultSet rset_customer = Model.Object.Jdbc.getdata("select* from customer_master where customer_code='" + rset_invoice.getString(2) + "'");
                    if (rset_customer.next()) {
                        lbl_customer_name.setText(rset_customer.getString(2));
                        lbl_customer_code.setText(rset_customer.getString(1));
                    } else {
                        lbl_customer_code.setText("No Customer");
                        lbl_customer_name.setText("No Customer");
                    }
                } else {
                    Model.Object.messagePopUps.cannt_find_invoice_credit_details();
                    lbl_invoice_amount.setText(null);
                    lbl_invoice_date.setText(null);
                    lbl_customer_name.setText(null);
                    txt_invoice_number.setText(null);
                    txt_invoice_number.grabFocus();
                }
            } else if (btn_grn.isSelected()) {
                ResultSet rset = Model.Object.Jdbc.getdata("select* from grn_balance where grn_code='" + txt_invoice_number.getText() + "' and payment_type='" + "Credit" + "' and grn_status='" + "0" + "'");
                if (rset.next()) {
                    ResultSet rset_payment = Model.Object.Jdbc.getdata("select* from payments where invoice_grn_code='" + txt_invoice_number.getText() + "'and (invoice_or_grn='" + "grn" + "' or invoice_or_grn='" + "Grn Return" + "' )");
                    Double d = 0.00;
                    while (rset_payment.next()) {
                        d = d + rset_payment.getDouble(6);
                    }
                    lbl_invoice_amount.setText(Model.Object.Formated.getPriceValue(rset.getDouble(12) - d));
                    lbl_invoice_date.setText(rset.getString(4));
                    ResultSet rset_supplier = Model.Object.Jdbc.getdata("select* from supplier_master where supplier_code='" + rset.getString(2) + "'");
                    if (rset_supplier.next()) {
                        lbl_customer_name.setText(rset_supplier.getString(2));
                        lbl_customer_code.setText(rset_supplier.getString(1));
                    } else {
                        lbl_customer_code.setText("No Supplier");
                        lbl_customer_name.setText("No Supplier");
                    }
                } else {
                    Model.Object.messagePopUps.cannt_find_grn_credit_details();
                    lbl_invoice_amount.setText(null);
                    lbl_invoice_date.setText(null);
                    lbl_customer_name.setText(null);
                    txt_invoice_number.setText(null);
                    txt_invoice_number.grabFocus();
                }
            } else {
                Model.Object.messagePopUps.select_invoice_or_grn();
                btn_invoice.grabFocus();
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void add_invoice(JTable tbl_invoice_collect, JTextField txt_invoice_number, JLabel lbl_invoice_amount, JLabel lbl_invoice_date, JLabel lbl_customer_name, JLabel lbl_total_invoice_amount, JRadioButton btn_invoice, JRadioButton btn_grn) {
        try {
            DefaultTableModel df = (DefaultTableModel) tbl_invoice_collect.getModel();
            if (txt_invoice_number.getText().isEmpty() || txt_invoice_number.getText() == null) {
                Model.Object.messagePopUps.enter_invoice_code();
                txt_invoice_number.grabFocus();
            } else if (lbl_invoice_amount.getText().isEmpty() || lbl_invoice_amount.getText() == null) {
                Model.Object.messagePopUps.invoice_amount_empty();
                txt_invoice_number.grabFocus();
            } else {
                boolean bool = false;
                for (int i = 0; i < df.getRowCount(); i++) {
                    if (df.getValueAt(i, 0).toString().equals("Invoice")) {
                        if (df.getValueAt(i, 1).toString().equals(txt_invoice_number.getText())) {
                            bool = true;
                            break;
                        }
                    }
                }
                if (bool) {
                    Model.Object.messagePopUps.Duplicate_entry();
                    lbl_customer_name.setText(null);
                    lbl_invoice_date.setText(null);
                    txt_invoice_number.setText(null);
                    txt_invoice_number.grabFocus();
                } else {
                    boolean bool_1 = false;
                    if (View.FrmCheque.customer_cheque.equals("no")) {
                        bool_1 = false;
                    } else {
                        if (View.FrmCheque.customer_cheque.equals(lbl_customer_name.getText())) {
                            bool_1 = false;
                        } else {
                            bool_1 = true;
                        }
                    }
                    if (bool_1) {
                        Model.Object.messagePopUps.customer_not_match();
                        lbl_invoice_amount.setText(null);
                        lbl_invoice_date.setText(null);
                        txt_invoice_number.setText(null);
                        txt_invoice_number.grabFocus();
                    } else {
                        Vector v = new Vector();
                        if (btn_grn.isSelected()) {
                            v.add("Grn");
                        } else {
                            v.add("Invoice");
                        }
                        v.add(txt_invoice_number.getText());
                        v.add(lbl_invoice_date.getText());
                        v.add(lbl_invoice_amount.getText());
                        df.addRow(v);
                        Double invoice_amount = 0.00;
                        for (int i = 0; i < tbl_invoice_collect.getRowCount(); i++) {
                            invoice_amount = invoice_amount + Double.parseDouble(tbl_invoice_collect.getValueAt(i, 3).toString());
                        }
                        lbl_total_invoice_amount.setText(Model.Object.Formated.getPriceValue(invoice_amount));
                        View.FrmCheque.customer_cheque = lbl_customer_name.getText();
                        Model.Object.messagePopUps.Data_Added_Successfully();
                        btn_grn.setEnabled(false);
                        btn_invoice.setEnabled(false);
                        lbl_invoice_amount.setText(null);
                        lbl_invoice_date.setText(null);
                        txt_invoice_number.setText(null);
                        txt_invoice_number.grabFocus();
                    }
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void cheque_add(JTextField txt_cheque_number, JComboBox cbo_bank_name, JTextField txt_chque_date, JTextField txt_chque_amount, JLabel lbl_type, JLabel lbl_cheque_status, JTable tbl_invoice_collect, JTable tbl_cheque_detail, JLabel lbl_total_cheque_amount) {
        try {
            if (tbl_invoice_collect.getRowCount() == 0) {
                Model.Object.messagePopUps.cannt_find_invoice_credit_details();
            } else if (txt_cheque_number.getText().isEmpty()) {
                Model.Object.messagePopUps.enter_cheque_number();
                txt_cheque_number.grabFocus();
            } else if (txt_chque_date.getText().isEmpty()) {
                Model.Object.messagePopUps.enter_cheque_date();
                txt_chque_date.grabFocus();
            } else if (txt_chque_amount.getText().isEmpty()) {
                Model.Object.messagePopUps.enter_cheque_amount();
                txt_chque_amount.grabFocus();
            } else {
                boolean bool = false;
                for (int i = 0; i < tbl_cheque_detail.getRowCount(); i++) {
                    if (tbl_cheque_detail.getValueAt(i, 0).toString().equals(txt_cheque_number.getText())) {
                        bool = true;
                        break;
                    }
                }
                if (bool) {
                    Model.Object.messagePopUps.Duplicate_entry();
                    cbo_bank_name.setSelectedItem("Axis Bank Ltd.");
                    txt_cheque_number.setText(null);
                    txt_chque_amount.setText(null);
                    txt_chque_date.setText(Model.Object.Formated.todayDate());
                    txt_cheque_number.grabFocus();
                } else {
                    ResultSet rset_ch_check = Model.Object.Jdbc.getdata("select* from cheque where cheque_number='" + txt_cheque_number.getText() + "'");
                    if (rset_ch_check.next()) {
                        Model.Object.messagePopUps.Duplicate_cheque();
                        txt_cheque_number.grabFocus();
                    } else {
                        DefaultTableModel df = (DefaultTableModel) tbl_cheque_detail.getModel();
                        Vector v = new Vector();
                        v.add(txt_cheque_number.getText());
                        v.add(cbo_bank_name.getSelectedItem());
                        v.add(txt_chque_date.getText());
                        v.add(txt_chque_amount.getText());
                        v.add(lbl_type.getText());
                        v.add(lbl_cheque_status.getText());
                        df.addRow(v);
                        Double ch_amo = 0.00;
                        for (int i = 0; i < tbl_cheque_detail.getRowCount(); i++) {
                            ch_amo = ch_amo + Double.parseDouble(tbl_cheque_detail.getValueAt(i, 3).toString());
                        }
                        Model.Object.messagePopUps.Data_Added_Successfully();
                        lbl_total_cheque_amount.setText(Model.Object.Formated.getPriceValue(ch_amo));
                        cbo_bank_name.setSelectedItem("Axis Bank Ltd.");
                        txt_cheque_number.setText(null);
                        txt_chque_amount.setText(null);
                        txt_chque_date.setText(Model.Object.Formated.todayDate());
                        txt_cheque_number.grabFocus();
                    }
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void save_cheque(JLabel lbl_customer_code, JLabel lbl_customer_name, JTable tbl_invoice_collect, JTable tbl_cheque_detail, JLabel lbl_total_invoice_amount, JLabel lbl_total_cheque_amount, JRadioButton btn_grn, JRadioButton btn_invoice, JTextField txt_cheque_number) {
        try {
            boolean bool = true;
            if (lbl_customer_name.getText().isEmpty()) {
                Model.Object.messagePopUps.customer_name_empty_cheque();
            } else if (tbl_invoice_collect.getRowCount() == 0) {
                Model.Object.messagePopUps.cannt_find_invoice_credit_details();
            } else if (tbl_cheque_detail.getRowCount() == 0) {
                Model.Object.messagePopUps.cheque_details_empty();
            } else {
                if (Double.parseDouble(lbl_total_invoice_amount.getText()) > (Double.parseDouble(lbl_total_cheque_amount.getText()))) {
                    Model.Object.messagePopUps.paymet_low();
                    bool = true;
                } else if (Double.parseDouble(lbl_total_invoice_amount.getText()) < (Double.parseDouble(lbl_total_cheque_amount.getText()))) {
                    Model.Object.messagePopUps.paymet_High();
                    bool = true;
                } else {
                    bool = false;
                }

            }
            if (bool) {
            } else {
                String number = "";
                for (int i = 0; i < tbl_invoice_collect.getRowCount(); i++) {
                    if (i + 1 == tbl_invoice_collect.getRowCount()) {
                        number = number + tbl_invoice_collect.getValueAt(i, 1).toString();
                    } else {
                        number = tbl_invoice_collect.getValueAt(i, 1) + "&" + number;
                    }
                }
                for (int i = 0; i < tbl_cheque_detail.getRowCount(); i++) {
                    Model.Object.Jdbc.putdata("insert into cheque values ('" + number + "','" + tbl_cheque_detail.getValueAt(i, 0) + "','" + lbl_customer_code.getText() + "','" + tbl_cheque_detail.getValueAt(i, 1) + "','" + tbl_cheque_detail.getValueAt(i, 2) + "','" + tbl_cheque_detail.getValueAt(i, 3) + "','" + tbl_cheque_detail.getValueAt(i, 5) + "','" + "" + "','" + tbl_cheque_detail.getValueAt(i, 4) + "',NOW(),'" + FrmHome2.user_lbl.getText() + "')");
                }
                String grn_invoice_type = "";
                if (btn_grn.isSelected()) {
                    grn_invoice_type = "grn";
                } else {
                    grn_invoice_type = "invoice";
                }
                DefaultTableModel df_invoice = (DefaultTableModel) tbl_invoice_collect.getModel();
                for (int i = 0; i < tbl_invoice_collect.getRowCount(); i++) {
                    Model.Object.Jdbc.putdata("insert into payments values ('0','" + grn_invoice_type + "','" + df_invoice.getValueAt(i, 1) + "','" + lbl_customer_code.getText() + "','" + df_invoice.getValueAt(i, 3) + "','" + df_invoice.getValueAt(i, 3) + "','" + "0" + "',NOW(),'Cheque','0','" + "" + "',NOW(),'" + FrmHome2.user_lbl.getText() + "')");
                    if (btn_invoice.isSelected()) {
                       // infoims.Object.Jdbc.putdata("update payments set payment_status='" + "1" + "' where invoice_or_grn='" + "invoice" + "' and invoice_grn_code='" + df_invoice.getValueAt(i, 1) + "'");
                    } else {
                        //infoims.Object.Jdbc.putdata("update payments set payment_status='" + "1" + "' where invoice_or_grn='" + "grn" + "' and invoice_grn_code='" + df_invoice.getValueAt(i, 1) + "'");
                    }
                }
                if (tbl_cheque_detail.getValueAt(0, 4).toString().equals("Invoice")) {
                    Model.Object.paymentVeryfication.save_new(lbl_customer_code.getText().toString(), number, lbl_customer_name.getText(), "From a " + lbl_customer_name.getText() + " Payment of Rs." + lbl_total_cheque_amount.getText() + " by Cheque", "Invoice");
                } else {
                    Model.Object.paymentVeryfication.save_new(lbl_customer_code.getText(), number, lbl_customer_name.getText(), "From a " + lbl_customer_name.getText() + " Payment of Rs." + lbl_total_cheque_amount.getText() + " by Cheque", "Good Received");
                }
                Model.Object.messagePopUps.saveMessage();
                btn_grn.setEnabled(true);
                btn_invoice.setEnabled(true);
                lbl_customer_name.setText(null);
                View.FrmCheque.customer_cheque = "no";
                DefaultTableModel df = (DefaultTableModel) tbl_cheque_detail.getModel();
                DefaultTableModel df_1 = (DefaultTableModel) tbl_invoice_collect.getModel();
                df.setRowCount(0);
                df_1.setRowCount(0);
                lbl_total_cheque_amount.setText("0.00");
                lbl_total_invoice_amount.setText("0.00");
            }
        } catch (Exception e) {
            System.out.println(e);
        }

    }

    private String getStartDate() {
        String startDate = JOptionPane.showInputDialog("Start Date", Model.Object.Formated.todayDate());
        return startDate;
    }

    private String getEndDate() {
        String endDate = JOptionPane.showInputDialog("End Date", Model.Object.Formated.todayDate());
        return endDate;
    }

    public void cheque_list(JList cheque_number_lst) {
        try {
            Vector v = new Vector();
            String start_date = getStartDate();
            String end_date = getEndDate();
            ResultSet rset = Model.Object.Jdbc.getdata("select* from cheque where ch_status='" + "Pending" + "' and cheque_date between'" + start_date + "' and '" + end_date + "'");
            while (rset.next()) {
                v.add(rset.getString(2));
            }
            cheque_number_lst.setListData(v);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void cheque_list_select(JTabbedPane cheque_tabb_tbp, JLabel invoice_number, JLabel Customer_lbl, JLabel cheque_number_lbl, JLabel bank_name_lbl, JLabel cheque_date_lbl, JLabel amount_lbl, JComboBox cheque_status_cbo, JList cheque_number_lst, JLabel invoice_grn_lbl) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select* from cheque where cheque_number='" + cheque_number_lst.getSelectedValue() + "'");
            if (rset.next()) {
                invoice_grn_lbl.setText(rset.getString(9));
                invoice_number.setText(rset.getString(1));
                Customer_lbl.setText(rset.getString(3));
                cheque_number_lbl.setText(rset.getString(2));
                if (cheque_tabb_tbp.getSelectedIndex() == 2) {
                    FrmCheque.old_cheque_number = rset.getString(2);
                } else {
                    FrmCheque.old_cheque_number = null;
                }
                bank_name_lbl.setText(rset.getString(4));
                cheque_date_lbl.setText(rset.getString(5));
                amount_lbl.setText(rset.getString(6));
                cheque_status_cbo.setSelectedItem(rset.getString(7));
            }
        } catch (Exception e) {
            System.out.println("cheque_list_select  " + e);
        }
    }

    public void number_validation(JTextField txt_chque_amount) {
        try {
            Double d = 0.00;
            if (txt_chque_amount.getText().isEmpty()) {
            } else {
                d = Double.parseDouble(txt_chque_amount.getText());
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid Number Format");
            txt_chque_amount.grabFocus();
            txt_chque_amount.setText(null);
        } catch (Exception e) {

        }
    }

    public void Update_cheque(JComboBox cheque_status_cbo, JLabel invoice_number, JLabel Customer_lbl, JLabel cheque_number_lbl, JLabel bank_name_lbl, JLabel cheque_date_lbl, JLabel amount_lbl, JLabel invoice_grn_lbl, JList cheque_number_lst) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select* from cheque where cheque_number='" + cheque_number_lbl.getText() + "'");
            if (rset.next()) {
                String in_grn = "";
                if (invoice_grn_lbl.getText().equals("Invoice")) {
                    in_grn = "Invoice";
                } else {
                    in_grn = "Grn";
                }
                if (cheque_status_cbo.getSelectedItem().toString().equals("Unrealised")) {
                    String unrealised_Date = JOptionPane.showInputDialog("Unrealised Date", "2014-12-02");
                    Model.Object.Jdbc.putdata("update cheque set ch_status='" + "Unrealised" + "', close_date='" + unrealised_Date + "' where cheque_number='" + cheque_number_lbl.getText() + "' and grn_or_invoice='" + in_grn + "'");
                    JOptionPane.showMessageDialog(null, "Record Updated Successfully");
                    invoice_grn_lbl.setText(null);
                    invoice_number.setText(null);
                    Customer_lbl.setText(null);
                    cheque_number_lbl.setText(null);
                    bank_name_lbl.setText(null);
                    cheque_date_lbl.setText(null);
                    amount_lbl.setText(null);
                    cheque_status_cbo.setSelectedItem("Realised");
                    Vector v = new Vector();
                    cheque_number_lst.setListData(v);
                } else {
                    String close_Date = JOptionPane.showInputDialog("Realised Date", Model.Object.Formated.todayDate());
                    Model.Object.Jdbc.putdata("update cheque set ch_status='" + cheque_status_cbo.getSelectedItem().toString() + "', close_date='" + close_Date + "' where cheque_number='" + cheque_number_lbl.getText() + "'");
                    if (invoice_grn_lbl.getText().equals("Invoice")) {
                        int count = 0;
                        ResultSet rset_peding_cheque_check = Model.Object.Jdbc.getdata("select* from cheque where invoiceno='" + invoice_number.getText() + "' and ch_status='" + "Pending" + "' and grn_or_invoice='" + "Invoice" + "'");
                        while (rset_peding_cheque_check.next()) {
                            count++;
                        }
                        if (1 < count) {

                        } else {
                            String number = "";
                            String number_1 = "";

                            String word = invoice_number.getText();
                            String guess = "&";
                            int index = word.indexOf(guess);
                            int index_count = 0;
                            while (index >= 0) {
                                index = word.indexOf(guess, index + 1);
                                index_count = index_count + 1;
                            }
                            int q = 0;
                            String s = invoice_number.getText();
                            System.out.println("next == ");
                            for (q = 0; q < s.length(); q++) {
                                if (String.valueOf(s.charAt(q)).equals("&")) {
                                    number_1 = number;
                                    System.out.println("fist " + number_1);
                                    if (cheque_status_cbo.getSelectedItem().toString().equals("Realised")) {
                                        boolean payment_cheque_1 = true;
                                        ResultSet rset_paym = Model.Object.Jdbc.getdata("select* from payments where (invoice_or_grn='" + "invoice" + "' || invoice_or_grn='" + "Invoice Return" + "') and invoice_grn_code='" + number_1 + "'");
                                        ResultSet rset_Ivoice = Model.Object.Jdbc.getdata("select* from invoice_balance where invoice_code='" + number_1 + "'");
                                        Double payment = 0.00;
                                        while (rset_paym.next()) {
                                            payment = payment + rset_paym.getDouble(6);
                                        }
                                        if (rset_Ivoice.next()) {
                                            if (payment == rset_Ivoice.getDouble(9)) {
                                                if (cheque_check(number_1, "Invoice") == false) {
                                                    payment_cheque_1 = false;
                                                    System.out.println("next == ");
                                                }
                                            } else {
                                                payment_cheque_1 = true;

                                            }
                                        }
                                        if (payment_cheque_1 == false) {
                                            System.out.println("false  .");
                                            Model.Object.Jdbc.putdata("update invoice_balance set invoice_status='" + "1" + "' where invoice_code='" + number_1 + "'");
                                            ResultSet pay_up = Model.Object.Jdbc.getdata("select* from payments where (invoice_or_grn='" + "invoice" + "' || invoice_or_grn='" + "Invoice Return" + "') and invoice_grn_code='" + number_1 + "'");
                                            if (pay_up.next()) {
                                                Model.Object.Jdbc.putdata("update payments set payment_status='" + "1" + "' where (invoice_or_grn='" + "invoice" + "' || invoice_or_grn='" + "Invoice Return" + "') and invoice_grn_code='" + number_1 + "'");
                                            }
                                        }
                                    }
                                    number = "";
                                } else {
                                    number = number + String.valueOf(s.charAt(q));
                                    if (q == (s.length() - 1)) {
                                        number_1 = number;
                                        System.out.println("last " + number_1);
                                        if (cheque_status_cbo.getSelectedItem().toString().equals("Realised")) {
                                            boolean payment_cheque_1 = true;
                                            ResultSet rset_paym = Model.Object.Jdbc.getdata("select* from payments where (invoice_or_grn='" + "invoice" + "' || invoice_or_grn='" + "Invoice Return" + "') and invoice_grn_code='" + number_1 + "'");
                                            ResultSet rset_Ivoice = Model.Object.Jdbc.getdata("select* from invoice_balance where invoice_code='" + number_1 + "'");
                                            Double payment = 0.00;
                                            while (rset_paym.next()) {
                                                payment = payment + rset_paym.getDouble(6);
                                            }
                                            if (rset_Ivoice.next()) {
                                                if (payment == rset_Ivoice.getDouble(9)) {
                                                    if (cheque_check(number_1, "Invoice") == false) {
                                                        payment_cheque_1 = false;
                                                    }
                                                } else {
                                                    payment_cheque_1 = true;
                                                }
                                            }
                                            if (payment_cheque_1 == false) {
                                                Model.Object.Jdbc.putdata("update invoice_balance set invoice_status='" + "1" + "' where invoice_code='" + number_1 + "'");
                                                ResultSet pay_up = Model.Object.Jdbc.getdata("select* from payments where  (invoice_or_grn='" + "invoice" + "' || invoice_or_grn='" + "Invoice Return" + "')  and invoice_grn_code='" + number_1 + "'");
                                                if (pay_up.next()) {
                                                    Model.Object.Jdbc.putdata("update payments set payment_status='" + "1" + "' where  (invoice_or_grn='" + "invoice" + "' || invoice_or_grn='" + "Invoice Return" + "')  and invoice_grn_code='" + number_1 + "'");
                                                }
                                            }
                                        }
                                        break;
                                    }
                                }
                            }
                        }
                    } else if (invoice_grn_lbl.getText().equals("Grn")) {
                        int count = 0;
                        ResultSet rset_peding_cheque_check = Model.Object.Jdbc.getdata("select* from cheque where invoiceno='" + invoice_number.getText() + "' and ch_status='" + "Pending" + "' and grn_or_invoice='" + "Grn" + "'");
                        while (rset_peding_cheque_check.next()) {
                            count++;
                        }
                        if (1 < count) {

                        } else {

                            String number = "";
                            String number_1 = "";

                            String word = invoice_number.getText();
                            String guess = "&";
                            int index = word.indexOf(guess);
                            int index_count = 0;
                            while (index >= 0) {
                                index = word.indexOf(guess, index + 1);
                                index_count = index_count + 1;
                            }
                            int q = 0;
                            String s = invoice_number.getText();
                            for (q = 0; q < s.length(); q++) {
                                if (String.valueOf(s.charAt(q)).equals("&")) {
                                    number_1 = number;
                                    if (cheque_status_cbo.getSelectedItem().toString().equals("Realised")) {
                                        boolean payment_cheque_1 = true;
                                        ResultSet rset_paym = Model.Object.Jdbc.getdata("select* from payments where (invoice_or_grn='" + "grn" + "' || invoice_or_grn='" + "Grn Return" + "') and invoice_grn_code='" + number_1 + "'");
                                        ResultSet rset_grn = Model.Object.Jdbc.getdata("select* from grn_balance where grn_code='" + number_1 + "'");
                                        Double payment = 0.00;
                                        while (rset_paym.next()) {
                                            payment = payment + rset_paym.getDouble(6);
                                        }
                                        System.out.println("pay " + payment);
                                        if (rset_grn.next()) {
                                            if (payment == rset_grn.getDouble(12)) {
                                                if (cheque_check(number_1, "Grn") == false) {
                                                    payment_cheque_1 = false;
                                                }
                                            } else {
                                                payment_cheque_1 = true;
                                            }
                                        }
                                        if (payment_cheque_1 == false) {
                                            Model.Object.Jdbc.putdata("update grn_balance set grn_status='" + "1" + "' where grn_code='" + number_1 + "'");
                                            ResultSet pay_up = Model.Object.Jdbc.getdata("select* from payments where (invoice_or_grn='" + "grn" + "' || invoice_or_grn='" + "Grn Return" + "') and invoice_grn_code='" + number_1 + "'");
                                            if (pay_up.next()) {
                                                Model.Object.Jdbc.putdata("update payments set payment_status='" + "1" + "' where (invoice_or_grn='" + "grn" + "' || invoice_or_grn='" + "Grn Return" + "')  and invoice_grn_code='" + number_1 + "'");
                                            }
                                        }
                                    }
                                    number = "";
                                } else {
                                    number = number + String.valueOf(s.charAt(q));
                                    if (q == (s.length() - 1)) {
                                        number_1 = number;
                                        if (cheque_status_cbo.getSelectedItem().toString().equals("Realised")) {
                                            boolean payment_cheque_1 = true;
                                            ResultSet rset_paym = Model.Object.Jdbc.getdata("select* from payments where (invoice_or_grn='" + "grn" + "' || invoice_or_grn='" + "Grn Return" + "') and invoice_grn_code='" + number_1 + "'");
                                            ResultSet rset_grn = Model.Object.Jdbc.getdata("select* from grn_balance where grn_code='" + number_1 + "'");
                                            Double payment = 0.00;
                                            while (rset_paym.next()) {
                                                payment = payment + rset_paym.getDouble(6);
                                            }
                                            if (rset_grn.next()) {
                                                if (payment == rset_grn.getDouble(12)) {
                                                    if (cheque_check(number_1, "Grn") == false) {
                                                        payment_cheque_1 = false;
                                                    }
                                                } else {
                                                    payment_cheque_1 = true;
                                                }
                                            }
                                            if (payment_cheque_1 == false) {
                                                Model.Object.Jdbc.putdata("update grn_balance set grn_status='" + "1" + "' where grn_code='" + number_1 + "'");
                                                ResultSet pay_up = Model.Object.Jdbc.getdata("select* from payments where (invoice_or_grn='" + "grn" + "' || invoice_or_grn='" + "Grn Return" + "') and invoice_grn_code='" + number_1 + "'");
                                                if (pay_up.next()) {
                                                    Model.Object.Jdbc.putdata("update payments set payment_status='" + "1" + "' where (invoice_or_grn='" + "grn" + "' || invoice_or_grn='" + "Grn Return" + "')  and invoice_grn_code='" + number_1 + "'");
                                                }
                                            }
                                        }
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    JOptionPane.showMessageDialog(null, "Record Updated Successfully");
                    invoice_grn_lbl.setText(null);
                    invoice_number.setText(null);
                    Customer_lbl.setText(null);
                    cheque_number_lbl.setText(null);
                    bank_name_lbl.setText(null);
                    cheque_date_lbl.setText(null);
                    amount_lbl.setText(null);
                    cheque_status_cbo.setSelectedItem("Realised");
                    Vector v = new Vector();
                    cheque_number_lst.setListData(v);
                }
            } else {
                JOptionPane.showMessageDialog(null, "Cheque Number Doesn't Match");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean cheque_check(String invoiceno, String grn_or_invoice) {
        boolean bool = true;
        try {
            ResultSet rset_chn_nest = Model.Object.Jdbc.getdata("select* from cheque where invoiceno='" + invoiceno + "' and grn_or_invoice='" + grn_or_invoice + "'");
            if (rset_chn_nest.next()) {
                ResultSet rset_chn = Model.Object.Jdbc.getdata("select* from cheque where invoiceno='" + invoiceno + "' and grn_or_invoice='" + grn_or_invoice + "'");
                while (rset_chn.next()) {
                    if (rset_chn.getString("ch_status").equals("Pending") || rset_chn.getString("ch_status").equals("Unrealised")) {
                        bool = true;
                        break;
                    } else {
                        bool = false;
                    }
                }
            } else {
                bool = false;
            }
        } catch (Exception e) {
            System.out.println("cheque_check  " + e);
        }
        return bool;
    }

    public void Unrelease_cheque_search(JList cheque_number_lst) {
        try {
            String start_date = getStartDate();
            String end_date = getEndDate();
            Vector v = new Vector();
            ResultSet rset = Model.Object.Jdbc.getdata("select* from cheque where ch_status='" + "Unrealised" + "' and close_date between'" + start_date + "' and '" + end_date + "'");
            while (rset.next()) {
                if (rset.getString(8).equals("Grn")) {
                    ResultSet rset_check_invoice = Model.Object.Jdbc.getdata("select* from grn_balance where grn_code='" + rset.getString("invoiceno") + "' and grn_status='" + "1" + "'");
                    if (rset_check_invoice.next()) {
                    } else {
                        v.add(rset.getString(2));
                    }
                } else {
                    ResultSet rset_check_invoice = Model.Object.Jdbc.getdata("select* from invoice_balance where invoice_code='" + rset.getString("invoiceno") + "' and invoice_status='" + "1" + "'");
                    if (rset_check_invoice.next()) {
                    } else {
                        v.add(rset.getString(2));
                    }
                }
                cheque_number_lst.setListData(v);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void Unrelease_update(JLabel ur_invoice_grn_lbl, JLabel ur_invoice_number, JLabel ur_Customer_lbl, JLabel ur_old_cheque_number_lbl, JTextField ur_cheque_number_txt, JLabel ur_Old_bank_name_lbl, JComboBox ur_bank_name_cbo, JLabel ur_Old_cheque_date_lbl, JTextField ur_cheque_date_txt, JLabel ur_amount_lbl, JLabel ur_Old_cheque_status_lbl, JLabel ur_cheque_status_lbl, JList ur_cheque_number_lst) {
        try {
            if (ur_cheque_number_txt.getText().isEmpty()) {
                Model.Object.messagePopUps.enter_cheque_number();
                ur_cheque_number_txt.grabFocus();
            } else if (ur_cheque_date_txt.getText().isEmpty()) {
                Model.Object.messagePopUps.enter_cheque_date();
                ur_cheque_date_txt.grabFocus();
            } else {
                ResultSet rset = Model.Object.Jdbc.getdata("select* from cheque where cheque_number='" + ur_cheque_number_txt.getText() + "'");
                if (rset.next()) {
                    JOptionPane.showMessageDialog(null, "Duplicate Cheque Number");
                    ur_Customer_lbl.setText(null);
                    ur_Old_bank_name_lbl.setText(null);
                    ur_Old_cheque_date_lbl.setText(null);
                    ur_amount_lbl.setText(null);
                    ur_bank_name_cbo.setSelectedItem("Axis Bank Ltd.");
                    ur_cheque_date_txt.setText(null);
                    ur_cheque_number_txt.setText(null);
                    ur_cheque_status_lbl.setText("Pending");
                    ur_invoice_grn_lbl.setText(null);
                    ur_Old_bank_name_lbl.setText(null);
                    ur_invoice_number.setText(null);
                    ur_old_cheque_number_lbl.setText(null);
                    ur_Old_cheque_status_lbl.setText(null);
                    Vector v = new Vector();
                    ur_cheque_number_lst.setListData(v);
                } else {
                    ResultSet rset_old_cheque = Model.Object.Jdbc.getdata("select* from cheque where cheque_number='" + ur_old_cheque_number_lbl.getText() + "'");
                    if (rset_old_cheque.next()) {
                        Model.Object.Jdbc.putdata("insert into cheque_unrealised values ('" + rset_old_cheque.getString(1) + "','" + rset_old_cheque.getString(2) + "','" + rset_old_cheque.getString(3) + "','" + rset_old_cheque.getString(4) + "','" + rset_old_cheque.getString(5) + "','" + rset_old_cheque.getString(6) + "','" + rset_old_cheque.getString(7) + "','" + rset_old_cheque.getString(8) + "','" + rset_old_cheque.getString(9) + "',NOW(),'" + FrmHome2.user_lbl.getText() + "')");
                        Model.Object.Jdbc.putdata("delete from cheque where cheque_number='" + rset_old_cheque.getString(2) + "'");
                        Model.Object.Jdbc.putdata("insert into cheque values ('" + ur_invoice_number.getText() + "','" + ur_cheque_number_txt.getText() + "','" + ur_Customer_lbl.getText() + "','" + ur_bank_name_cbo.getSelectedItem() + "','" + ur_cheque_date_txt.getText() + "','" + ur_amount_lbl.getText() + "','" + ur_cheque_status_lbl.getText() + "','" + "" + "','" + ur_invoice_grn_lbl.getText() + "',NOW(),'" + FrmHome2.user_lbl.getText() + "')");
                        Model.Object.messagePopUps.saveMessage();
                        ur_Customer_lbl.setText(null);
                        ur_Old_bank_name_lbl.setText(null);
                        ur_Old_cheque_date_lbl.setText(null);
                        ur_amount_lbl.setText(null);
                        ur_bank_name_cbo.setSelectedItem("Axis Bank Ltd.");
                        ur_cheque_date_txt.setText(null);
                        ur_cheque_number_txt.setText(null);
                        ur_cheque_status_lbl.setText("Pending");
                        ur_invoice_grn_lbl.setText(null);
                        ur_invoice_number.setText(null);
                        ur_old_cheque_number_lbl.setText(null);
                        Vector v = new Vector();
                        ur_cheque_number_lst.setListData(v);
                        ur_Old_cheque_status_lbl.setText(null);
                    }
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
