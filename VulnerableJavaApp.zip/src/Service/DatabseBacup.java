/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import java.io.File;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import org.apache.commons.*;

/**
 *
 * @author user
 */
public class DatabseBacup {

    public void DatabaseBacup(JLabel jb) {
        JFileChooser jFileChooser = new JFileChooser();
        jFileChooser.setSelectedFile(new File("InfoIms" + Model.Object.Formated.todayDate() + "Backup.sql"));
        jFileChooser.showSaveDialog(jb);
        String path = jFileChooser.getSelectedFile().getAbsolutePath();
        String username = "root";
        String password = "Infocraft@99.com";
        //pass=Infocraft@99.com
        String dbname = "infoims_sumith_new_chathuka";
        String executeCmd = "C:\\Program Files\\MySQL\\MySQL Server 5.1\\bin\\mysqldump -u " + username + " -p" + password + " --add-drop-database -B " + dbname + " mysql -r " + path;
        // String executeCmd = "C:\\Program Files\\MySQL\\MySQL Server 5.6\\bin\\mysqldump -u " + username + " -p" + password + " --add-drop-database -B " + dbname + " mysql -r " + path;
        try {
            Process runtimeProcess = Runtime.getRuntime().exec(executeCmd);
            int processComplete = runtimeProcess.waitFor();
            if (processComplete == 0) {
                Model.Object.messagePopUps.get_backup();
            } else {
                Model.Object.messagePopUps.not_get_backup();
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }
}
