/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import java.awt.Color;
import java.awt.event.KeyEvent;
import java.sql.ResultSet;
import java.util.Vector;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListModel;
import javax.swing.table.DefaultTableModel;
import View.FrmGrnReturn;
import View.FrmHome2;
import View.FrmPayment;
import javax.swing.JOptionPane;

/**
 *
 * @author user
 */
public class GrnService {

    public void supplier_search_key_release(JTextField txt_supplier_code_search, JComboBox cbo_supplier_code) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select* from supplier_master where name like'" + txt_supplier_code_search.getText() + "%'");
            Vector v = new Vector();
            while (rset.next()) {
                v.add(rset.getString(2));
            }
            cbo_supplier_code.setModel(new DefaultComboBoxModel(v));
        } catch (Exception e) {
            System.out.println("grn supplier_search  " + e);
        }
    }

    public void supplier_search_all(JComboBox cbo_supplier_code) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select* from supplier_master");
            Vector v = new Vector();
            while (rset.next()) {
                v.add(rset.getString(1));
            }
            cbo_supplier_code.setModel(new DefaultComboBoxModel(v));
        } catch (Exception e) {
            System.out.println("grn supplier_search_all  " + e);
        }
    }

    public void all_supplier_Name_load(JComboBox cbo_supplier_code) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select* from supplier_master");
            Vector v = new Vector();
            while (rset.next()) {
                v.add(rset.getString(2));
            }
            cbo_supplier_code.setModel(new DefaultComboBoxModel(v));
        } catch (Exception e) {
            System.out.println("grn all_supplier_load  " + e);
        }
    }

    public void all_supplier_load(JComboBox cbo_supplier_code) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select* from supplier_master");
            Vector v = new Vector();
            while (rset.next()) {
                v.add(rset.getString(1));
            }
            cbo_supplier_code.setModel(new DefaultComboBoxModel(v));
        } catch (Exception e) {
            System.out.println("grn all_supplier_load  " + e);
        }
    }

    public void select_supplier(JComboBox cbo_supplier_code, JLabel txt_supplier_name) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select* from supplier_master where name='" + cbo_supplier_code.getSelectedItem() + "'");
            if (rset.next()) {
                txt_supplier_name.setText(rset.getString(2));
            }
        } catch (Exception e) {
            System.out.println("grn select_supplier  " + e);
        }
    }

    public void grn_invoice_number_check(JTextField txt_invoice_number, JTextField txt_invoice_date) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select* from grn_balance where supplier_invoice_code='" + txt_invoice_number.getText() + "'");
            if (rset.next()) {
                Model.Object.messagePopUps.grn_invoice_duplicate();
                txt_invoice_number.grabFocus();
                txt_invoice_number.selectAll();
            } else {
                txt_invoice_date.grabFocus();
            }
        } catch (Exception e) {
            System.out.println("grn grn_invoice_number_check  " + e);
        }
    }

    public void grn_number_generator(JLabel lbl_grn_number) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select max(grn_code) from grn_code");
            if (rset.next()) {
                lbl_grn_number.setText("GRN" + (rset.getInt(1) + 1));
            }
        } catch (Exception e) {
            System.out.println("grn number generator  " + e);
        }
    }

    public void grn_item_list_load_from_code(JTextField txt_item_code, JList lst_item_list, JList lst_item_code_list) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select* from item_master where item_code like'" + txt_item_code.getText() + "%'");
            Vector v_desc = new Vector();
            Vector v_code = new Vector();
            while (rset.next()) {
                v_desc.add(rset.getString(2));
                v_code.add(rset.getString(1));
            }
            lst_item_list.setListData(v_desc);
            lst_item_code_list.setListData(v_code);
        } catch (Exception e) {
            System.out.println("grn grn_item_list_load  " + e);
        }
    }

    public void item_code_list_value_change(JTextField txt_item_code, JList lst_item_code_list, JList lst_item_list, JTextField txt_item_description, JLabel lbl_available_Qty, JTextField txt_item_cost, JComboBox cbo_location) {
        try {
            int i = lst_item_code_list.getSelectedIndex();
            lst_item_list.setSelectedIndex(i);
            lst_item_list.ensureIndexIsVisible(lst_item_code_list.getSelectedIndex());
            ResultSet rset = Model.Object.Jdbc.getdata("select* from item_inventory where item_code='" + lst_item_code_list.getSelectedValue() + "' and location='" + cbo_location.getSelectedItem() + "'");
            if (rset.next()) {
                if (rset.getDouble(4) < 10) {
                    lbl_available_Qty.setForeground(Color.red);
                } else {
                    lbl_available_Qty.setForeground(Color.black);
                }
                lbl_available_Qty.setText(Model.Object.Formated.getPriceValue(rset.getDouble(4)));
            } else {
                lbl_available_Qty.setText("0.00");

            }
            ResultSet rset_item_master = Model.Object.Jdbc.getdata("select* from item_master where item_code='" + lst_item_code_list.getSelectedValue() + "'");
            if (rset_item_master.next()) {
                txt_item_code.setText(rset_item_master.getString(1));
                txt_item_description.setText(rset_item_master.getString(2));
                txt_item_cost.setText(Model.Object.Formated.getPriceValue(rset_item_master.getDouble(4)));
            } else {
                txt_item_cost.setText("0.00");
                txt_item_description.setText(null);
            }
        } catch (Exception e) {
            System.out.println("grn item_code_enter  " + e);
        }
    }

    public void grn_item_list_load_from_name(JTextField txt_item_description, JList lst_item_list, JList lst_item_code_list) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select* from item_master where item_description like'" + txt_item_description.getText() + "%'");
            Vector v_desc = new Vector();
            Vector v_code = new Vector();
            while (rset.next()) {
                v_desc.add(rset.getString(2));
                v_code.add(rset.getString(1));
            }
            lst_item_list.setListData(v_desc);
            lst_item_code_list.setListData(v_code);
        } catch (Exception e) {
            System.out.println("grn grn_item_list_load  " + e);
        }
    }

    public void item_code_enter(JList lst_item_code_list, JLabel lbl_available_Qty, JTextField txt_item_description, JTextField txt_item_code, JTextField txt_item_cost, JTextField txt_quantity) {
        try {
            if (txt_item_code.getText().isEmpty()) {
                lst_item_code_list.grabFocus();
                lst_item_code_list.setSelectedIndex(0);
            } else if (lst_item_code_list.getModel().getSize() == 1) {
                ListModel model = lst_item_code_list.getModel();
                Object o = model.getElementAt(0);
                ResultSet rset_item_master = Model.Object.Jdbc.getdata("select* from item_master where item_code='" + o.toString() + "'");
                if (rset_item_master.next()) {
                    ResultSet rset = Model.Object.Jdbc.getdata("select* from item_inventory where item_code='" + o.toString() + "' and location='" + "WAREHOUSE" + "'");
                    if (rset.next()) {
                        if (rset.getDouble(4) < 10) {
                            lbl_available_Qty.setForeground(Color.red);
                        } else {
                            lbl_available_Qty.setForeground(Color.black);
                        }
                        lbl_available_Qty.setText(Model.Object.Formated.getPriceValue(rset.getDouble(4)));
                    } else {
                        lbl_available_Qty.setText("0.00");
                    }
                    txt_item_description.setText(rset_item_master.getString(2));
                    txt_item_cost.setText(Model.Object.Formated.getPriceValue(rset_item_master.getDouble(4)));

                    txt_item_code.setText(rset_item_master.getString(1));
                    txt_item_description.setText(rset_item_master.getString(2));
                    txt_quantity.grabFocus();
                    lst_item_code_list.setSelectedIndex(0);
                } else {
                    Model.Object.messagePopUps.Item_number_dosesnot_match();
                    txt_item_code.grabFocus();
                    txt_item_code.selectAll();
                }
            } else if (lst_item_code_list.getModel().getSize() == 0) {
                Model.Object.messagePopUps.Item_number_dosesnot_match();
                txt_item_code.grabFocus();
                txt_item_code.selectAll();
            } else {
                lst_item_code_list.setSelectedIndex(0);
                lst_item_code_list.grabFocus();
            }
        } catch (Exception e) {
            System.out.println("grn item_code_enter  " + e);
        }

    }

    public void item_list_key_press(JList lst_item_code_list, JTextField txt_quantity, KeyEvent evt) {
        try {
            if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
                int i = lst_item_code_list.getSelectedIndex();
                txt_quantity.grabFocus();
                lst_item_code_list.setSelectedIndex(i);
            }
        } catch (Exception e) {
            System.out.println("grn item_list_er_press " + e);
        }
    }

    public void quantity_action(JTextField txt_quantity, JTextField txt_item_descount) {
        try {
            if (txt_quantity.getText().isEmpty()) {
                Model.Object.messagePopUps.Quantity_Empty();
                txt_quantity.grabFocus();
            } else {
                txt_item_descount.grabFocus();
                txt_item_descount.selectAll();
            }
        } catch (Exception e) {
            System.out.println("grn quantity_action  " + e);
        }
    }

    public void item_discount_action(JTextField txt_item_cost, JTextField txt_quantity, JTextField txt_item_descount, JLabel lbl_item_amount, JButton btn_item_add) {
        try {
            if (txt_item_descount.getText().isEmpty()) {
                txt_item_descount.setText("0.00");
            }
            Double total_amount = Double.parseDouble(txt_item_cost.getText()) * Double.parseDouble(txt_quantity.getText());
            Double discount = total_amount * Double.parseDouble(txt_item_descount.getText()) / 100;
            lbl_item_amount.setText(Model.Object.Formated.getPriceValue(total_amount - discount));
            txt_item_descount.setText(Model.Object.Formated.getPriceValue(Double.parseDouble(txt_item_descount.getText())));
            btn_item_add.grabFocus();
        } catch (Exception e) {
            System.out.println("grn item_discount_action  " + e);
        }
    }

    public void item_list_all_load(JList lst_item_list, JList lst_item_code_list) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select* from item_master");
            Vector v_desc = new Vector();
            Vector v_code = new Vector();
            while (rset.next()) {
                v_desc.add(rset.getString(2));
                v_code.add(rset.getString(1));
            }
            lst_item_list.setListData(v_desc);
            lst_item_code_list.setListData(v_code);
        } catch (Exception e) {
            System.out.println("grn item_list all load  " + e);
        }
    }

    public void add_item(JTextField txt_total_dicount, JLabel lbl_total_amount, JList lst_item_code_list, JList lst_item_list, JTextField txt_supplier_code_search, JLabel lbl_supplier_name, JTextField txt_invoice_number, JTextField txt_invoice_date, JTextField txt_due_date, JTextField txt_grn_date, JTextField txt_item_code, JTextField txt_item_description, JTextField txt_item_cost, JTextField txt_quantity, JTextField txt_item_descount, JLabel lbl_item_amount, JComboBox cbo_supplier_code, JTable tbl_grn) {
        try {
            if (txt_item_code.getText().isEmpty()) {
                Model.Object.messagePopUps.please_item_code();
                txt_item_code.grabFocus();
            } else if (txt_item_description.getText().isEmpty()) {
                Model.Object.messagePopUps.item_desc_is_empty();
                txt_item_code.grabFocus();
            } else if (txt_item_cost.getText().isEmpty() || txt_item_cost.getText().equals("0.00")) {
                Model.Object.messagePopUps.item_cost_is_empty();
                txt_item_code.grabFocus();
            } else if (txt_quantity.getText().isEmpty() || txt_quantity.getText().equals("0")) {
                Model.Object.messagePopUps.Quantity_Empty();
                txt_quantity.grabFocus();
            } else if (txt_item_descount.getText().isEmpty()) {
                Model.Object.messagePopUps.enter_discount();
                txt_item_descount.grabFocus();
            } else if (lbl_item_amount.getText().isEmpty() || lbl_item_amount.getText() == null) {
                Model.Object.messagePopUps.item_amount_empty();
                txt_item_descount.grabFocus();
            } else {
                boolean bool = false;
                DefaultTableModel df = (DefaultTableModel) tbl_grn.getModel();
                for (int i = 0; i < df.getRowCount(); i++) {
                    if (df.getValueAt(i, 0).toString().equals(txt_item_code.getText())) {
                        if (df.getValueAt(i, 5).toString().equals("100.00")) {
                            bool = true;
                            break;
                        }
                    }
                }
                if (bool) {
                    Model.Object.messagePopUps.Duplicate_entry();
                    txt_item_description.grabFocus();
                    txt_item_code.selectAll();
                } else {
                    ResultSet rset_item_master = Model.Object.Jdbc.getdata("select* from item_master where item_code='" + txt_item_code.getText() + "'");
                    if (rset_item_master.next()) {
                        Vector v = new Vector();
                        v.add(txt_item_code.getText());
                        v.add(txt_item_description.getText());
                        v.add(txt_item_cost.getText());
                        v.add(txt_quantity.getText());
                        v.add(Model.Object.Formated.getPriceValue(Double.parseDouble(txt_item_cost.getText()) * Double.parseDouble(txt_quantity.getText())));
                        v.add(txt_item_descount.getText());
                        v.add(lbl_item_amount.getText());
                        v.add("0.00");
                        v.add(lbl_item_amount.getText());
                        df.addRow(v);
                        Model.Object.messagePopUps.Data_Added_Successfully();
                        Double total_amount = 0.00;
                        for (int i = 0; i < tbl_grn.getRowCount(); i++) {
                            total_amount = total_amount + Double.parseDouble(tbl_grn.getValueAt(i, 6).toString());
                        }
                        lbl_total_amount.setText(Model.Object.Formated.getPriceValue(total_amount));
                        txt_item_code.setText(null);
                        txt_item_description.setText(null);
                        txt_item_cost.setText(null);
                        txt_quantity.setText(null);
                        txt_item_descount.setText(null);
                        lbl_item_amount.setText(null);
                        item_list_all_load(lst_item_list, lst_item_code_list);
                        txt_total_dicount.setText(null);
                        txt_item_description.grabFocus();
                    } else {
                        Model.Object.messagePopUps.Item_number_dosesnot_match();
                        txt_item_code.grabFocus();
                        txt_item_code.selectAll();
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("grn add_item  " + e);
        }
    }

    public void total_discount_action(JLabel lbl_return_amount, JLabel lbl_sub_total, JTable tbl_grn, JLabel lbl_total_amount, JTextField txt_total_dicount, JLabel lbl_net_amount, JComboBox cbo_payment_type) {
        try {
            if (txt_total_dicount.getText().isEmpty() || txt_total_dicount.getText() == null) {
                txt_total_dicount.setText("0.00");
            }
            if (lbl_return_amount.getText() == null || lbl_return_amount.getText().isEmpty()) {
                lbl_return_amount.setText("0.00");
            }
            DefaultTableModel df = (DefaultTableModel) tbl_grn.getModel();
            for (int i = 0; i < df.getRowCount(); i++) {
                Double sub_total = (Double.parseDouble(df.getValueAt(i, 6).toString()) * Double.parseDouble(txt_total_dicount.getText())) / 100;
                df.setValueAt((Model.Object.Formated.getPriceValue((Double.parseDouble(df.getValueAt(i, 6).toString()) - sub_total))), i, 8);
                df.setValueAt(txt_total_dicount.getText(), i, 7);
            }
            Double discount = Double.parseDouble(lbl_total_amount.getText()) * Double.parseDouble(txt_total_dicount.getText()) / 100;
            lbl_net_amount.setText(Model.Object.Formated.getPriceValue(Double.parseDouble(lbl_total_amount.getText()) - discount));
            lbl_sub_total.setText(Model.Object.Formated.getPriceValue(Double.parseDouble(lbl_net_amount.getText()) - Double.parseDouble(lbl_return_amount.getText())));
            cbo_payment_type.grabFocus();
        } catch (Exception e) {
            System.out.println("grn total_discount_action " + e);
        }
    }

    public void save_button(JLabel lbl_return_amount, JLabel lbl_sub_total, JTextField txt_supplier_code_search, JTextField txt_item_code, JComboBox cbo_supplier_code, JLabel lbl_supplier_name, JTextField txt_invoice_number, JTextField txt_invoice_date, JLabel lbl_grn_number, JTextField txt_grn_date, JTable tbl_grn, JLabel lbl_total_amount, JTextField txt_total_dicount, JLabel lbl_net_amount, JComboBox cbo_payment_type, JTextField txt_cash_payment, JLabel total_balance_lbl, JTextField txt_due_date, JLabel lbl_balance, JComboBox cbo_location) {
        try {
            if (cbo_supplier_code.getSelectedItem().toString().isEmpty()) {
                Model.Object.messagePopUps.select_supplier_number();
                cbo_supplier_code.grabFocus();
            } else if (lbl_supplier_name.getText().isEmpty()) {
                Model.Object.messagePopUps.supplier_name_cannt_find();
                cbo_supplier_code.grabFocus();
            } else if (txt_invoice_number.getText().isEmpty()) {
                Model.Object.messagePopUps.enter_grn_invoice_number();
                txt_invoice_number.grabFocus();
            } else if (txt_invoice_date.getText().isEmpty()) {
                Model.Object.messagePopUps.enter_grn_invoice_date();
                txt_invoice_date.grabFocus();
            } else if (lbl_grn_number.getText().isEmpty()) {
                Model.Object.messagePopUps.grn_code_empty();
            } else if (txt_grn_date.getText().isEmpty()) {
                Model.Object.messagePopUps.grn_date_empty();
                txt_grn_date.grabFocus();
            } else if (lbl_total_amount.getText().isEmpty()) {
                Model.Object.messagePopUps.total_amount_empty();
                txt_item_code.grabFocus();
            } else if (txt_total_dicount.getText().isEmpty()) {
                Model.Object.messagePopUps.enter_total_discount();
                txt_total_dicount.grabFocus();
            } else if (lbl_net_amount.getText().isEmpty()) {
                Model.Object.messagePopUps.net_amount_empty();
                txt_total_dicount.grabFocus();
            } else if (txt_cash_payment.getText().isEmpty()) {
                Model.Object.messagePopUps.enter_cash_payment();
                txt_cash_payment.grabFocus();
            } else {
                boolean boo = false;
                if (cbo_payment_type.getSelectedItem().toString().equals("Credit")) {
                    if (Double.parseDouble(txt_cash_payment.getText()) >= Double.parseDouble(lbl_sub_total.getText())) {
                        boo = true;
                        Model.Object.messagePopUps.paymet_High();
                        txt_cash_payment.grabFocus();
                        txt_cash_payment.selectAll();
                    } else {
                        boo = false;
                    }
                } else {
                    if (Double.parseDouble(lbl_sub_total.getText()) > Double.parseDouble(txt_cash_payment.getText())) {
                        boo = true;
                        Model.Object.messagePopUps.paymet_low();
                        txt_cash_payment.grabFocus();
                        txt_cash_payment.selectAll();
                    } else {
                        boo = false;
                    }
                }
                if (boo == false) {
                    ResultSet rset = Model.Object.Jdbc.getdata("select* from grn_item where grn_code='" + lbl_grn_number.getText() + "'");
                    if (rset.next()) {
                        Model.Object.messagePopUps.grn_code_duplicate();
                    } else {
                        DefaultTableModel df = (DefaultTableModel) tbl_grn.getModel();
                        for (int i = 0; i < df.getRowCount(); i++) {
                            Double recent_qty = 0.00;
                            ResultSet rset_all_qty = Model.Object.Jdbc.getdata("select* from item_inventory where item_code='" + df.getValueAt(i, 0) + "'");
                            while (rset_all_qty.next()) {
                                recent_qty = recent_qty + rset_all_qty.getDouble(4);
                            }

                            Double location_recent_qty = 0.00;
                            ResultSet rset_location_qty = Model.Object.Jdbc.getdata("select* from item_inventory where item_code='" + df.getValueAt(i, 0) + "' and location='" + cbo_location.getSelectedItem() + "'");
                            if (rset_location_qty.next()) {
                                location_recent_qty = rset_location_qty.getDouble(4);
                            }
                            Model.Object.Jdbc.putdata("insert into grn_item values('" + lbl_grn_number.getText() + "','" + df.getValueAt(i, 0) + "','" + df.getValueAt(i, 1) + "','" + "Type" + "','" + df.getValueAt(i, 2) + "','" + df.getValueAt(i, 3) + "','" + df.getValueAt(i, 4) + "','" + "Percentage" + "','" + df.getValueAt(i, 5) + "','" + df.getValueAt(i, 6) + "','" + df.getValueAt(i, 7) + "','" + df.getValueAt(i, 8) + "',NOW(),'" + FrmHome2.user_lbl.getText() + "','" + cbo_supplier_code.getSelectedItem() + "')");
                            Double quantity_old = 0.00;
                            Double quantity_old_full = 0.00;
                            Double quantity_new = 0.00;
                            Double old_avarage_cost = 0.00;
                            Double new_avarage_cost = 0.00;
                            Double new_avarage_unit_cost = 0.00;
                            ResultSet rset_inventoty1 = Model.Object.Jdbc.getdata("select* from item_inventory where item_code='" + df.getValueAt(i, 0) + "'");
                            if (rset_inventoty1.next()) {
                                quantity_old_full = rset_inventoty1.getDouble(4);
                            }
                            ResultSet rset_inventoty = Model.Object.Jdbc.getdata("select* from item_inventory where item_code='" + df.getValueAt(i, 0) + "' and location='" + cbo_location.getSelectedItem() + "'");
                            if (rset_inventoty.next()) {
                                quantity_old = rset_inventoty.getDouble(4);
                                quantity_new = rset_inventoty.getDouble(4) + Double.parseDouble(df.getValueAt(i, 3).toString());

                                Double old_avarage = rset_inventoty.getDouble(3) * quantity_old;
                                Double new_cost = Double.parseDouble(df.getValueAt(i, 6).toString()) - (Double.parseDouble(df.getValueAt(i, 6).toString()) * Double.parseDouble(txt_total_dicount.getText())) / 100;
                                new_cost = old_avarage + new_cost;
                                Double avarage_uit_cost = new_cost / quantity_new;
                                Model.Object.Jdbc.putdata("update item_inventory set stock='" + (rset_inventoty.getDouble(4) + Double.parseDouble(df.getValueAt(i, 3).toString())) + "',avarage_price='" + avarage_uit_cost + "' ,last_date_time=NOW(),last_user='" + FrmHome2.user_lbl.getText() + "' where item_code='" + df.getValueAt(i, 0) + "' and location='" + cbo_location.getSelectedItem() + "'");
                            } else {
                                quantity_new = Double.parseDouble(df.getValueAt(i, 3).toString());
                                String[] location = new String[]{"WAREHOUSE", "OUTLET"};
                                Double w_qty = 0.0;
                                Double o_qty = 0.0;
                                if (cbo_location.getSelectedItem().toString().equals("WAREHOUSE")) {
                                    w_qty = Double.parseDouble(df.getValueAt(i, 3).toString());
                                } else {
                                    o_qty = Double.parseDouble(df.getValueAt(i, 3).toString());
                                }
                                Double[] quantity = new Double[]{w_qty, o_qty};
                                for (int j = 0; j < 2; j++) {
                                    Model.Object.Jdbc.putdata("insert into item_inventory values('" + df.getValueAt(i, 0) + "','" + df.getValueAt(i, 1) + "','" + (Double.parseDouble(df.getValueAt(i, 6).toString()) - (Double.parseDouble(df.getValueAt(i, 6).toString()) * Double.parseDouble(txt_total_dicount.getText())) / 100) / Double.parseDouble(df.getValueAt(i, 3).toString()) + "','" + quantity[j] + "','" + location[j] + "',NOW(),'" + FrmHome2.user_lbl.getText() + "')");
                                }
                            }
                            ResultSet rset_item_master = Model.Object.Jdbc.getdata("select* from item_master where item_code='" + df.getValueAt(i, 0) + "'");
                            if (rset_item_master.next()) {
                                old_avarage_cost = quantity_old_full * rset_item_master.getDouble(5);
                            }
                            Double total_discount = (Double.parseDouble(df.getValueAt(i, 6).toString()) * Double.parseDouble(txt_total_dicount.getText())) / 100;
                            Double new_item_amount = Double.parseDouble(df.getValueAt(i, 6).toString()) - total_discount;
                            new_avarage_cost = old_avarage_cost + new_item_amount;
                            new_avarage_unit_cost = new_avarage_cost / (quantity_old_full + Double.parseDouble(df.getValueAt(i, 3).toString()));
                            Model.Object.Jdbc.putdata("update item_master set main_item_avarage_cost='" + new_avarage_unit_cost + "' where item_code='" + df.getValueAt(i, 0) + "'");

                            Model.Object.Jdbc.putdata("insert into transaction values('" + df.getValueAt(i, 0) + "','" + lbl_grn_number.getText() + "','" + txt_grn_date.getText() + "','" + recent_qty + "','" + df.getValueAt(i, 3) + "','" + "0.00" + "','" + (recent_qty + Double.parseDouble(df.getValueAt(i, 3).toString())) + "','" + "Good Recieved" + "','" + cbo_location.getSelectedItem() + "',NOW(),'" + FrmHome2.user_lbl.getText() + "')");
                            Model.Object.Jdbc.putdata("insert into Location_wise_transaction values('" + df.getValueAt(i, 0) + "','" + lbl_grn_number.getText() + "','" + txt_grn_date.getText() + "','" + location_recent_qty + "','" + df.getValueAt(i, 3) + "','" + "0.0" + "','" + (location_recent_qty + Double.parseDouble(df.getValueAt(i, 3).toString())) + "','" + "Good Recieved" + "','" + cbo_location.getSelectedItem() + "',NOW(),'" + FrmHome2.user_lbl.getText() + "')");

                        }
                        String grn_status = "";
                        if (cbo_payment_type.getSelectedItem().toString().equals("Credit")) {
                            grn_status = "0";
                            Model.Object.Jdbc.putdata("insert into payments value('" + "0" + "','" + "grn" + "','" + lbl_grn_number.getText() + "','" + cbo_supplier_code.getSelectedItem() + "','" + lbl_net_amount.getText() + "','" + txt_cash_payment.getText() + "','" + Math.abs(Double.parseDouble(lbl_balance.getText())) + "',NOW(),'" + "Cash" + "','" + "0" + "','" + "" + "',NOW(),'" + FrmHome2.user_lbl.getText() + "')");
                        } else {
                            grn_status = "1";
                        }
                        String SupplierCode = "";
                        ResultSet rset5 = Model.Object.Jdbc.getdata("select* from supplier_master where name='" + cbo_supplier_code.getSelectedItem() + "'");
                        if (rset5.next()) {
                            SupplierCode = rset5.getString(1);
                        }
                        Model.Object.Jdbc.putdata("insert into grn_balance value('" + lbl_grn_number.getText() + "','" + SupplierCode + "','" + txt_invoice_number.getText() + "','" + txt_invoice_date.getText() + "','" + txt_due_date.getText() + "','" + txt_grn_date.getText() + "','" + lbl_total_amount.getText() + "','" + "Percentage" + "','" + txt_total_dicount.getText() + "','" + lbl_net_amount.getText() + "','" + lbl_return_amount.getText() + "','" + lbl_sub_total.getText() + "','" + cbo_payment_type.getSelectedItem() + "','" + txt_cash_payment.getText() + "','" + lbl_balance.getText() + "','" + grn_status + "','" + cbo_location.getSelectedItem() + "',NOW(),'" + FrmHome2.user_lbl.getText() + "')");
                        Model.Object.Jdbc.putdata("insert into grn_code values('" + "0" + "')");
                        if (cbo_payment_type.getSelectedItem().equals("Credit")) {
                            if (!txt_cash_payment.getText().equals("0.00")) {
                                Model.Object.paymentVeryfication.save_new(SupplierCode, lbl_grn_number.getText(), lbl_supplier_name.getText(), "From a " + lbl_supplier_name.getText() + " Payment of Rs." + txt_cash_payment.getText() + " by Cash", "Good Received");
                            }
                        }
                        if (lbl_return_amount.getText() == null || lbl_return_amount.getText().isEmpty() || lbl_return_amount.getText().equals("0.00")) {
                        } else {
                            FrmGrnReturn.new_invo_code = lbl_grn_number.getText();
                            FrmGrnReturn.return_type = "Grn";
                            FrmGrnReturn.btn_end_return.doClick();
                        }
                        //print report
                        int payment = 10;
                        FrmPayment p = new FrmPayment();
                        if (cbo_payment_type.getSelectedItem().toString().equals("Credit")) {
                            payment = Model.Object.messagePopUps.have_you_payment_now();
                            if (payment == JOptionPane.YES_OPTION) {
                                p.setVisible(true);
                                p.cbo_type.setSelectedItem("Goods Receipt Note");
                                p.cbo_type.setEnabled(false);
                                ResultSet rset2 = Model.Object.Jdbc.getdata("select* from supplier_master where name='" + cbo_supplier_code.getSelectedItem() + "'");
                                if (rset2.next()) {
                                    p.cbo_customer_code.setSelectedItem(rset2.getString(1));
                                }
                                p.cbo_customer_code.setEnabled(false);
                                p.lbl_name.setText(lbl_supplier_name.getText());
                                Vector v = new Vector();
                                v.add(txt_invoice_number.getText());
                                p.lst_invoice_code.setListData(v);
                                Model.Object.payment.invoice_numner_list_change(p.lbl_return_amount, p.cbo_type, p.lst_invoice_code, p.tbl_invoice_details, p.tbl_past_payment, p.lbl_invoice_total, p.lbl_payed_amount, p.lbl_due_amount, p.txt_paying_amount);
                                p.txt_paying_amount.grabFocus();
                                p.lst_invoice_code.setSelectedIndex(0);
                            } else {
                                Model.Object.messagePopUps.saveMessage();
                            }
                        } else {
                            Model.Object.messagePopUps.saveMessage();
                        }

                        df.setRowCount(0);
                        txt_cash_payment.setText(null);
                        txt_due_date.setText(null);
                        txt_grn_date.setText(null);
                        txt_invoice_date.setText(null);
                        txt_invoice_number.setText(null);
                        txt_item_code.setText(null);
                        txt_total_dicount.setText(null);
                        lbl_balance.setText(null);
                        lbl_net_amount.setText(null);
                        lbl_total_amount.setText(null);
                        cbo_supplier_code.setSelectedIndex(0);
                        lbl_supplier_name.setText(null);
                        lbl_sub_total.setText(null);
                        lbl_return_amount.setText(null);
                        txt_invoice_date.setText(Model.Object.Formated.todayDate());
                        txt_due_date.setText(Model.Object.Formated.todayDate());
                        txt_grn_date.setText(Model.Object.Formated.todayDate());
                        grn_number_generator(lbl_grn_number);
                        cbo_payment_type.setSelectedIndex(0);
                        txt_supplier_code_search.grabFocus();
                        if (payment == JOptionPane.YES_OPTION) {
                            p.txt_paying_amount.grabFocus();
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("grn save_button " + e);
        }
    }
}
