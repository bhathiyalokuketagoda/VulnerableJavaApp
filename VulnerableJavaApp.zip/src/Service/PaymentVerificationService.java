/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import java.sql.ResultSet;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import View.FrmHome2;

/**
 *
 * @author user
 */
public class PaymentVerificationService {

    public void load(JTable tbl_notify) {
        try {
            DefaultTableModel df = (DefaultTableModel) tbl_notify.getModel();
            ResultSet rset = Model.Object.Jdbc.getdata("select* from payment_notifications where status='" + "0" + "'");
            while (rset.next()) {
                Vector v = new Vector();
                v.add(rset.getString(1));
                v.add(rset.getString(2));
                v.add(rset.getString(3));
                v.add(rset.getString(4));
                v.add(rset.getString(5));
                v.add(rset.getString(8));
                df.addRow(v);
            }
        } catch (Exception e) {
            System.out.println("NotificationService  load    " + e);
        }
    }

    public void approve(JTable tbl_notify) {
        try {
            DefaultTableModel df = (DefaultTableModel) tbl_notify.getModel();
            int i = tbl_notify.getSelectedRow();
            ResultSet rset = Model.Object.Jdbc.getdata("select* from payment_notifications where status='" + "0" + "' and notify_code='" + df.getValueAt(i, 0) + "'");
            if (rset.next()) {
                int o = Model.Object.messagePopUps.are_you_sure_approve();
                if (o == JOptionPane.YES_OPTION) {
                    Model.Object.Jdbc.putdata("update payment_notifications set status='" + "1" + "' where notify_code='" + df.getValueAt(i, 0) + "'");
                    Model.Object.messagePopUps.approve_successfully();
                    df.removeRow(i);
                }
            }
        } catch (Exception e) {
            System.out.println("NotificationService  approve    " + e);
        }
    }

    public void save_new(String cs_code, String invoice_code, String cs_name, String comment, String acction) {
        try {
            Model.Object.Jdbc.putdata("insert into payment_notifications values('" + '0' + "','" + invoice_code + "','" + cs_code + "','" + cs_name + "','" + comment + "','" + "0" + "','" + acction + "',NOW(),'" + FrmHome2.user_lbl.getText() + "')");
        } catch (Exception e) {
            System.out.println("NotificationService  save_new    " + e);
        }
    }
}
