/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import View.FrmHome2;
import java.sql.ResultSet;
import java.util.Vector;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JPasswordField;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author user
 */
public class AdminService {

    public boolean check_user_permission_cheque_eithount_msg(String components, String function) {
        boolean bool = false;
        try {
            if (FrmHome2.Admin.equals("Admin")) {
                bool = true;
            } else {
                ResultSet rset = Model.Object.Jdbc.getdata("select* from user_permission where User_group='" + FrmHome2.group + "' and Function='" + function + "' and Components='" + components + "' and Status='" + "true" + "'");
                if (rset.next()) {
                    bool = true;
                } else {
                    bool = false;
                }
            }
        } catch (Exception e) {
            System.out.println("AdminService user_permission_cheque() " + e);
        }
        if (bool == false) {
           // Model.Object.messagePopUps.dont_permision();
        }
        return bool;
    }

    public boolean check_user_permission_cheque(String components, String function) {
        boolean bool = false;
        try {
            if (FrmHome2.Admin.equals("Admin")) {
                bool = true;
            } else {
                ResultSet rset = Model.Object.Jdbc.getdata("select* from user_permission where User_group='" + FrmHome2.group + "' and Function='" + function + "' and Components='" + components + "' and Status='" + "true" + "'");
                if (rset.next()) {
                    bool = true;
                } else {
                    bool = false;
                }
            }
        } catch (Exception e) {
            System.out.println("AdminService user_permission_cheque() " + e);
        }
        if (bool == false) {
            Model.Object.messagePopUps.dont_permision();
        }
        return bool;
    }

    public void new_user_register(JTextField txt_full_name, JTextField txt_user_name, JComboBox cbo_user_Group, JPasswordField pwd_password, JPasswordField pws_confirm_password) {
        try {
            if (txt_full_name.getText().isEmpty()) {
                Model.Object.messagePopUps.Plase_Enter_full_name();
                txt_full_name.grabFocus();
            } else if (txt_user_name.getText().isEmpty()) {
                Model.Object.messagePopUps.Plase_Enter_user_name();
                txt_user_name.grabFocus();
            } else if (cbo_user_Group.getSelectedItem().toString().equals("[ Select ]")) {
                Model.Object.messagePopUps.Plase_Enter_userGroup();
                cbo_user_Group.grabFocus();
            } else if (pwd_password.getText().isEmpty()) {
                Model.Object.messagePopUps.enter_password();
                pwd_password.grabFocus();
            } else if (pws_confirm_password.getText().isEmpty()) {
                Model.Object.messagePopUps.Plase_Enter_confirm_paswrd();
                pws_confirm_password.grabFocus();
            } else if (pwd_password.getText() == pws_confirm_password.getText()) {
                Model.Object.messagePopUps.password_not_in_match();
                pws_confirm_password.grabFocus();
            } else {
                ResultSet rset = Model.Object.Jdbc.getdata("select* from user_login where UserName='" + txt_user_name.getText() + "'");
                if (rset.next()) {
                    Model.Object.messagePopUps.user_duplicate();
                    txt_user_name.grabFocus();
                } else {

                    Model.Object.Jdbc.putdata("insert into user_login values('" + txt_full_name.getText() + "','" + txt_user_name.getText() + "','" + cbo_user_Group.getSelectedItem() + "','" + pws_confirm_password.getText() + "','" + "User" + "','" + FrmHome2.user_lbl.getText() + "',NOW())");
                    Model.Object.messagePopUps.saveMessage();
                    txt_full_name.setText(null);
                    txt_user_name.setText(null);
                    cbo_user_Group.setSelectedItem("[ Select ]");
                    pwd_password.setText(null);
                    pws_confirm_password.setText(null);
                    txt_full_name.grabFocus();
                }
            }
        } catch (Exception e) {
            System.out.println("AdminService new_user_register() " + e);
        }
    }

    public void user_update(JTextField txt_Current_user_name, JPasswordField pwd_current_user_password, JTextField txt_full_name, JTextField txt_user_name, JComboBox cbo_user_Group, JPasswordField pwd_password, JPasswordField pws_confirm_password) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select* from user_login where UserName='" + txt_Current_user_name.getText() + "' ");
            if (rset.next()) {
                if (txt_full_name.getText().isEmpty()) {
                    Model.Object.messagePopUps.Plase_Enter_full_name();
                    txt_full_name.grabFocus();
                } else if (txt_user_name.getText().isEmpty()) {
                    Model.Object.messagePopUps.Plase_Enter_user_name();
                    txt_user_name.grabFocus();
                } else if (cbo_user_Group.getSelectedItem().toString().equals("[ Select ]")) {
                    Model.Object.messagePopUps.Plase_Enter_userGroup();
                    cbo_user_Group.grabFocus();
                } else if (pwd_password.getText().isEmpty()) {
                    Model.Object.messagePopUps.enter_password();
                    pwd_password.grabFocus();
                } else if (pws_confirm_password.getText().isEmpty()) {
                    Model.Object.messagePopUps.Plase_Enter_confirm_paswrd();
                    pws_confirm_password.grabFocus();
                } else if (pwd_password.getText() == pws_confirm_password.getText()) {
                    Model.Object.messagePopUps.password_not_in_match();
                    pws_confirm_password.grabFocus();
                } else {
                    Model.Object.Jdbc.putdata("update user_login set FullName='" + txt_full_name.getText() + "',UserName='" + txt_user_name.getText() + "',UserGroup='" + cbo_user_Group.getSelectedItem() + "', Password='" + pws_confirm_password.getText() + "',user='" + FrmHome2.user_lbl.getText() + "', date_time=NOW() where  UserName='" + txt_Current_user_name.getText() + "' ");
                    Model.Object.messagePopUps.updateMessage();
                    txt_full_name.setText(null);
                    txt_user_name.setText(null);
                    cbo_user_Group.setSelectedItem("[ Select ]");
                    pwd_password.setText(null);
                    pws_confirm_password.setText(null);
                    txt_Current_user_name.setText(null);
                    pwd_current_user_password.setText(null);
                    txt_Current_user_name.grabFocus();
                }
            } else {
                Model.Object.messagePopUps.user_name_password_not_match();
                txt_Current_user_name.setText(null);
                pwd_current_user_password.setText(null);
                txt_Current_user_name.grabFocus();
            }
        } catch (Exception e) {
            System.out.println("AdminService new_user_register() " + e);
        }
    }

    public void user_serch(JTextField txt_Current_user_name, JPasswordField pwd_current_user_password, JTextField txt_full_name, JTextField txt_user_name, JComboBox cbo_user_Group, JPasswordField pwd_password, JPasswordField pws_confirm_password) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select* from user_login where UserName='" + txt_Current_user_name.getText() + "' ");
            if (rset.next()) {
                txt_full_name.setText(rset.getString(1));
                txt_user_name.setText(rset.getString(2));
                pwd_current_user_password.setText(rset.getString(3));
                cbo_user_Group.setSelectedItem(rset.getString(3));
                pwd_password.setText(rset.getString(4));
                pws_confirm_password.setText(rset.getString(3));
                pwd_current_user_password.grabFocus();

            } else {
                Model.Object.messagePopUps.user_name_password_not_match();
                txt_full_name.setText(null);
                txt_user_name.setText(null);
                cbo_user_Group.setSelectedItem("[ Select ]");
                pwd_password.setText(null);
                txt_Current_user_name.setText(null);
                pws_confirm_password.setText(null);
                pwd_current_user_password.setText(null);
                txt_Current_user_name.grabFocus();

            }
        } catch (Exception e) {
            System.out.println("AdminService user_serch() " + e);
        }
    }

    public void load_group(JComboBox cbo_Permissin_group) {
        try {
            Vector v = new Vector();
            v.add("[ Select ]");
            ResultSet rset = Model.Object.Jdbc.getdata("select* from user_group");
            while (rset.next()) {
                v.add(rset.getString(1));
            }
            cbo_Permissin_group.setModel(new DefaultComboBoxModel(v));
        } catch (Exception e) {
            System.out.println("AdminService load_group() " + e);
        }
    }

    public void save_group() {
        try {
            String user_group = "";
            user_group = Model.Object.messagePopUps.enter_group();
            System.out.println(user_group);
            if (user_group == null || user_group.equals("")) {
                Model.Object.messagePopUps.Plase_Enter_userGroup();
            } else {
                ResultSet rset = Model.Object.Jdbc.getdata("select* from user_group where user_group='" + user_group + "'");
                if (rset.next()) {
                    Model.Object.messagePopUps.Duplicate_entry_plain();
                } else {
                    Model.Object.Jdbc.putdata("insert into user_group values('" + user_group + "','" + FrmHome2.user_lbl.getText() + "','" + Model.Object.Formated.todayDate() + "')");
                    Model.Object.messagePopUps.saveMessage();
                }
            }
        } catch (Exception e) {
            System.out.println("AdminService save_group() " + e);
        }
    }

    public void load_components(JComboBox cbo_components) {
        try {
            Vector v = new Vector();
            v.add("[ Select ]");
            ResultSet rset = Model.Object.Jdbc.getdata("select components from components group by components");
            while (rset.next()) {
                v.add(rset.getString(1));
            }
            cbo_components.setModel(new DefaultComboBoxModel(v));
        } catch (Exception e) {
            System.out.println("AdminService load_components() " + e);
        }
    }

    public void load_function(JComboBox cbo_components, JComboBox CboFunction) {
        try {
            Vector v = new Vector();
            v.add("[ Select ]");
            ResultSet rset = Model.Object.Jdbc.getdata("select function from components where components='" + cbo_components.getSelectedItem() + "'");
            while (rset.next()) {
                v.add(rset.getString(1));
            }
            CboFunction.setModel(new DefaultComboBoxModel(v));
        } catch (Exception e) {
            System.out.println("AdminService load_components() " + e);
        }
    }

    public void load_table_by_user(JComboBox cbo_components, JComboBox cbo_Permissin_group, JTable tbl_permission) {
        try {
            DefaultTableModel df = (DefaultTableModel) tbl_permission.getModel();
            df.setRowCount(0);
            ResultSet rset = Model.Object.Jdbc.getdata("select* from user_permission where User_Group='" + cbo_Permissin_group.getSelectedItem() + "'");
            while (rset.next()) {
                Vector v = new Vector();
                v.add(rset.getString(1));
                v.add(rset.getString(2));
                v.add(rset.getString(3));
                v.add(rset.getBoolean(4));
                df.addRow(v);
            }

        } catch (Exception e) {
            System.out.println("AdminService load_components() " + e);
        }
    }

    public void load_table(JComboBox cbo_components, JComboBox cbo_Permissin_group, JTable tbl_permission) {
        try {
            DefaultTableModel df = (DefaultTableModel) tbl_permission.getModel();
            df.setRowCount(0);
            ResultSet rset = Model.Object.Jdbc.getdata("select* from user_permission where Components='" + cbo_components.getSelectedItem() + "' and User_Group='" + cbo_Permissin_group.getSelectedItem() + "'");
            while (rset.next()) {
                Vector v = new Vector();
                v.add(rset.getString(1));
                v.add(rset.getString(2));
                v.add(rset.getString(3));
                v.add(rset.getBoolean(4));
                df.addRow(v);
            }

        } catch (Exception e) {
            System.out.println("AdminService load_components() " + e);
        }
    }

    public void add_permission(JComboBox cbo_components, JComboBox CboFunction, JTable tbl_permission, JComboBox cbo_Permissin_group, JCheckBox chb_status) {
        try {
            if (CboFunction.getSelectedItem().equals("[ Select ]")) {
                Model.Object.messagePopUps.select_function();
                CboFunction.grabFocus();
            } else if (cbo_Permissin_group.getSelectedItem().equals("[ Select ]")) {
                Model.Object.messagePopUps.select_group();
                cbo_Permissin_group.grabFocus();
            } else if (cbo_components.getSelectedItem().equals("[ Select ]")) {
                Model.Object.messagePopUps.select_Components();
                cbo_components.grabFocus();
            } else {
                DefaultTableModel df = (DefaultTableModel) tbl_permission.getModel();
                ResultSet rset = Model.Object.Jdbc.getdata("select* from user_permission where User_Group='" + cbo_Permissin_group.getSelectedItem() + "' and Components='" + cbo_components.getSelectedItem() + "' and Function='" + CboFunction.getSelectedItem() + "'");
                if (rset.next()) {
                    Model.Object.messagePopUps.duplicate();
                    CboFunction.setSelectedItem("[ Select ]");
                    cbo_Permissin_group.setSelectedItem("[ Select ]");
                    cbo_components.setSelectedItem("[ Select ]");
                    chb_status.setSelected(false);
                } else {
                    Vector v = new Vector();
                    v.add(cbo_Permissin_group.getSelectedItem());
                    v.add(cbo_components.getSelectedItem());
                    v.add(CboFunction.getSelectedItem());
                    String status = "false";
                    if (chb_status.isSelected()) {
                        v.add(true);
                        status = "true";
                    } else {
                        v.add(false);
                        status = "false";
                    }
                    df.addRow(v);
                    Model.Object.Jdbc.putdata("insert into user_permission values('" + cbo_Permissin_group.getSelectedItem() + "','" + cbo_components.getSelectedItem() + "','" + CboFunction.getSelectedItem() + "','" + status + "','" + FrmHome2.user_lbl.getText() + "',NOW())");
                    Model.Object.messagePopUps.saveMessage();
                    CboFunction.setSelectedItem("[ Select ]");
                    cbo_Permissin_group.setSelectedItem("[ Select ]");
                    cbo_components.setSelectedItem("[ Select ]");
                    chb_status.setSelected(false);
                }
            }
        } catch (Exception e) {
            System.out.println("AdminService load_components() " + e);
        }
    }

    public void status_change(JTable tbl_permission) {
        try {
            if (tbl_permission.getSelectedColumn() == 3) {
                if (tbl_permission.getValueAt(tbl_permission.getSelectedRow(), tbl_permission.getSelectedColumn()).equals(true)) {
                    ResultSet rset = Model.Object.Jdbc.getdata("select* from user_permission where User_Group='" + tbl_permission.getValueAt(tbl_permission.getSelectedRow(), 0) + "' and Components='" + tbl_permission.getValueAt(tbl_permission.getSelectedRow(), 1) + "' and Function='" + tbl_permission.getValueAt(tbl_permission.getSelectedRow(), 2) + "'");
                    if (rset.next()) {
                        Model.Object.Jdbc.putdata("update user_permission set Status='" + "true" + "', date_time=NOW(), user='" + FrmHome2.user_lbl.getText() + "' where User_Group='" + tbl_permission.getValueAt(tbl_permission.getSelectedRow(), 0) + "' and Components='" + tbl_permission.getValueAt(tbl_permission.getSelectedRow(), 1) + "'and Function='" + tbl_permission.getValueAt(tbl_permission.getSelectedRow(), 2) + "'");
                        Model.Object.messagePopUps.status_change();
                    }
                } else {
                    ResultSet rset = Model.Object.Jdbc.getdata("select* from user_permission where User_Group='" + tbl_permission.getValueAt(tbl_permission.getSelectedRow(), 0) + "' and Components='" + tbl_permission.getValueAt(tbl_permission.getSelectedRow(), 1) + "' and Function='" + tbl_permission.getValueAt(tbl_permission.getSelectedRow(), 2) + "'");
                    if (rset.next()) {
                        Model.Object.Jdbc.putdata("update user_permission set Status='" + "false" + "' , date_time=NOW(), user='" + FrmHome2.user_lbl.getText() + "'where User_Group='" + tbl_permission.getValueAt(tbl_permission.getSelectedRow(), 0) + "' and Components='" + tbl_permission.getValueAt(tbl_permission.getSelectedRow(), 1) + "' and Function='" + tbl_permission.getValueAt(tbl_permission.getSelectedRow(), 2) + "'");
                        Model.Object.messagePopUps.status_change();
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("AdminService status_change() " + e);
        }
    }
}
