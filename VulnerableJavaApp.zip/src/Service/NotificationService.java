/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author user
 */
public class NotificationService {

    public void load_minimum_qty(JTable tbl_minimum, JComboBox Cbo_Location, JTextField txt_minmun_item_description) {
        try {
            DefaultTableModel df = (DefaultTableModel) tbl_minimum.getModel();
            df.setRowCount(0);
            ResultSet rset = Model.Object.Jdbc.getdata("select* from minimum_qty");
            while (rset.next()) {
                Vector v = new Vector();
                ResultSet rset_stock = Model.Object.Jdbc.getdata("select stock,item_code,item_name from item_inventory where item_code='" + rset.getString(1) + "' and location='" + Cbo_Location.getSelectedItem() + "' and item_name like'" + txt_minmun_item_description.getText() + "%' ");
                if (rset_stock.next()) {
                    if (rset.getDouble(2) >= rset_stock.getDouble(1)) {
                        v.add(rset_stock.getString(2));
                        v.add(rset_stock.getString(3));
                        v.add(rset_stock.getString(1));
                        df.addRow(v);
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("load_minimum_qty() " + e);
        }
    }

    public void load_customer_pending_cheque(JTable Tbl_customer_cheque, JTextField txt_customer) {
        try {
            DefaultTableModel df = (DefaultTableModel) Tbl_customer_cheque.getModel();
            df.setRowCount(0);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
            ResultSet rset = Model.Object.Jdbc.getdata("select* from cheque where grn_or_invoice='" + "Invoice" + "' and ch_status='" + "Pending" + "' order by cheque_date");
            while (rset.next()) {
                if (Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Outlet") == true) {
                    ResultSet rset_inv = Model.Object.Jdbc.getdata("select* from invoice_item where invoice_code='" + rset.getString(1) + "' and location='" + "OUTLET" + "'");
                    if (rset_inv.next()) {
                        Vector v = new Vector();
                        ResultSet rset_customer = Model.Object.Jdbc.getdata("select* from customer_master where customer_code='" + rset.getString(3) + "'");
                        if (rset_customer.next()) {
                            v.add(rset_customer.getString(2));
                        } else {
                            v.add("Unknown");
                        }
                        v.add(rset.getString(1));
                        v.add(rset.getString(2));
                        v.add(Model.Object.Formated.getPriceValue(rset.getDouble(6)));
                        v.add(rset.getString(5));
                        Date add_date = sdf.parse(sdf.format(rset.getDate(5)));
                        Date now_date = sdf.parse(Model.Object.Formated.todayDate());
                        long defference = (add_date.getTime() - now_date.getTime()) / (24 * 60 * 60 * 1000);
                        int i = (int) defference;
                        i++;
                        if (i > 2 && i <= 7) {
                            i = 2;
                        } else if (i <= 2 && i >= 0) {
                            i = 1;
                        } else {
                            i = 3;
                        }
                        v.add(i);
                        df.addRow(v);
                    }

                }
                if (Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Warehouse") == true) {
                    ResultSet rset_inv = Model.Object.Jdbc.getdata("select* from invoice_item where invoice_code='" + rset.getString(1) + "' and location='" + "WAREHOUSE" + "'");
                    if (rset_inv.next()) {
                        Vector v = new Vector();
                        ResultSet rset_customer = Model.Object.Jdbc.getdata("select* from customer_master where customer_code='" + rset.getString(3) + "'");
                        if (rset_customer.next()) {
                            v.add(rset_customer.getString(2));
                        } else {
                            v.add("Unknown");
                        }
                        v.add(rset.getString(1));
                        v.add(rset.getString(2));
                        v.add(Model.Object.Formated.getPriceValue(rset.getDouble(6)));
                        v.add(rset.getString(5));
                        Date add_date = sdf.parse(sdf.format(rset.getDate(5)));
                        Date now_date = sdf.parse(Model.Object.Formated.todayDate());
                        long defference = (add_date.getTime() - now_date.getTime()) / (24 * 60 * 60 * 1000);
                        int i = (int) defference;
                        i++;
                        if (i > 2 && i <= 7) {
                            i = 2;
                        } else if (i <= 2 && i >= 0) {
                            i = 1;
                        } else {
                            i = 3;
                        }
                        v.add(i);
                        df.addRow(v);

                    }
                }
            }
        } catch (Exception e) {
            System.out.println("load_pending_cheque() " + e);
        }
    }

    public void load_customer_pending_cheque_search(JTable Tbl_customer_cheque, JTextField txt_customer) {
        try {
            DefaultTableModel df = (DefaultTableModel) Tbl_customer_cheque.getModel();
            df.setRowCount(0);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
            String customer_code = "";
            ResultSet rset_customer_code = Model.Object.Jdbc.getdata("select* from customer_master where  name like'" + txt_customer.getText() + "%'");
            if (rset_customer_code.next()) {
                customer_code = rset_customer_code.getString(1);
            } else {
                customer_code = "000";
            }
            ResultSet rset = Model.Object.Jdbc.getdata("select* from cheque where grn_or_invoice='" + "Invoice" + "' and ch_status='" + "Pending" + "' and cus_sup_code ='" + customer_code + "' order by cheque_date");
            while (rset.next()) {
                if (Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Outlet") == true) {
                    ResultSet rset_inv = Model.Object.Jdbc.getdata("select* from invoice_item where invoice_code='" + rset.getString(1) + "' and location='" + "OUTLET" + "'");
                    if (rset_inv.next()) {
                        Vector v = new Vector();
                        ResultSet rset_customer = Model.Object.Jdbc.getdata("select* from customer_master where customer_code='" + rset.getString(3) + "'");
                        if (rset_customer.next()) {
                            v.add(rset_customer.getString(2));
                        } else {
                            v.add("Unknown");
                        }
                        v.add(rset.getString(1));
                        v.add(rset.getString(2));
                        v.add(Model.Object.Formated.getPriceValue(rset.getDouble(6)));
                        v.add(rset.getString(5));
                        Date add_date = sdf.parse(sdf.format(rset.getDate(5)));
                        Date now_date = sdf.parse(Model.Object.Formated.todayDate());
                        long defference = (add_date.getTime() - now_date.getTime()) / (24 * 60 * 60 * 1000);
                        int i = (int) defference;
                        i++;
                        if (i > 2 && i <= 7) {
                            i = 2;
                        } else if (i <= 2 && i >= 0) {
                            i = 1;
                        } else {
                            i = 3;
                        }
                        v.add(i);
                        df.addRow(v);
                    }
                }
                if (Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Warehouse") == true) {
                    ResultSet rset_inv = Model.Object.Jdbc.getdata("select* from invoice_item where invoice_code='" + rset.getString(1) + "' and location='" + "WAREHOUSE" + "'");
                    if (rset_inv.next()) {
                        Vector v = new Vector();
                        ResultSet rset_customer = Model.Object.Jdbc.getdata("select* from customer_master where customer_code='" + rset.getString(3) + "'");
                        if (rset_customer.next()) {
                            v.add(rset_customer.getString(2));
                        } else {
                            v.add("Unknown");
                        }
                        v.add(rset.getString(1));
                        v.add(rset.getString(2));
                        v.add(Model.Object.Formated.getPriceValue(rset.getDouble(6)));
                        v.add(rset.getString(5));
                        Date add_date = sdf.parse(sdf.format(rset.getDate(5)));
                        Date now_date = sdf.parse(Model.Object.Formated.todayDate());
                        long defference = (add_date.getTime() - now_date.getTime()) / (24 * 60 * 60 * 1000);
                        int i = (int) defference;
                        i++;
                        if (i > 2 && i <= 7) {
                            i = 2;
                        } else if (i <= 2 && i >= 0) {
                            i = 1;
                        } else {
                            i = 3;
                        }
                        v.add(i);
                        df.addRow(v);
                    }
                }

            }
        } catch (Exception e) {
            System.out.println("load_pending_cheque() " + e);
        }
    }

    public void load_supplier_pending_cheque(JTable Tbl_supplier_cheque, JTextField txt_supplier) {
        try {
            DefaultTableModel df = (DefaultTableModel) Tbl_supplier_cheque.getModel();
            df.setRowCount(0);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
            ResultSet rset = Model.Object.Jdbc.getdata("select* from cheque where grn_or_invoice='" + "Grn" + "' and ch_status='" + "Pending" + "' order by cheque_date");
            while (rset.next()) {
                if (Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Outlet") == true) {
                    ResultSet rset_out = Model.Object.Jdbc.getdata("select* from grn_balance where grn_code='" + rset.getString(1) + "' and location='" + "OUTLET" + "'");
                    if (rset_out.next()) {
                        Vector v = new Vector();
                        ResultSet rset_supplier = Model.Object.Jdbc.getdata("select* from supplier_master where supplier_code='" + rset.getString(3) + "'");
                        if (rset_supplier.next()) {
                            v.add(rset_supplier.getString(2));
                        } else {
                            v.add("Unknown");
                        }
                        v.add(rset.getString(1));
                        v.add(rset.getString(2));
                        v.add(Model.Object.Formated.getPriceValue(rset.getDouble(6)));
                        v.add(rset.getString(5));
                        Date add_date = sdf.parse(sdf.format(rset.getDate(5)));
                        Date now_date = sdf.parse(Model.Object.Formated.todayDate());
                        long defference = (add_date.getTime() - now_date.getTime()) / (24 * 60 * 60 * 1000);
                        int i = 0;
                        i = (int) defference;
                        i++;
                        if (i > 2 && i <= 7) {
                            i = 2;
                        } else if (i <= 2 && i >= 0) {
                            i = 1;
                        } else {
                            i = 3;
                        }
                        v.add(i);
                        df.addRow(v);
                    }
                }
                if (Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Warehouse") == true) {
                    ResultSet rset_out = Model.Object.Jdbc.getdata("select* from grn_balance where grn_code='" + rset.getString(1) + "' and location='" + "WAREHOUSE" + "'");
                    if (rset_out.next()) {
                        Vector v = new Vector();
                        ResultSet rset_supplier = Model.Object.Jdbc.getdata("select* from supplier_master where supplier_code='" + rset.getString(3) + "'");
                        if (rset_supplier.next()) {
                            v.add(rset_supplier.getString(2));
                        } else {
                            v.add("Unknown");
                        }
                        v.add(rset.getString(1));
                        v.add(rset.getString(2));
                        v.add(Model.Object.Formated.getPriceValue(rset.getDouble(6)));
                        v.add(rset.getString(5));
                        Date add_date = sdf.parse(sdf.format(rset.getDate(5)));
                        Date now_date = sdf.parse(Model.Object.Formated.todayDate());
                        long defference = (add_date.getTime() - now_date.getTime()) / (24 * 60 * 60 * 1000);
                        int i = 0;
                        i = (int) defference;
                        i++;
                        if (i > 2 && i <= 7) {
                            i = 2;
                        } else if (i <= 2 && i >= 0) {
                            i = 1;
                        } else {
                            i = 3;
                        }
                        v.add(i);
                        df.addRow(v);
                    }
                }

            }
        } catch (Exception e) {
            System.out.println("load_pending_cheque() " + e);
        }
    }
    String supplier_code = " ";

    public void load_supplier_pending_cheque_search(JTable Tbl_supplier_cheque, JTextField txt_supplier) {
        try {
            DefaultTableModel df = (DefaultTableModel) Tbl_supplier_cheque.getModel();
            df.setRowCount(0);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
            ResultSet rset_supplier_code = Model.Object.Jdbc.getdata("select* from supplier_master where  name like'" + txt_supplier.getText() + "%'");
            if (rset_supplier_code.next()) {
                supplier_code = rset_supplier_code.getString(1);
                System.out.println(supplier_code = rset_supplier_code.getString(1));
            } else {
                supplier_code = " ";
            }
            ResultSet rset = Model.Object.Jdbc.getdata("select* from cheque where grn_or_invoice='" + "Grn" + "' and ch_status='" + "Pending" + "' and cus_sup_code ='" + supplier_code + "' order by cheque_date");
            while (rset.next()) {
                if (Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Outlet") == true) {
                    ResultSet rset_out = Model.Object.Jdbc.getdata("select* from grn_balance where grn_code='" + rset.getString(1) + "' and location='" + "OUTLET" + "'");
                    if (rset_out.next()) {
                        Vector v = new Vector();
                        ResultSet rset_supplier = Model.Object.Jdbc.getdata("select* from supplier_master where supplier_code='" + rset.getString(3) + "'");
                        if (rset_supplier.next()) {
                            v.add(rset_supplier.getString(2));
                        } else {
                            v.add("Unknown");
                        }
                        v.add(rset.getString(1));
                        v.add(rset.getString(2));
                        v.add(Model.Object.Formated.getPriceValue(rset.getDouble(6)));
                        v.add(rset.getString(5));
                        Date add_date = sdf.parse(sdf.format(rset.getDate(5)));
                        Date now_date = sdf.parse(Model.Object.Formated.todayDate());
                        long defference = (add_date.getTime() - now_date.getTime()) / (24 * 60 * 60 * 1000);
                        int i = 0;
                        i = (int) defference;
                        i++;
                        if (i > 2 && i <= 7) {
                            i = 2;
                        } else if (i <= 2 && i >= 0) {
                            i = 1;
                        } else {
                            i = 3;
                        }
                        v.add(i);
                        df.addRow(v);
                    }
                }
                if (Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Warehouse") == true) {
                    ResultSet rset_out = Model.Object.Jdbc.getdata("select* from grn_balance where grn_code='" + rset.getString(1) + "' and location='" + "OUTLET" + "'");
                    if (rset_out.next()) {
                        Vector v = new Vector();
                        ResultSet rset_supplier = Model.Object.Jdbc.getdata("select* from supplier_master where supplier_code='" + rset.getString(3) + "'");
                        if (rset_supplier.next()) {
                            v.add(rset_supplier.getString(2));
                        } else {
                            v.add("Unknown");
                        }
                        v.add(rset.getString(1));
                        v.add(rset.getString(2));
                        v.add(Model.Object.Formated.getPriceValue(rset.getDouble(6)));
                        v.add(rset.getString(5));
                        Date add_date = sdf.parse(sdf.format(rset.getDate(5)));
                        Date now_date = sdf.parse(Model.Object.Formated.todayDate());
                        long defference = (add_date.getTime() - now_date.getTime()) / (24 * 60 * 60 * 1000);
                        int i = 0;
                        i = (int) defference;
                        i++;
                        if (i > 2 && i <= 7) {
                            i = 2;
                        } else if (i <= 2 && i >= 0) {
                            i = 1;
                        } else {
                            i = 3;
                        }
                        v.add(i);
                        df.addRow(v);
                    }
                }

            }
        } catch (Exception e) {
            System.out.println("load_pending_cheque() " + e);
        }
    }

    public void load_item_code_details(JTable tbl_item_description, JTextField txt_item_code) {
        try {
            DefaultTableModel df = (DefaultTableModel) tbl_item_description.getModel();
            df.setRowCount(0);
            String location = "";
            if (Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Outlet") == true) {
                location = "OUTLET";
            } else if (Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Warehouse") == true) {
                location = "WAREHOUSE";
            }
            ResultSet rset = Model.Object.Jdbc.getdata("select* from item_inventory where item_code like'" + txt_item_code.getText() + "%'and location='" + location + "'");
            while (rset.next()) {
                Vector v = new Vector();
                v.add(rset.getString(1));
                v.add(rset.getString(2));
                ResultSet rset_master = Model.Object.Jdbc.getdata("select* from item_master where item_code='" + rset.getString(1) + "'");
                if (rset_master.next()) {
                    v.add(Model.Object.Formated.getPriceValue(rset_master.getDouble(4)));
                    v.add(Model.Object.Formated.getPriceValue(rset_master.getDouble(6)));
                } else {
                    v.add("Unknown");
                    v.add("Unknown");
                }
                v.add(rset.getString(4));
                df.addRow(v);
            }
        } catch (Exception e) {
            System.out.println("load_item_details() " + e);
        }
    }

    public void load_item_desciption_details(JTable tbl_item_description, JTextField txt_item_description) {
        try {
            DefaultTableModel df = (DefaultTableModel) tbl_item_description.getModel();
            df.setRowCount(0);
             String location = "";
            if (Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Outlet") == true) {
                location = "OUTLET";
            } else if (Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Warehouse") == true) {
                location = "WAREHOUSE";
            }
            ResultSet rset = Model.Object.Jdbc.getdata("select* from item_inventory where item_name like'" + txt_item_description.getText() + "%' and location='" + location + "'");
            while (rset.next()) {
                Vector v = new Vector();
                v.add(rset.getString(1));
                v.add(rset.getString(2));
                ResultSet rset_master = Model.Object.Jdbc.getdata("select* from item_master where item_code='" + rset.getString(1) + "'");
                if (rset_master.next()) {
                    v.add(Model.Object.Formated.getPriceValue(rset_master.getDouble(4)));
                    v.add(Model.Object.Formated.getPriceValue(rset_master.getDouble(6)));
                } else {
                    v.add("Unknown");
                    v.add("Unknown");
                }
                v.add(rset.getString(4));
                df.addRow(v);
            }
        } catch (Exception e) {
            System.out.println("load_item_details() " + e);
        }
    }
}
