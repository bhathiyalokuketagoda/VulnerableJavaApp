/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import View.FrmHome2;
import java.sql.ResultSet;
import java.util.Vector;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JTextField;

/**
 *
 * @author user
 */
public class PastInvoice {

    public void load_past_invoice_number(JList lst_invoice_number) {
        try {

            ResultSet rset1 = Model.Object.Jdbc.getdata("select Admin from user_login where UserGroup='" + FrmHome2.group + "'");
            if (rset1.next()) {
                if (rset1.getString(1).equals("Admin") || (Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Outlet") == true && Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Warehouse") == true)) {
                    Vector v = new Vector();
                    lst_invoice_number.setListData(v);
                    ResultSet rset = Model.Object.Jdbc.getdata("select invoice_code from invoice_balance order by LPAD(lower(invoice_balance.invoice_code), 10,0) ASC");
                    while (rset.next()) {
                        v.add(rset.getString(1));
                    }
                    lst_invoice_number.setListData(v);
                    //admin

                } else if (Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Outlet") == true) {
                    Vector v = new Vector();
                    lst_invoice_number.setListData(v);
                    // ResultSet rset = Model.Object.Jdbc.getdata("select invoice_code from invoice_balance order by invoice_code  ASC");
                    //

                    ResultSet rset = Model.Object.Jdbc.getdata("SELECT invoice_balance.invoice_code FROM invoice_balance INNER JOIN invoice_item ON invoice_balance.invoice_code = invoice_item.invoice_code WHERE invoice_item.location = 'OUTLET' GROUP BY invoice_item.invoice_code order by LPAD(lower(invoice_balance.invoice_code), 10,0) ASC ");
                    while (rset.next()) {
                        v.add(rset.getString(1));
                    }
                    lst_invoice_number.setListData(v);
                    //outlet

                } else if (Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Warehouse") == true) {
                    Vector v = new Vector();
                    lst_invoice_number.setListData(v);
                    ResultSet rset = Model.Object.Jdbc.getdata("SELECT invoice_balance.invoice_code FROM invoice_balance INNER JOIN invoice_item ON invoice_balance.invoice_code = invoice_item.invoice_code WHERE invoice_item.location = 'WAREHOUSE' GROUP BY invoice_item.invoice_code order by LPAD(lower(invoice_balance.invoice_code), 10,0) ASC ");
                    while (rset.next()) {
                        v.add(rset.getString(1));
                    }
                    lst_invoice_number.setListData(v);
                    //wherhouse
                }
            }

        } catch (Exception e) {
            System.out.println("load_past_invoice_number()  " + e);
        }
    }

    public void search_past_invoice_bycustomer(JList lst_invoice_number, JTextField txt_cus) {
        try {

            ResultSet rset1 = Model.Object.Jdbc.getdata("select Admin from user_login where UserGroup='" + FrmHome2.group + "'");
            if (rset1.next()) {
                if (rset1.getString(1).equals("Admin") || (Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Outlet") == true && Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Warehouse") == true)) {
                    Vector v = new Vector();
                    lst_invoice_number.setListData(v);
                    ResultSet rsettsetcus = Model.Object.Jdbc.getdata("select customer_code  from customer_master where name like '" + txt_cus.getText() + "%'");
                    while (rsettsetcus.next()) {
                        ResultSet rset = Model.Object.Jdbc.getdata("select invoice_code from invoice_balance where customer_code ='" + rsettsetcus.getString(1) + "' order by LPAD(lower(invoice_balance.invoice_code), 10,0) ASC");
                        while (rset.next()) {
                            v.add(rset.getString(1));
                            System.out.println(rsettsetcus.getString(1));
                            System.out.println(rset.getString(1));
                        }
                    }
                    lst_invoice_number.setListData(v);
                    //admin

                } else if (Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Outlet") == true) {
                    Vector v = new Vector();
                    lst_invoice_number.setListData(v);
                    ResultSet rsettsetcus = Model.Object.Jdbc.getdata("select customer_code  from customer_master where name like '" + txt_cus.getText() + "%'");
                    while (rsettsetcus.next()) {
                        ResultSet rset = Model.Object.Jdbc.getdata("SELECT invoice_balance.invoice_code FROM invoice_balance INNER JOIN invoice_item ON invoice_balance.invoice_code = invoice_item.invoice_code WHERE invoice_item.location = 'OUTLET' AND invoice_balance.customer_code ='" + rsettsetcus.getString(1) + "' GROUP BY invoice_item.invoice_code order by LPAD(lower(invoice_balance.invoice_code), 10,0) ASC ");
                        while (rset.next()) {
                            v.add(rset.getString(1));
                        }
                    }
                    lst_invoice_number.setListData(v);
                    //outlet

                } else if (Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Warehouse") == true) {
                    Vector v = new Vector();
                    lst_invoice_number.setListData(v);
                    ResultSet rsettsetcus = Model.Object.Jdbc.getdata("select customer_code  from customer_master where name like '" + txt_cus.getText() + "%'");
                    while (rsettsetcus.next()) {
                        ResultSet rset = Model.Object.Jdbc.getdata("SELECT invoice_balance.invoice_code FROM invoice_balance INNER JOIN invoice_item ON invoice_balance.invoice_code = invoice_item.invoice_code WHERE invoice_item.location = 'WAREHOUSE' AND invoice_balance.customer_code ='" + rsettsetcus.getString(1) + "' GROUP BY invoice_item.invoice_code order by LPAD(lower(invoice_balance.invoice_code), 10,0) ASC ");
                        while (rset.next()) {
                            v.add(rset.getString(1));
                        }
                    }
                    lst_invoice_number.setListData(v);
                    //wherhouse
                }
            }

        } catch (Exception e) {
            System.out.println("load_past_invoice_number()  " + e);
        }
    }

    public void search_past_invoice_number(JList lst_invoice_number, JTextField txt_search) {
        try {

            ResultSet rset1 = Model.Object.Jdbc.getdata("select Admin from user_login where UserGroup='" + FrmHome2.group + "'");
            if (rset1.next()) {
                if (rset1.getString(1).equals("Admin") || (Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Outlet") == true && Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Warehouse") == true)) {
                    Vector v = new Vector();
                    lst_invoice_number.setListData(v);
                    ResultSet rset = Model.Object.Jdbc.getdata("select invoice_code from invoice_balance where invoice_code like'" + "INV" + txt_search.getText() + "%' order by invoice_code");
                    while (rset.next()) {
                        v.add(rset.getString(1));
                    }
                    lst_invoice_number.setListData(v);
                    //admin

                } else if (Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Outlet") == true) {
                    Vector v = new Vector();
                    lst_invoice_number.setListData(v);
                    ResultSet rset = Model.Object.Jdbc.getdata("SELECT invoice_balance.invoice_code FROM invoice_balance INNER JOIN invoice_item ON invoice_balance.invoice_code = invoice_item.invoice_code WHERE invoice_item.location = 'OUTLET' AND invoice_balance.invoice_code like '" + "INV" + txt_search.getText() + "%' GROUP BY invoice_item.invoice_code order by LPAD(lower(invoice_balance.invoice_code), 10,0) ASC ");
                    while (rset.next()) {
                        v.add(rset.getString(1));
                    }
                    lst_invoice_number.setListData(v);
                    //outlet

                } else if (Model.Object.Admin.check_user_permission_cheque_eithount_msg("Location", "Warehouse") == true) {
                    Vector v = new Vector();
                    lst_invoice_number.setListData(v);
                    ResultSet rset = Model.Object.Jdbc.getdata("SELECT invoice_balance.invoice_code FROM invoice_balance INNER JOIN invoice_item ON invoice_balance.invoice_code = invoice_item.invoice_code WHERE invoice_item.location = 'WAREHOUSE' AND invoice_balance.invoice_code like '" + "INV" + txt_search.getText() + "%' GROUP BY invoice_item.invoice_code order by LPAD(lower(invoice_balance.invoice_code), 10,0) ASC ");
                    while (rset.next()) {
                        v.add(rset.getString(1));
                    }
                    lst_invoice_number.setListData(v);
                    //wherhouse
                }
            }

        } catch (Exception e) {
            System.out.println("load_past_invoice_number()  " + e);
        }
    }

    public void select_code(String invoice_number, JLabel lbl_customer, JLabel lbl_invoice_date, JLabel lbl_amount, JLabel lbl_sale_type) {
        try {
            ResultSet rset = Model.Object.Jdbc.getdata("select* from invoice_balance where invoice_code='" + invoice_number + "'");
            if (rset.next()) {
                ResultSet rset_c = Model.Object.Jdbc.getdata("select* from customer_master where customer_code='" + rset.getString(2) + "'");
                if (rset_c.next()) {
                    lbl_customer.setText(rset_c.getString(2));
                } else {
                    lbl_customer.setText("Unknown Customer");
                }
                lbl_invoice_date.setText(rset.getString(3));
                lbl_sale_type.setText(rset.getString(10));
                lbl_amount.setText(rset.getString(9));
            }
        } catch (Exception e) {
            System.out.println(" past invoice    select_code()   " + e);
        }
    }

}
