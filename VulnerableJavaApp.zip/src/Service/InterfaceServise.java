/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import java.awt.Color;
import javax.swing.JLabel;

/**
 *
 * @author user
 */
public class InterfaceServise {

    public void close_label_focus(JLabel lbl_close) {
        lbl_close.setOpaque(true);
        lbl_close.setBackground(Color.RED);
    }

    public void close_label_focus_out(JLabel lbl_close) {
        lbl_close.setOpaque(false);
        lbl_close.setBackground(new Color(10, 20, 30, 0));
    }

    public void minimize_label_focus(JLabel lbl_minimize) {
        lbl_minimize.setOpaque(true);
        lbl_minimize.setBackground(Color.blue);
    }

    public void minimize_label_focus_out(JLabel lbl_minimize) {
        lbl_minimize.setOpaque(false);
        lbl_minimize.setBackground(new Color(10, 20, 30, 0));
    }
}
